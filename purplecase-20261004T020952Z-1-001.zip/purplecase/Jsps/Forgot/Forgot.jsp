<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="PageBegin_description" value="'Forgot Your Username or Password?'" />
<ww:include page="/Jsps/Page/Begin.jsp" />
	<div class="PageTitle">Forgot Your Username or Password?</div>
	<div class="PageTitleTagLine">We've got it covered. Fill out this form and we'll email you right away with your username and new temporary password.</div>
		
	<form name="validatedForgot" action="<ww:property value="registry.linkGenerator.processForgot" />" method="POST">
        <ww:include page="/Jsps/Utils/BackUrlHiddenField.jsp" />
        <ww:include page="/Jsps/Utils/ReturnUrlHiddenField.jsp" />
        <ww:set name="FormModuleHeader_title" value="'1. Enter your email address'" />
        <ww:set name="FormModuleHeader_showRequiredFieldsNotice" value="true" />
        <ww:include page="/Jsps/Utils/FormModuleHeader.jsp" />
            <ww:component template="form-containerbegin.vm" />
                <ww:component template="form-rowbegin.vm" />
                    <ww:component template="form-cellbegin.vm" />
                        <ww:textfield size="50" required="true" labelposition="'top'" label="@com.zeedive.validation.validated.ValidatedForgot@EMAIL_LABEL" name="'validatedForgot.email'"/>
                    <ww:component template="form-cellend.vm" />
                <ww:component template="form-rowend.vm" />
                <ww:component template="form-rowbegin.vm" />
                    <ww:set
                        name="FormInlineHelpCell_message"
                        value="'This must be the email address you have on file.'" />
                    <ww:include page="/Jsps/Utils/FormInlineHelpCell.jsp" />
                <ww:component template="form-rowend.vm" />
            <ww:component template="form-containerend.vm" />
            <br />
        <ww:include page="/Jsps/Utils/FormModuleFooter.jsp" />
        <br/>
		<ww:set name="FormModuleHeader_title" value="'2. Answer your security question'" />
		<ww:set name="FormModuleHeader_showRequiredFieldsNotice" value="false" />
		<ww:include page="/Jsps/Utils/FormModuleHeader.jsp" />
			<ww:component template="form-containerbegin.vm" />
                <ww:component template="form-rowbegin.vm" />
                    <ww:component template="form-cellbegin.vm" />
                    <ww:select
                        required="true"
                        labelposition="'top'"
                        label="@com.zeedive.validation.validated.ValidatedForgot@SECURITY_QUESTION_LABEL"
                        headerKey="''"
                        headerValue="'--Select--'"
                        name="'validatedForgot.securityQuestion'"
                        list="@com.zeedive.domain.objects.SecurityQuestion@values()"
                        listValue="displayName"
                        size="1"/>
                    <ww:component template="form-cellend.vm" />
                <ww:component template="form-rowend.vm" />
                <ww:component template="form-rowbegin.vm" />
                    <ww:set
                        name="FormInlineHelpCell_message"
                        value="'Select the security question you originally picked.'" />
                    <ww:include page="/Jsps/Utils/FormInlineHelpCell.jsp" />
                <ww:component template="form-rowend.vm" />
                <ww:component template="form-rowspacing.vm" />
                <ww:component template="form-rowbegin.vm" />
                    <ww:component template="form-cellbegin.vm" />
                        <ww:textfield size="50" required="true" labelposition="'top'" label="@com.zeedive.validation.validated.ValidatedForgot@SECURITY_ANSWER_LABEL" name="'validatedForgot.securityAnswer'"/>
                    <ww:component template="form-cellend.vm" />
                <ww:component template="form-rowend.vm" />
                <ww:component template="form-rowbegin.vm" />
                    <ww:set
                        name="FormInlineHelpCell_message"
                        value="'Enter the answer to your security question exactly as you originally typed it.'" />
                    <ww:include page="/Jsps/Utils/FormInlineHelpCell.jsp" />
                <ww:component template="form-rowend.vm" />
			<ww:component template="form-containerend.vm" />
			<br />
		<ww:include page="/Jsps/Utils/FormModuleFooter.jsp" />
		<ww:set name="FormSubmitFooter_submitButtonName" value="'Send Email'" />
		<ww:set name="FormSubmitFooter_helpText" value="'Press \"Send Email\" to have an email sent right away with your username and a new temporary password.'" />
		<ww:include page="/Jsps/Utils/FormSubmitFooter.jsp" />
	</form>
<ww:set name="End_backUrl" value="registry.linkGenerator.getForgot().setBackUrl(backUrl)" />
<ww:include page="/Jsps/Page/End.jsp" />