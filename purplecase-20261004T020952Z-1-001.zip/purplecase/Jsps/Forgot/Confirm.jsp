<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="PageBegin_description" value="'Forgot Your Username or Password?'" />
<ww:include page="/Jsps/Page/Begin.jsp" />
<div class="PageTitle">Email Sent!</div>
<div class="PageTitleTagLine">
	In a few minutes, you'll receive an email with your username and temporary password.
    <br/>
    <br/>
    <br/>
    <b>We strongly recommend you change this password as soon as you're signed in.</b>
    <br/>
    (To change, go to "My Account" in the navigation bar.)
</div>
<div class="ModuleEmpty">
<table cellpadding="0" cellspacing="0">
    <tr>
        <td>
            <form name="form" action="<ww:property value="registry.linkGenerator.forUrl(returnUrl)" />" method="GET">
                <ww:component template="form-containerbegin.vm" />
                    <ww:submit name="'doSubmit'" align="left" value="'Continue'" />
                <ww:component template="form-containerend.vm" />
            </form>
        </td>
    </tr>
</table>
</div>
<p>&nbsp;</p>
<ww:set name="End_backUrl" value="registry.linkGenerator.getForgotConfirm().setBackUrl(backUrl)" />
<ww:include page="/Jsps/Page/End.jsp" />