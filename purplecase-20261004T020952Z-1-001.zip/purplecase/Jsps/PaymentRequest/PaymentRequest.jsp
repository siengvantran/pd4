<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="PageBegin_description" value="'Contact Seller'" />
<ww:include page="/Jsps/Page/Begin.jsp" />
<ww:set name="ContactTitle_user" value="user" />
<ww:include page="/Jsps/Contact/Title.jsp" />
<form name="validatedPaymentRequest" action="<ww:property value="registry.linkGenerator.processPaymentRequest" />" method="POST">
	<ww:include page="/Jsps/Utils/BackUrlHiddenField.jsp" />
	<ww:hidden name="'userId'" value="user.userId"/>
	<ww:include page="/Jsps/Utils/FormModuleBareHeader.jsp" />
		<table class="FullWidth" cellpadding="0" cellspacing="0">
			<tr>
				<td class="TableTitleContainerLeft" colspan="3">&nbsp;</td>
				<td class="TableTitleContainerInside">
					Quantity
				</td>
				<td class="TableTitleContainerRight" style="text-align:right; padding-right: 11px;">
					Price
				</td>
			</tr>
				<ww:iterator value="model.paymentRequest.catches" status="iteratorStatus">
				<ww:set name="Payment_listRowClass" value="#iteratorStatus.odd ? 'BrowseResultDark' : 'BrowseResultLight'" />
				<tr class="<ww:property value="#Payment_listRowClass" />">
					<td width="1" class="BrowseResultLight">
						<div class="PaymentRequestCheckBox">
							<ww:component template="form-containerbegin.vm" />
								<ww:checkbox
									name="'validatedPaymentRequest.validatedPaymentRequestCatches.ids'"
									value="validatedPaymentRequest.validatedPaymentRequestCatches.idsForDomain.contains(top.catchId)"
									fieldValue="top.catchId" />
							<ww:component template="form-containerend.vm" />
						</div>
					</td>
					<td width="1" class="PaymentThumbnail">
						<ww:set name="Thumbnail_type" value="'Micro'" />
						<ww:set name="Thumbnail_listing" value="top.listing" />
						<ww:set name="Thumbnail_readOnly" value="true" />
						<ww:include page="/Jsps/Picture/Thumbnail.jsp" />
					</td>
					<td class="BrowseResultTitle">
						<ww:property value="registry.htmlRenderer.renderAsText(registry.internationalizer.formatter.formatListingTitle(top.listing.title))" />
					</td>
					<td class="PaymentQuantity">
						<ww:property value="registry.internationalizer.formatter.formatCount(top.buyerCatch.quantityWon)" />
					</td>
					<td class="PaymentPrice">
						<ww:property value="registry.internationalizer.formatter.formatPrice(top.price)" />
					</td>
				</tr>
			</ww:iterator>
		</table>	
		<ww:include page="/Jsps/Utils/PageNavigationEmpty.jsp" />
	<ww:include page="/Jsps/Utils/FormModuleBareFooter.jsp" />
	
	<ww:set name="FormModuleHeader_title" value="'Enter Your Message'" />
	<ww:set name="FormModuleHeader_showRequiredFieldsNotice" value="false" />
	<ww:include page="/Jsps/Utils/FormModuleHeader.jsp" />
		<ww:component template="form-containerbegin.vm" />
			<ww:component template="form-rowbegin.vm" />
				<ww:textarea 
					labelposition="'top'" 
					cols="60"
					rows="5" 
					label="@com.zeedive.validation.validated.ValidatedPayment@MESSAGE_LABEL" 
					name="'validatedPaymentRequest.message'"/>
			<ww:component template="form-rowend.vm" />
			<ww:component template="form-rowbegin.vm" />
				<ww:set name="FormInlineHelpCell_message" value="'Leave blank if no message'" />
				<ww:include page="/Jsps/Utils/FormInlineHelpCell.jsp" />
			<ww:component template="form-rowend.vm" />
		<ww:component template="form-containerend.vm" />
	<ww:include page="/Jsps/Utils/FormModuleFooter.jsp" />
	<div style="display: none;"><input type="text" id="command" name="command" value="SEND" /></div>
	<ww:set name="FormSubmitFooter_linkId" value="'PreviewPaymentRequest'" />
	<ww:set name="FormSubmitFooter_linkText" value="'Preview Message'" />
	<ww:set name="FormSubmitFooter_linkDestination" value="'#'" />
	<ww:set name="FormSubmitFooter_linkOnClick" value="'document.getElementById(&#39;command&#39;).value = &#39;PREVIEW&#39;; validatedPaymentRequest.submit(); return false;'" />
	<ww:set name="FormSubmitFooter_submitButtonName" value="'Send Message'" />
	<ww:set name="FormSubmitFooter_helpText" value="'Press \"Send Message\" to send your message right away. Click \"Preview Message\" if you wish to preview the message before sending it'" />
	<ww:include page="/Jsps/Utils/FormSubmitFooter.jsp" />
</form>
<ww:set name="End_backUrl" value="registry.linkGenerator.getPaymentRequest(user.userId).setBackUrl(backUrl)" />
<ww:include page="/Jsps/Page/End.jsp" />