<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="ItemList_catches" value="#PaymentRequestReadOnly_paymentRequest.catches" />
<ww:include page="/Jsps/Invoice/Html/ItemList.jsp" />
<table class="ModuleContainer" cellpadding="0" cellspacing="0">
	<ww:if test="@com.zeedive.util.StringUtil@isEmpty(#PaymentRequestReadOnly_paymentRequest.message) == false">
		<tr>
			<td colspan="2">
				<ww:set name="ModuleHeader_title" value="'Message to Seller'" />
				<ww:include page="/Jsps/Utils/ModuleHeader.jsp" />
					<ww:property value="
						registry.htmlRenderer.renderAsText(registry.internationalizer.formatter.formatUserMessage(
							#PaymentRequestReadOnly_paymentRequest.message))"/>
				<ww:include page="/Jsps/Utils/ModuleFooter.jsp" />
			</td>
		</tr>
	</ww:if>
</table>