<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="PageBegin_description" value="'Contact Seller - Preview'" />
<ww:include page="/Jsps/Page/Begin.jsp" />
<ww:set name="ContactTitle_user" value="user" />
<ww:include page="/Jsps/Contact/Title.jsp" />
<ww:set name="PaymentRequestReadOnly_paymentRequest" value="model.paymentRequest" />
<ww:include page="Html/ReadOnly.jsp" />
<form name="validatedPaymentRequest" action="<ww:property value="registry.linkGenerator.processPaymentRequest" />" method="POST" onsubmit="disableForm(this)">
<ww:include page="/Jsps/Utils/BackUrlHiddenField.jsp" />
<ww:hidden name="'userId'" value="user.userId"/>
<ww:iterator value="model.paymentRequest.catches" status="iteratorStatus">
	<ww:if test="validatedPaymentRequest.validatedPaymentRequestCatches.idsForDomain.contains(top.catchId)" >
		<ww:hidden
			name="'validatedPaymentRequest.validatedPaymentRequestCatches.ids'"
			value="top.catchId" />
	</ww:if>
</ww:iterator>
<ww:hidden name="'validatedPaymentRequest.message'"/>
<div style="display: none;"><input type="text" id="command" name="command" value="SEND" /></div>
<br />
<ww:set name="FormSubmitFooter_linkId" value="'EditPaymentRequest'" />
<ww:set name="FormSubmitFooter_linkText" value="'Edit Message'" />
<ww:set name="FormSubmitFooter_linkDestination" value="'#'" />
<ww:set name="FormSubmitFooter_linkOnClick" value="'document.getElementById(&#39;command&#39;).value = &#39;EDIT&#39;; validatedPaymentRequest.submit(); return false;'" />
<ww:set name="FormSubmitFooter_submitButtonName" value="'Send Message'" />
<ww:set name="FormSubmitFooter_helpText" value="'Press \"Send Message\" to send your message right away. Click \"Preview Message\" if you wish to preview the message before sending it'" />
<ww:include page="/Jsps/Utils/FormSubmitFooter.jsp" />
</form>
<ww:set name="End_backUrl" value="registry.linkGenerator.getProcessPaymentRequest().setBackUrl(backUrl)" />
<ww:include page="/Jsps/Page/End.jsp" />