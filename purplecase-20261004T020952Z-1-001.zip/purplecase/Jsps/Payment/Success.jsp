<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="PageBegin_description" value="'Payment Successful'" />
<ww:include page="/Jsps/Page/Begin.jsp" />
<div class="PageTitle">Payment Successful</div>	
<div class="PageTitleTagLine">
	Your payment of 
	<span class="PaymentSucessImportant">
		<ww:property value="registry.internationalizer.formatter.formatPrice(payment.total)" /> 
	</span>		
	to
	<span class="PaymentSucessImportant">
		<ww:property value="registry.internationalizer.formatter.formatUsername(payment.toUser.username)" />
	</span>
	has been processed successfully.
	<br/>
	<br/>
	<br/>
	This payment number is 
	<span class="PaymentSucessImportant">
		<ww:property value="registry.internationalizer.formatter.formatId(payment.paymentId)" /></span>.
        <br/>Please keep this number for your records.
    <br/>
    <br/>
    <br/>
    <ww:if test="authenticationInfo.user.emailPreferences.paymentSent == true">
        A confirmation email has been sent to <ww:property value="registry.internationalizer.formatter.formatEmail(authenticationInfo.user.email)" />
        <br/>
        <br/>
        <br/>
    </ww:if>
    <b>What's next?</b>
    <br/>
    <br/>You will be notified by email as soon as your items have been shipped.
    <br/>You can access your order status at any time by clicking <a id="PaymentSuccessMyItems" href="<ww:property value="registry.linkGenerator.myDives" />">My Dives</a> on the main nagivation bar on top of the page.
</div>
<form name="form" action="<ww:property value="registry.linkGenerator.myDivesCaught" />" method="POST">
	<ww:set name="FormSubmitFooter_submitButtonName" value="'Continue'" />
	<ww:include page="/Jsps/Utils/FormSubmitFooter.jsp" />
</form>

<ww:set name="End_backUrl" value="registry.linkGenerator.getPaymentSuccess(payment).setBackUrl(backUrl)" />
<ww:include page="/Jsps/Page/End.jsp" />
