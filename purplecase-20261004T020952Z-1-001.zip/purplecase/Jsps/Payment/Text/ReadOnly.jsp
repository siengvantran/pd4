<%@ taglib uri="webwork" prefix="ww" %><ww:set name="ItemList_catches" value="#PaymentReadOnly_payment.invoice.catches" /><ww:include page="/Jsps/Invoice/Text/ItemList.jsp" />
Item Total: <ww:property value="registry.internationalizer.formatter.formatPrice(#PaymentReadOnly_payment.invoice.catchesTotal)"/>
Shipping Total -  <ww:property value="registry.internationalizer.formatter.formatShippingProvider(#PaymentReadOnly_payment.shippingOption.provider.displayName)"/><ww:if test="#PaymentReadOnly_payment.shippingInsurance == true">, Insured</ww:if>: <ww:property value="registry.internationalizer.formatter.formatPrice(#PaymentReadOnly_payment.shippingTotal)"/>
Sales Tax: <ww:property value="registry.internationalizer.formatter.formatPrice(#PaymentReadOnly_payment.salesTaxTotal)"/><ww:if test="@com.zeedive.util.NumberUtil@makeSafe(#PaymentReadOnly_payment.invoice.sellerCharges) != 0.0">
Seller Charge: <ww:property value="registry.internationalizer.formatter.formatPrice(#PaymentReadOnly_payment.invoice.sellerCharges)"/></ww:if><ww:if test="#PaymentReadOnly_payment.hasCredit == true">
DiveCash: <ww:property value="registry.internationalizer.formatter.formatPrice(#PaymentReadOnly_payment.credit)"/></ww:if>

Total: <ww:property value="registry.internationalizer.formatter.formatPrice(#PaymentReadOnly_payment.total)"/>


Shipping Address:

<ww:set name="AddressInfo_address" value="#PaymentReadOnly_payment.address" /><ww:set name="AddressForm_includePhoneNumber" value="false" /><ww:include page="/Jsps/Address/Text/Info.jsp" />


Billing Information:

<ww:set name="CreditCardInfo_creditCard" value="#PaymentReadOnly_payment.creditCard" /><ww:include page="/Jsps/CreditCard/Text/Info.jsp" /><ww:if test="@com.zeedive.util.StringUtil@isEmpty(#PaymentReadOnly_payment.message) == false">


Message to Seller:

<ww:property value="registry.internationalizer.formatter.formatUserMessage(#PaymentReadOnly_payment.message)"/></ww:if>