<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="ItemList_catches" value="#PaymentReadOnly_payment.invoice.catches" />
<ww:include page="/Jsps/Invoice/Html/ItemList.jsp" />
<ww:set name="PaymentReadOnlyTotals_payment" value="#PaymentReadOnly_payment" />
<ww:include page="/Jsps/Payment/Html/ReadOnlyTotals.jsp" />
<br/><br/>
<table height="1" style="height: 1px; width: 100%;" cellpadding="0" cellspacing="0">
	<tr>
		<td valign="top">
			<ww:set name="ModuleHeader_title" value="'Shipping Address'" />
			<ww:include page="/Jsps/Utils/ModuleHeader.jsp" />
				<ww:set name="AddressInfo_address" value="#PaymentReadOnly_payment.address" />
				<ww:set name="AddressForm_includePhoneNumber" value="false" />
				<ww:include page="/Jsps/Address/Html/Info.jsp" />
			<ww:include page="/Jsps/Utils/ModuleFooter.jsp" />
		</td>
		<td valign="top">
			<ww:set name="ModuleHeader_title" value="'Billing Information'" />
			<ww:include page="/Jsps/Utils/ModuleHeader.jsp" />
				<ww:set name="CreditCardInfo_creditCard" value="#PaymentReadOnly_payment.creditCard" />
				<ww:include page="/Jsps/CreditCard/Html/Info.jsp" />
			<ww:include page="/Jsps/Utils/ModuleFooter.jsp" />
		</td>
	</tr>
	<ww:if test="@com.zeedive.util.StringUtil@isEmpty(#PaymentReadOnly_payment.message) == false">
		<tr>
			<td colspan="2">
				<ww:set name="ModuleHeader_title" value="'Message to Seller'" />
				<ww:include page="/Jsps/Utils/ModuleHeader.jsp" />
					<ww:property value="
						registry.htmlRenderer.renderAsText(registry.internationalizer.formatter.formatUserMessage(
							#PaymentReadOnly_payment.message))"/>
				<ww:include page="/Jsps/Utils/ModuleFooter.jsp" />
			</td>
		</tr>
	</ww:if>
</table>
