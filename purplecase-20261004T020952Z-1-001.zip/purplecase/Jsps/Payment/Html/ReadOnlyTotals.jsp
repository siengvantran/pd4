<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:include page="/Jsps/Utils/FormModuleBareHeader.jsp" />
<table class="FullWidth" cellpadding="0" cellspacing="0">
	<tr>
		<td style="font-size: 14px; padding-right: 20px; padding-bottom: 10px; text-align: right;" width="100%">
			Item Total:
		</td>
		<td style="text-align: right; font-size: 14px; padding-left: 6px; padding-right: 11px; padding-bottom: 10px;">
			<ww:property value="
				registry.internationalizer.formatter.formatPrice(
					#PaymentReadOnlyTotals_payment.invoice.catchesTotal)"/>
		</td>
	</tr>
	<tr>
        <td style="font-size: 14px; padding-right: 20px; padding-bottom: 10px; text-align: right;" width="100%">
			Shipping Total -  <ww:property value="
					registry.htmlRenderer.renderAsText(registry.internationalizer.formatter.formatShippingProvider(#PaymentReadOnlyTotals_payment.shippingOption.provider.displayName))"/><ww:if test="#PaymentReadOnlyTotals_payment.shippingInsurance == true">, Insured</ww:if>:
		</td>
        <td style="text-align: right; font-size: 14px; padding-left: 6px; padding-right: 11px; padding-bottom: 10px;">
			<ww:property value="
				registry.internationalizer.formatter.formatPrice(
					#PaymentReadOnlyTotals_payment.shippingTotal)"/>
		</td>
	</tr>
	<tr>
        <td style="font-size: 14px; padding-right: 20px; padding-bottom: 10px; text-align: right;" width="100%">
			Sales Tax:
		</td>
        <td style="text-align: right; font-size: 14px; padding-left: 6px; padding-right: 11px; padding-bottom: 10px;">
			<ww:property value="
				registry.internationalizer.formatter.formatPrice(
					#PaymentReadOnlyTotals_payment.salesTaxTotal)"/>
		</td>
	</tr>
	<ww:if test="@com.zeedive.util.NumberUtil@makeSafe(#PaymentReadOnlyTotals_payment.invoice.sellerCharges) != 0.0">
		<tr>
            <td style="font-size: 14px; padding-right: 20px; padding-bottom: 10px; text-align: right;" width="100%">
				Seller Charge:
			</td>
            <td style="text-align: right; font-size: 14px; padding-left: 6px; padding-right: 11px; padding-bottom: 10px;">
				<ww:property value="
					registry.internationalizer.formatter.formatPrice(
						#PaymentReadOnlyTotals_payment.invoice.sellerCharges)"/>
			</td>
		</tr>
	</ww:if>
    <ww:if test="#PaymentReadOnlyTotals_payment.hasCredit == true">
        <tr>
            <td style="font-size: 14px; padding-right: 20px; padding-bottom: 10px; text-align: right;" width="100%">
                DiveCash:
            </td>
            <td style="font-weight: bold; color: #44AA00; text-align: right; font-size: 14px; padding-left: 6px; padding-right: 11px; padding-bottom: 10px;">
                <ww:property value="
                    registry.internationalizer.formatter.formatPrice(
                        #PaymentReadOnlyTotals_payment.credit)"/>
            </td>
        </tr>
    </ww:if>
	<ww:if test="#PaymentReadOnlyTotals_allowTotalRefresh == true">
		<tr>
			<td>
				<table align="right" cellpadding="0" cellspacing="0">
					<tr>
						<td width="1" style="font-size: 14px; padding-right: 10px; padding-top: 10px; text-align: right;">
							<ww:component template="form-containerbegin.vm" />
								<ww:component template="button.vm" >
									<ww:param name="'align'" value="'left'" />
									<ww:param name="'nameValue'" value="'Refresh Totals'" />
									<ww:param 
										name="'onclick'" 
										value="
											'document.getElementById(&quot;command&quot;).value = &quot;REFRESH&quot;;
											validatedPayment.submit();
											return false;'" />
								</ww:component>
							<ww:component template="form-containerend.vm" />
						</td>
						<td width="1" style="font-size: 14px; padding-right: 20px; padding-top: 10px; text-align: right;">
							Total:
						</td>
					</tr>
				</table>
			</td>
            <td style="text-align: right; font-size: 14px; padding-left: 6px; padding-right: 11px; padding-top: 10px; font-weight: bold;">
				<ww:property value="
					registry.internationalizer.formatter.formatPrice(
						#PaymentReadOnlyTotals_payment.total)"/>
			</td>
		</tr>
	</ww:if>
	<ww:else>
		<tr>
			<td style="font-size: 14px; padding-right: 20px; padding-top: 10px; text-align: right;">
				Total:
			</td>
			<td style="text-align: right; font-size: 14px; padding-left: 6px; padding-right: 11px; padding-top: 10px; font-weight: bold;">
				<ww:property value="
					registry.internationalizer.formatter.formatPrice(
						#PaymentReadOnlyTotals_payment.total)"/>
			</td>
		</tr>
	</ww:else>
</table>
<ww:include page="/Jsps/Utils/FormModuleBareFooter.jsp" />