<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<div style="padding-left: 5px; padding-bottom: 30px;">
	<table cellpadding="0" cellspacing="0">
		<tr>
            <td style="font-size:12px; font-weight: bold;" valign="bottom">
				<ww:if test="#PaymentHeader_to">
                    Payment to&nbsp;
                    <ww:set name="PaymentHeader_user" value="#PaymentHeader_payment.toUser" />
				</ww:if>
				<ww:if test="#PaymentHeader_from">
					Payment from&nbsp;
					<ww:set name="PaymentHeader_user" value="#PaymentHeader_payment.fromUser" />
				</ww:if>
			</td>
            <td style="font-size:12px; font-weight: bold;" valign="bottom">
                <ww:property value="registry.htmlRenderer.renderAsText(registry.internationalizer.formatter.formatUsername(#PaymentHeader_user.username))" />
			</td>			
			<ww:if test="#PaymentHeader_payment.invoice.hasBeenSaved == true">
				<ww:if test="#PaymentHeader_payment.isPaid == true">
                    <td style="font-size:12px; font-weight: bold;" valign="bottom">
                        <ww:if test="#PaymentHeader_from == true || #PaymentHeader_to == true">&nbsp;-</ww:if>
                        Payment <ww:property value="registry.internationalizer.formatter.formatId(#PaymentHeader_payment.paymentId)"/>
					</td>
                    <td style="font-size:12px; font-weight: bold;" valign="bottom">
						&nbsp;- <span style="color: #448800; font-size:12px; font-weight: bold;">Paid <ww:property value="registry.internationalizer.formatter.formatSaleTime(#PaymentHeader_payment.creationTime)"/></span>
					</td>
				</ww:if>
				<ww:else>
                    <td style="font-size:12px; font-weight: bold;" valign="bottom">
                        <ww:if test="#PaymentHeader_from == true || #PaymentHeader_to == true">&nbsp;-</ww:if>
						Invoice <ww:property value="registry.internationalizer.formatter.formatId(#PaymentHeader_payment.invoice.invoiceId)"/>
					</td>
				</ww:else>
			</ww:if>			
		</tr>
	</table>
</div>
