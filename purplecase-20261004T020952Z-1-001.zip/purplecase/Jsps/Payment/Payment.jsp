<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="PageBegin_description" value="'Payment'" />
<ww:include page="/Jsps/Page/Begin.jsp" />
<ww:set name="ContactTitle_user" value="model.payment.toUser" />
<ww:set name="ContactTitle_text" value="'Pay'" />
<ww:include page="/Jsps/Contact/Title.jsp" />
<ww:set name="PaymentHeader_payment" value="model.payment" />
<ww:include page="/Jsps/Payment/Html/Header.jsp" />
<!--    REMOVED FOR GOOGLE BUY NOW BUTTONS
<form name="validatedPayment" action="<ww:property value="registry.linkGenerator.processPayment" />" method="POST">
-->
    <ww:include page="/Jsps/Utils/BackUrlHiddenField.jsp" />
	<ww:if test="user != null">
		<ww:hidden name="'userId'" value="user.userId"/>
	</ww:if>
	<ww:if test="invoice != null">
		<ww:hidden name="'invoiceId'" value="invoice.invoiceId"/>
	</ww:if>
	<ww:if test="catch != null">
		<ww:hidden name="'catchId'" value="catch.catchId"/>
		<ww:iterator value="catches" status="iteratorStatus">
			<ww:if test="validatedPayment.validatedPaymentCatches.idsForDomain.contains(top.catchId)" >
				<ww:hidden
					name="'validatedPayment.validatedPaymentCatches.ids'"
					value="top.catchId" />
			</ww:if>
		</ww:iterator>
	</ww:if>
	<div style="display: none;"><input type="text" id="validatedPayment.useAddressOnFile" name="validatedPayment.useAddressOnFile" value="<ww:property value="validatedPayment.useAddressOnFile"/>" /></div>
	<div style="display: none;"><input type="text" id="validatedPayment.useCreditCardOnFile" name="validatedPayment.useCreditCardOnFile" value="<ww:property value="validatedPayment.useCreditCardOnFile"/>" /></div>
	<div style="display: none;"><input type="text" id="command" name="command" value="PREVIEW" /></div>
	<ww:include page="/Jsps/Utils/FormModuleBareHeader.jsp" />
		<table class="FullWidth" cellpadding="0" cellspacing="0">
			<tr>
				<ww:if test="allowCatchSelection">
					<td class="TableTitleContainerLeft">&nbsp;</td>
					<td class="TableTitleContainerInside">&nbsp;</td>
				</ww:if>
				<ww:else>
					<td class="TableTitleContainerLeft">&nbsp;</td>
				</ww:else>
                <td class="TableTitleContainerInside">&nbsp;</td>
                <td class="TableTitleContainerInside">&nbsp;</td>
                <td class="TableTitleContainerInside">&nbsp;</td>
				<td class="TableTitleContainerInside">
					Quantity
				</td>
				<td class="TableTitleContainerRight" style="text-align:right; padding-right: 11px;">
					Price
				</td>
			</tr>
				<ww:iterator value="catches" status="iteratorStatus">
				<ww:set name="Payment_listRowClass" value="#iteratorStatus.odd ? 'BrowseResultDark' : 'BrowseResultLight'" />
				<tr class="<ww:property value="#Payment_listRowClass" />">
					<ww:if test="allowCatchSelection">
						<td width="1" class="BrowseResultLight">
							<div class="PaymentCheckBox">
								<ww:component template="form-containerbegin.vm" />
									<ww:checkbox
										name="'validatedPayment.validatedPaymentCatches.ids'"
										value="validatedPayment.validatedPaymentCatches.idsForDomain.contains(top.catchId)"
										fieldValue="top.catchId" />
								<ww:component template="form-containerend.vm" />
							</div>
						</td>
					</ww:if>
					<td width="1" class="PaymentThumbnail">
						<ww:set name="Thumbnail_type" value="'Micro'" />
						<ww:set name="Thumbnail_listing" value="top.listing" />
						<ww:set name="Thumbnail_readOnly" value="true" />
						<ww:include page="/Jsps/Picture/Thumbnail.jsp" />
					</td>
					<td class="BrowseResultTitle">
						<ww:property value="registry.htmlRenderer.renderAsText(registry.internationalizer.formatter.formatListingTitle(top.listing.title))" />
					</td>
                    <td>
                        <form action="https://checkout.google.com/cws/v2/Merchant/<ww:property value="registry.appProperties.developmentGoogleMerchantId"/>/checkoutForm" id="BB_BuyButtonForm" method="post" name="BB_BuyButtonForm">
                            <input name="item_name_1" type="hidden" value="<ww:property value="top.listing.title"/>"/>
                            <input name="item_description_1" type="hidden" value="<ww:property value="top.listing.description"/>"/>
                            <input name="item_quantity_1" type="hidden" value="<ww:property value="top.buyerCatch.quantityWon"/>"/>
                            <input name="item_price_1" type="hidden" value="<ww:property value="top.priceWithMaxShipping"/>"/>
                            <input name="item_currency_1" type="hidden" value="GBP"/>
                            <input name="_charset_" type="hidden" value="utf-8"/>
                            <input alt="" src="https://checkout.google.com/buttons/buy.gif?merchant_id=<ww:property value="registry.appProperties.developmentGoogleMerchantId"/>&amp;w=121&amp;h=44&amp;style=trans&amp;variant=text&amp;loc=en_US" type="image"/>
                        </form>
                    </td>
                    <td>
                        <form action="https://www.paypal.com/cgi-bin/webscr" method="post">
                            <input type="hidden" name="cmd" value="_xclick">
                            <input type="hidden" name="business" value="roger@pricedive.com">
                            <input type="hidden" name="item_name" value="<ww:property value="top.listing.title"/>">
                            <input type="hidden" name="item_number" value="<ww:property value="top.listing.listingId"/>">
                            <input type="hidden" name="amount" value="<ww:property value="top.price"/>">
                            <input type="hidden" name="shipping" value="<ww:property value="top.listing.maxPostage"/>">
                            <input type="hidden" name="no_shipping" value="0">
                            <input type="hidden" name="no_note" value="1">
                            <input type="hidden" name="currency_code" value="GBP">
                            <input type="hidden" name="lc" value="GB">
                            <input type="hidden" name="bn" value="PP-BuyNowBF">
                            <input type="hidden" name="return" value="<ww:property value="registry.linkGenerator.paymentSuccess"/>">                            <input type="image" src="https://www.paypal.com/en_GB/i/btn/btn_paynowCC_LG.gif" border="0" name="submit" alt="PayPal - The safer, easier way to pay online.">
                            <img alt="" border="0" src="https://www.paypal.com/en_GB/i/scr/pixel.gif" width="1" height="1">
                        </form>
                    </td>
                    <td class="PaymentQuantity">
						<ww:property value="registry.internationalizer.formatter.formatCount(top.buyerCatch.quantityWon)" />
					</td>
					<td class="PaymentPrice">
						<ww:property value="registry.internationalizer.formatter.formatPrice(top.price)" />
					</td>
				</tr>
			</ww:iterator>
		</table>	
		<ww:include page="/Jsps/Utils/PageNavigationEmpty.jsp" />
	<ww:include page="/Jsps/Utils/FormModuleBareFooter.jsp" />

<!-- removed for Google Buy Now Buttons (PART ONE)

	<ww:set name="FormModuleHeader_title" value="'Shipping Option'" />
	<ww:include page="/Jsps/Utils/FormModuleHeader.jsp" />
		<table class="FullWidth" cellpadding="0" cellspacing="0">
			<ww:iterator value="model.payment.invoice.shippingOptions" status="iteratorStatus">
				<tr>
					<td class="PaymentShippingSelector" width="1">
						<ww:if test="model.payment.invoice.shippingOptions.size() == 1">
							<ww:hidden 
								name="'validatedPayment.shippingOptionPosition'" 
								value="0" />
						</ww:if>
						<ww:else>
							<ww:component template="form-containerbegin.vm" />
								<ww:radio 
									id="PaymentShippingOptionCheckBox"
									value="validatedPayment.shippingOptionPositionForDomain"
									name="'validatedPayment.shippingOptionPosition'" 
									list="{ top }" 
									listKey="position" 
									listValue="null" />
							<ww:component template="form-containerend.vm" />
						</ww:else>
					</td>
					<td width="100%">
						<table class="FullWidth" cellpadding="0" cellspacing="0">
							<tr>
								<td width="1">
									<div class="PaymentShippingProvider">
										<ww:property value="
											registry.htmlRenderer.renderAsText(registry.internationalizer.formatter.formatShippingProvider(provider.displayName))"/>
										<span class="PaymentShippingProviderPrice">
												(<ww:property value="registry.internationalizer.formatter.formatPrice(top.rate)"/>)
										</span>
									</div>
								</td>
								<td width="100%">
									<div class="PaymentShippingProviderLine">&nbsp;</div>
								</td>
							</tr>
						</table>
					</td>
					<td class="PaymentShippingPrice" width="1">
						<ww:property value="
							registry.internationalizer.formatter.formatPrice(top.rate)"/>
					</td>
				</tr>
			</ww:iterator>
			<ww:set name="TableRowSpacer_height" value="10" />
            <ww:include page="/Jsps/Utils/TableRowSpacer.jsp" />
			
			<ww:if test="
				model.payment.invoice.shippingInsuranceType == @com.zeedive.domain.objects.ShippingInsuranceType@REQUIRED ||
				model.payment.invoice.shippingInsuranceType == @com.zeedive.domain.objects.ShippingInsuranceType@OPTIONAL">
				<tr>
					<td class="PaymentShippingSelector" width="1">
						<ww:if test="
							model.payment.invoice.shippingInsuranceType == @com.zeedive.domain.objects.ShippingInsuranceType@REQUIRED">
							<ww:hidden name="'validatedPayment.shippingInsurance'" value="'true'" />
						</ww:if>
						<ww:else>
							<ww:component template="form-containerbegin.vm" />
								<ww:checkbox
									id="PaymentShippingInsuranceCheckBox"
									name="'validatedPayment.shippingInsurance'" 
									fieldValue="'true'" />
							<ww:component template="form-containerend.vm" />
						</ww:else>
					</td>
					<td class="PaymentShippingProvider" width="100%">
						<table class="FullWidth" cellpadding="0" cellspacing="0">
							<tr>
								<td width="1">
									<div class="PaymentShippingProvider">
										Shipping Insurance
										<span class="PaymentShippingProviderPrice">
											(<ww:property value="
												registry.internationalizer.formatter.formatPrice(
													model.payment.invoice.shippingInsurancePrice)"/>)
										</span>
									</div>
								</td>
								<td width="100%">
									<div class="PaymentShippingProviderLine">&nbsp;</div>
								</td>
							</tr>
						</table>
					</td>
					<td class="PaymentShippingPrice" width="1">
						<ww:property value="
							registry.internationalizer.formatter.formatPrice(
								model.payment.invoice.shippingInsurancePrice)"/>
					</td>
				</tr>
			</ww:if>
			<ww:else>
				<ww:if test="
					model.payment.invoice.shippingInsuranceType == @com.zeedive.domain.objects.ShippingInsuranceType@INCLUDED">
					<ww:hidden name="'validatedPayment.shippingInsurance'" value="'true'" />
				</ww:if>
				<ww:else>
					<ww:hidden name="'validatedPayment.shippingInsurance'" value="'false'" />
				</ww:else>
			</ww:else>
		</table>
	<ww:include page="/Jsps/Utils/FormModuleFooter.jsp" />

    <br/><br/>
	<ww:set name="PaymentReadOnlyTotals_payment" value="model.payment" />
	<ww:set name="PaymentReadOnlyTotals_allowTotalRefresh" value="true" />
	<ww:include page="/Jsps/Payment/Html/ReadOnlyTotals.jsp" />
			
    <div style="display: none">
    <ww:if test="authenticationInfo.user.purchaseStatus == @com.zeedive.domain.objects.UserPurchaseStatus@NEVER_PURCHASED">
        <br/>
        <br/>
        <ww:set name="FormModuleHeader_title" value="'Referrer Discount Code'" />
        <ww:include page="/Jsps/Utils/FormModuleHeader.jsp" />
            <table class="FullWidth" cellpadding="0" cellspacing="0">
                <tr>
                    <td>
                        <ww:component template="form-containerbegin.vm" />
                            <ww:component template="form-rowbegin.vm" />
                                <ww:component template="form-cellbegin.vm" />
                                    <ww:textfield size="40" id="'validatedPayment.encodedReferrer'" name="'validatedPayment.encodedReferrer'" value="validatedPayment.encodedReferrer" />
                                <ww:component template="form-cellend.vm" />
                            <ww:component template="form-rowend.vm" />
                            <ww:component template="form-rowbegin.vm" />
                                <ww:set name="FormInlineHelpCell_message" value="'Leave blank if you do not have a referrer discount code.'" />
                                <ww:include page="/Jsps/Utils/FormInlineHelpCell.jsp" />
                            <ww:component template="form-rowend.vm" />
                        <ww:component template="form-containerend.vm" />
                    </td>
                </tr>
            </table>
        <ww:include page="/Jsps/Utils/FormModuleFooter.jsp" />
    </ww:if>
    </div>
   END OF REMOVED FOR GOOGLE BUY NOW BUTTONS (PART ONE) -->
    <ww:if test="@com.zeedive.util.StringUtil@isEmpty(model.payment.invoice.paymentInstructions) == false">
		<br />
		<br />
		<ww:set name="ModuleHeader_title" value="'Note From Seller'" />
		<ww:include page="/Jsps/Utils/ModuleHeader.jsp" />
			<div class="PaymentInstructions">
				<ww:property value="
					registry.htmlRenderer.renderAsText(registry.internationalizer.formatter.formatPaymentInstructions(
						model.payment.invoice.paymentInstructions))" />
			</div>
		<ww:include page="/Jsps/Utils/ModuleFooter.jsp" />
	</ww:if>

    <!-- removed for Google Buy Now Buttons (PART TWO)

    <div style="display: none">
	<ww:if test="validatedPayment.useAddressOnFileForDomain == true">
		<ww:set name="Payment_initialDisplayAddressOnFile" value="'block'" />
		<ww:set name="Payment_initialDisplayEnteredAddress" value="'none'" />
	</ww:if>
	<ww:else>
		<ww:set name="Payment_initialDisplayAddressOnFile" value="'none'" />
		<ww:set name="Payment_initialDisplayEnteredAddress" value="'block'" />
	</ww:else>
	<ww:set name="EditableBlockLink_formElementId" value="'validatedPayment.useAddressOnFile'" />
	<ww:set name="EditableBlockLink_readOnlyDivId" value="'PaymentAddressOnFile'" />
	<ww:set name="EditableBlockLink_formDivId" value="'PaymentEnteredAddress'" />
	<ww:set name="EditableBlockLink_changeHelpText" value="'Click this link to specify a different shipping address'" />
	<ww:set name="EditableBlockLink_cancelHelpText" value="'Click this link to discard your changes'" />
	<div id="PaymentAddressOnFile" style="display: <ww:property value="#Payment_initialDisplayAddressOnFile" />;">
		<br />
		<br />
		<ww:set name="ModuleHeader_title" value="'Shipping Address'" />
		<ww:include page="/Jsps/Utils/ModuleHeader.jsp" />
			<ww:set name="AddressInfo_address" value="authenticationInfo.user.address" />
			<ww:set name="AddressForm_includePhoneNumber" value="false" />
			<ww:include page="/Jsps/Address/Html/Info.jsp" />
			<ww:include page="/Jsps/Utils/EditableBlockLinkChange.jsp" />
		<ww:include page="/Jsps/Utils/ModuleFooter.jsp" />
	</div>		
	<div id="PaymentEnteredAddress" style="display: <ww:property value="#Payment_initialDisplayEnteredAddress" />;">
		<br/>
		<ww:set name="FormModuleHeader_title" value="'Shipping Address'" />
		<ww:set name="FormModuleHeader_showRequiredFieldsNotice" value="true" />
		<ww:include page="/Jsps/Utils/FormModuleHeader.jsp" />
			<ww:component template="form-containerbegin.vm" />
				<ww:set name="AddressForm_prefix" value="'validatedPayment'" />
				<ww:set name="AddressForm_includePhoneNumber" value="false" />
				<ww:include page="/Jsps/Address/Form.jsp" />
			<ww:component template="form-containerend.vm" />
            <br/><div class="PaymentShippingNotice"><ww:include page="/Jsps/Utils/DomesticShippingNotice.jsp" /></div>
            <ww:include page="/Jsps/Utils/EditableBlockLinkCancel.jsp" />
		<ww:include page="/Jsps/Utils/FormModuleFooter.jsp" />
	</div>		
	
	<ww:if test="validatedPayment.useCreditCardOnFileForDomain == true">
		<ww:set name="Payment_initialDisplayCreditCardOnFile" value="'block'" />
		<ww:set name="Payment_initialDisplayEnteredCreditCard" value="'none'" />
	</ww:if>
	<ww:else>
		<ww:set name="Payment_initialDisplayCreditCardOnFile" value="'none'" />
		<ww:set name="Payment_initialDisplayEnteredCreditCard" value="'block'" />
	</ww:else>
	<ww:set name="EditableBlockLink_formElementId" value="'validatedPayment.useCreditCardOnFile'" />
	<ww:set name="EditableBlockLink_readOnlyDivId" value="'PaymentCreditCardOnFile'" />
	<ww:set name="EditableBlockLink_formDivId" value="'PaymentEnteredCreditCard'" />
	<ww:set name="EditableBlockLink_changeHelpText" value="'Click this link to specify a different billing information'" />
	<ww:set name="EditableBlockLink_cancelHelpText" value="'Click this link to discard your changes'" />
	<div id="PaymentCreditCardOnFile" style="display: <ww:property value="#Payment_initialDisplayCreditCardOnFile" />;">
		<br />
		<br />
		<ww:set name="ModuleHeader_title" value="'Billing Information'" />
		<ww:include page="/Jsps/Utils/ModuleHeader.jsp" />
			<ww:set name="CreditCardInfo_creditCard" value="authenticationInfo.user.creditCard" />
			<ww:include page="/Jsps/CreditCard/Html/Info.jsp" />
			<ww:include page="/Jsps/Utils/EditableBlockLinkChange.jsp" />
		<ww:include page="/Jsps/Utils/ModuleFooter.jsp" />
	</div>		
	<div id="PaymentEnteredCreditCard" style="display: <ww:property value="#Payment_initialDisplayEnteredCreditCard" />;">
		<br/>
		<ww:set name="FormModuleHeader_title" value="'Billing Information'" />
		<ww:set name="FormModuleHeader_showRequiredFieldsNotice" value="true" />
		<ww:include page="/Jsps/Utils/FormModuleHeader.jsp" />
			<ww:component template="form-containerbegin.vm" />
				<ww:set name="CreditCardForm_prefix" value="'validatedPayment'" />
				<ww:set name="CreditCardForm_validated" value="validatedPayment" />
				<ww:include page="/Jsps/CreditCard/Form.jsp" />
			<ww:component template="form-containerend.vm" />
            <ww:if test="model.payment.isPaidInFullWithCredit">
                <br/><div class="PaymentBillingNotice">Even if you pay in full using your account credit, we require valid billing information to be entered.<br/>You credit card will NOT be charged.</div>
            </ww:if>
            <ww:if test="authenticationInfo.user.creditCard != null">
				<ww:include page="/Jsps/Utils/EditableBlockLinkCancel.jsp" />
			</ww:if>
			<ww:else>
				<br />
			</ww:else>
		<ww:include page="/Jsps/Utils/FormModuleFooter.jsp" />
	</div>		
	<br/>
	<ww:set name="FormModuleHeader_title" value="'Message to Seller'" />
	<ww:set name="FormModuleHeader_showRequiredFieldsNotice" value="false" />
	<ww:include page="/Jsps/Utils/FormModuleHeader.jsp" />
		<ww:component template="form-containerbegin.vm" />
			<ww:component template="form-rowbegin.vm" />
                <ww:textarea
                    labelposition="'top'"
                    cols="60"
                    rows="5"
                    label="@com.zeedive.validation.validated.ValidatedPayment@MESSAGE_LABEL"
                    name="'validatedPayment.message'"/>
			<ww:component template="form-rowend.vm" />
			<ww:component template="form-rowbegin.vm" />
				<ww:set name="FormInlineHelpCell_message" value="'Leave blank if no message'" />
				<ww:include page="/Jsps/Utils/FormInlineHelpCell.jsp" />
			<ww:component template="form-rowend.vm" />
		<ww:component template="form-containerend.vm" />
	<ww:include page="/Jsps/Utils/FormModuleFooter.jsp" />
	<ww:set name="FormSubmitFooter_submitButtonName" value="'Continue'" />
	<ww:set name="FormSubmitFooter_helpText" value="'Press \"Continue\" to see your order total and confirm your payment information'" />
	<ww:include page="/Jsps/Utils/FormSubmitFooter.jsp" />
    </div>
       END OF REMOVED FOR GOOGLE BUY NOW BUTTONS (PART ONE) -->
<!-- REMOVE THIS FORM FOR GOOGLE BUY NOW BUTTONS
</form>
-->
<ww:set name="End_backUrl" value="registry.linkGenerator.getProcessPayment().setBackUrl(backUrl)" />
<ww:include page="/Jsps/Page/End.jsp" />