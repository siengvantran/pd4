<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="PageBegin_description" value="'Unable To Process Payment'" />
<ww:include page="/Jsps/Page/Begin.jsp" />
<div class="PageTitleFailed">Unable To Process Payment</div>	
<div class="PageTitleTagLine">
	<span class="PaymentFailure">
		We are sorry, we were unable to process your payment of
		<span class="PaymentFailureImportant">
			<ww:property value="registry.internationalizer.formatter.formatPrice(model.payment.total)" /> 
		</span>		
		to
		<span class="PaymentFailureImportant">
			<ww:property value="registry.internationalizer.formatter.formatUsername(model.payment.toUser.username)" />.
		</span>
	</span>
	<br />
	<br />
	<br />
	This may be due to one of the following:
	<ul>
		<li class="PaymentFailureEntry">The credit card number, credit card verification code or expiration date specified in the payment information is incorrect</li>
		<li class="PaymentFailureEntry">The address where you receive your billing statement does not match the address specified in the billing information (this is normally your home address)</li>
	</ul>
	<br />
	<br />
	You may want to:
	<ul>
		<li class="PaymentFailureEntry">Press the "Edit Your Payment Information" button to edit and re-submit your payment</li>
		<li class="PaymentFailureEntry">Press the "Cancel Your Payment" button if you wish to pay at a later time</li>
	</ul>
	
</div>
<form name="validatedPayment" action="<ww:property value="registry.linkGenerator.processPayment" />" method="POST">
	<ww:include page="/Jsps/Utils/BackUrlHiddenField.jsp" />
	<ww:hidden name="'validatedPayment.validatedPaymentCatches.ids'" />
	<ww:if test="model.payment.invoice.shippingInsuranceType == @com.zeedive.domain.objects.ShippingInsuranceType@OPTIONAL">
		<ww:hidden name="'validatedPayment.shippingInsurance'"/>
	</ww:if>
	<ww:hidden name="'validatedPayment.shippingOptionPosition'"/>
	<ww:hidden name="'validatedPayment.useAddressOnFile'" />
	<ww:set name="AddressForm_prefix" value="'validatedPayment'" />
	<ww:set name="AddressForm_includePhoneNumber" value="false" />
	<ww:include page="/Jsps/Address/HiddenFields.jsp" />
	<ww:hidden name="'validatedPayment.useCreditCardOnFile'" />
	<ww:set name="CreditCardForm_prefix" value="'validatedPayment'" />
	<ww:include page="/Jsps/CreditCard/HiddenFields.jsp" />
	<ww:if test="user != null">
		<ww:hidden name="'userId'" value="user.userId"/>
	</ww:if>
	<ww:if test="invoice != null">
		<ww:hidden name="'invoiceId'" value="invoice.invoiceId"/>
	</ww:if>
	<ww:if test="catch != null">
		<ww:hidden name="'catchId'" value="catch.catchId"/>
		<ww:iterator value="catches" status="iteratorStatus">
			<ww:if test="validatedPayment.validatedPaymentCatches.idsForDomain.contains(top.catchId)" >
				<ww:hidden
					name="'validatedPayment.validatedPaymentCatches.ids'"
					value="top.catchId" />
			</ww:if>
		</ww:iterator>
	</ww:if>
	<ww:hidden name="'validatedPayment.message'"/>
	<div style="display: none;"><input type="text" id="command" name="command" value="EDIT" /></div>
	<ww:set name="FormSubmitFooter_submitButtonName" value="'Edit Your Payment Information'" />
	<ww:set name="FormSubmitFooter_cancelButtonOnClick" value="'document.getElementById(&quot;command&quot;).value = &quot;CANCEL&quot;; validatedPayment.submit(); return false;'" />
	<ww:set name="FormSubmitFooter_cancelButtonName" value="'Cancel Your Payment'" />
	<ww:include page="/Jsps/Utils/FormSubmitFooter.jsp" />
</form>
<ww:set name="End_backUrl" value="registry.linkGenerator.getProcessPayment().setBackUrl(backUrl)" />
<ww:include page="/Jsps/Page/End.jsp" />