<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="PageBegin_description" value="'Payment - Preview'" />
<ww:include page="/Jsps/Page/Begin.jsp" />
<ww:set name="ContactTitle_user" value="model.payment.toUser" />
<ww:set name="ContactTitle_text" value="'Preview Payment To '" />
<ww:include page="/Jsps/Contact/Title.jsp" />
<ww:set name="PaymentHeader_payment" value="model.payment" />
<ww:include page="/Jsps/Payment/Html/Header.jsp" />
<ww:set name="PaymentReadOnly_payment" value="model.payment" />
<ww:include page="Html/ReadOnly.jsp" />
<form name="validatedPayment" action="<ww:property value="registry.linkGenerator.processPayment" />" method="POST" onsubmit="disableForm(this)">
<ww:include page="/Jsps/Utils/BackUrlHiddenField.jsp" />
	<ww:if test="allowCatchSelection">
		<ww:iterator value="model.payment.invoice.catches" status="iteratorStatus">
			<ww:if test="validatedPayment.validatedPaymentCatches.idsForDomain.contains(top.catchId)" >
				<ww:hidden
					name="'validatedPayment.validatedPaymentCatches.ids'"
					value="top.catchId" />
			</ww:if>
		</ww:iterator>
	</ww:if>				
	<ww:if test="model.payment.invoice.shippingInsuranceType == @com.zeedive.domain.objects.ShippingInsuranceType@OPTIONAL">
		<ww:hidden name="'validatedPayment.shippingInsurance'"/>
	</ww:if>
	<ww:hidden name="'validatedPayment.shippingOptionPosition'"/>

	<ww:hidden name="'validatedPayment.useAddressOnFile'" />
	<ww:set name="AddressForm_prefix" value="'validatedPayment'" />
	<ww:set name="AddressForm_includePhoneNumber" value="false" />
	<ww:include page="/Jsps/Address/HiddenFields.jsp" />

	<ww:hidden name="'validatedPayment.useCreditCardOnFile'" />
	<ww:set name="CreditCardForm_prefix" value="'validatedPayment'" />
	<ww:include page="/Jsps/CreditCard/HiddenFields.jsp" />
	<ww:if test="user != null">
		<ww:hidden name="'userId'" value="user.userId"/>
	</ww:if>
	<ww:if test="invoice != null">
		<ww:hidden name="'invoiceId'" value="invoice.invoiceId"/>
	</ww:if>
	<ww:if test="catch != null">
		<ww:hidden name="'catchId'" value="catch.catchId"/>
		<ww:iterator value="catches" status="iteratorStatus">
			<ww:if test="validatedPayment.validatedPaymentCatches.idsForDomain.contains(top.catchId)" >
				<ww:hidden
					name="'validatedPayment.validatedPaymentCatches.ids'"
					value="top.catchId" />
			</ww:if>
		</ww:iterator>
	</ww:if>
    <ww:hidden name="'validatedPayment.encodedReferrer'" value="validatedPayment.encodedReferrer"/>
    <ww:hidden name="'validatedPayment.message'"/>
	<div style="display: none;"><input type="text" id="command" name="command" value="SEND" /></div>
	<br />
	<ww:set name="FormSubmitFooterBinding_linkId" value="'EditPaymentInformation'" />
	<ww:set name="FormSubmitFooterBinding_linkText" value="'Edit Your Payment Information'" />
	<ww:set name="FormSubmitFooterBinding_linkDestination" value="'#'" />
	<ww:set name="FormSubmitFooterBinding_linkOnClick" value="'document.getElementById(&#39;command&#39;).value = &#39;EDIT&#39;; validatedPayment.submit(); return false;'" />
	<ww:set name="FormSubmitFooterBinding_submitButtonName" value="'Send Payment'" />
	<ww:set name="FormSubmitFooterBinding_helpText" value="'If you like what you see, press \"Send Payment\" to submit your payment. Click \"Edit Your Payment Information\" If you wish to make any change to the information above.'" />
	<ww:include page="/Jsps/Utils/FormSubmitFooterBinding.jsp" />
    <p>&nbsp;</p>
</form>
<ww:set name="End_backUrl" value="registry.linkGenerator.getProcessPayment().setBackUrl(backUrl)" />
<ww:include page="/Jsps/Page/End.jsp" />
