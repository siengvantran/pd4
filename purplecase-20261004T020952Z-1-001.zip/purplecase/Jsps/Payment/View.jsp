<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="PageBegin_description" value="'Payment Details'" />
<ww:include page="/Jsps/Page/Begin.jsp" />
<div class="ModuleEmpty">
    <ww:set name="ContactTitle_user" value="payment.toUser" />
    <ww:set name="ContactTitle_text" value="'Paid To'" />
    <ww:include page="/Jsps/Contact/Title.jsp" />
	<ww:set name="PaymentHeader_payment" value="payment" />
	<ww:set name="PaymentHeader_to" value="true" />
	<ww:include page="Html/Header.jsp" />
</div>
<ww:set name="PaymentReadOnly_payment" value="payment" />
<ww:include page="Html/ReadOnly.jsp" />
<div class="ModuleEmpty">
	<ww:include page="/Jsps/Utils/FormModuleBareHeader.jsp" />
		<ww:form name="'form'" action="backUrl" method="'POST'">
			<ww:component template="form-containerbegin.vm" />
				<ww:submit name="'doSubmit'" align="left" value="'Continue'" />
			<ww:component template="form-containerend.vm" />
		</ww:form>
	<ww:include page="/Jsps/Utils/FormModuleBareFooter.jsp" />
</div>
<br />
<ww:set name="End_backUrl" value="registry.linkGenerator.getViewPayment(payment).setBackUrl(backUrl)" />
<ww:include page="/Jsps/Page/End.jsp" />
