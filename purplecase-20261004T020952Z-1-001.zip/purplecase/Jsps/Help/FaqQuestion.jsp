<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<tr>
    <td width="1" valign="top"><div class="FaqQuestionArrow"><img class="NoBorder" alt="" src="<ww:property value="registry.linkGenerator.forResource('Images/BulletArrow.gif')"/>" />&nbsp;</div></td>
    <td align="right" valign="top">
        <div class="FaqQuestionContent"><a href="#<ww:property value="#FaqQuestion_id" />"><ww:property value="#FaqQuestion_question" /></a></div>
    </td>
</tr>