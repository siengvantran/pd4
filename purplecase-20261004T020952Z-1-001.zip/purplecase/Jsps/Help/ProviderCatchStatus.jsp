<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="Icon_topic" value="'ProviderCatchStatus'" />
<ww:set name="Icon_width" value="350" />
<ww:set name="Icon_height" value="220" />
<ww:set name="Icon_resize" value="false" />
<ww:set name="Icon_textLink" value="#ProviderCatchStatus_textLink" />
<ww:include page="Icon.jsp" />