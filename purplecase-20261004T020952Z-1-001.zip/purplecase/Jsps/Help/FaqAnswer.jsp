<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<tr>
    <td>
        <a name="<ww:property value="#FaqAnswer_id" />">
        <table align="center" width="100%" cellpadding="0" cellspacing="0" border="0">
            <tr>
                <td width="1" valign="top"><div class="FaqAnswerArrow"><img class="NoBorder" alt="" src="<ww:property value="registry.linkGenerator.forResource('Images/BulletArrow.gif')"/>" />&nbsp;</div></td>
                <td align="right" valign="top">
                    <div class="FaqAnswerQuestion"><ww:property value="#FaqAnswer_question" /></div>
                </td>
            </tr>
            <tr>
                <td>&nbsp;</td>
                <td>
                    <div class="FaqAnswerAnswer"><ww:property value="#FaqAnswer_answer" /></div>
                </td>
            </tr>
        </table>
        </a>
    </td>
</tr>