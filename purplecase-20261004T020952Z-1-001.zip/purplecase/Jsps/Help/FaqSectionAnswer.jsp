<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<tr>
    <td>
        <div class="FaqSectionAnswerTitle"><ww:property value="#FaqSectionAnswer_title" /></div>
    </td>
</tr>