<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="Icon_topic" value="'StrongPassword'" />
<ww:set name="Icon_width" value="420" />
<ww:set name="Icon_height" value="590" />
<ww:set name="Icon_resize" value="false" />
<ww:set name="Icon_textLink" value="#StrongPassword_textLink" />
<ww:include page="Icon.jsp" />