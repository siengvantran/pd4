<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<tr>
    <td align="right" valign="top">
        <div class="GlossaryEntryTitle"><ww:property value="#GlossaryEntry_term" /></div>
    </td>
    <td valign="top"><div class="GlossaryEntryArrow"><img class="NoBorder" alt="" src="<ww:property value="registry.linkGenerator.forResource('Images/BulletArrow.gif')"/>" />&nbsp;</div></td>
    <td>
        <div class="GlossaryEntryContent"><ww:property value="#GlossaryEntry_content" /></div>
    </td>
</tr>