<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<tr>
    <td valign="top" align="right"><div style="padding-right: 20px;"><img class="NoBorder" alt="" src="<ww:property value="#DifferentDivesEntry_link"/>" /></div></td>
    <td valign="bottom">
        <span style="font-weight:bold; font-size: 14px;"><ww:property value="#DifferentDivesEntry_title"/></span>
    </td>
</tr>
<tr>
    <td>

    </td>
    <td>
        <div style="text-align: justify; padding-top: 10px;"><ww:property value="#DifferentDivesEntry_text"/></div>
    </td>
</tr>