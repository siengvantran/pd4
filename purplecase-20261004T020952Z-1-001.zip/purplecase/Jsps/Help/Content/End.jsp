<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
            <div class="FooterSeparatorHelp"><img src="<ww:property value="registry.linkGenerator.forResource('Images/Transparent.gif')"/>" width="1" height="1"/></div>
            <div class="HelpCloseWindow"><ww:include page="/Jsps/Utils/CloseWindowLink.jsp" /></div>
        </td>
    </tr>
</table>
</html>
