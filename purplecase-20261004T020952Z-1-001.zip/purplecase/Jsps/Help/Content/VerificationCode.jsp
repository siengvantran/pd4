<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="Begin_topic" value="'Credit Card Verification Code (CVV - CVV2)'" />
<ww:include page="Begin.jsp" />
    For your safety and security, our card processor requires that you enter your card verification number, if one is available. The verification number is a 3 or 4 digit number printed on your card.
    <br/><br/>
    If you are using a Visa or Mastercard it is a 3 digit number that appears to the right of your card number (see below).
    <br/><br/>
    <img src="<ww:property value="registry.linkGenerator.forResource('Images/CVV1.gif')" />" alt="" />
    <br/><br/>
    If you are using an American Express card, the verification number is a 4 digit number that appears on the front of your card, above and either on the left or right of the card number (see below).
    <br/><br/>
    <img src="<ww:property value="registry.linkGenerator.forResource('Images/CVV2.gif')" />" alt="" />
    <br/><br/>
    If your card does not have a verification number, try another card or enter the number 000.
<ww:include page="End.jsp" />