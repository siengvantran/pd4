<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<html>
<head> 
<ww:set name="Title_description" value="'Help'" />
<ww:include page="/Jsps/Utils/Title.jsp" />
<link href="<ww:property value="registry.linkGenerator.forResource('Css/Main.css')"/>" rel="stylesheet" type="text/css">
<style type="text/css">
	<ww:include page="/Jsps/Css/Main.jsp" />
</style>
<script language="javascript" src="<ww:property value="registry.linkGenerator.javascript" />" ></script>
</head> 
<body>
<table class="FullWidth" cellpadding="0" cellspacing="0">
    <tr>
        <td>
            <div class="HelpTopicTitle"><ww:property value="#Begin_topic" /></div>
            <div class="HeaderSeparatorHelp"><img src="<ww:property value="registry.linkGenerator.forResource('Images/Transparent.gif')"/>" width="1" height="1"/></div>