<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="Begin_topic" value="'Item Status'" />
<ww:include page="Begin.jsp" />
<table cellpadding="1" cellspacing="0">
	<tr>
		<td><img src="<ww:property value="registry.linkGenerator.forResource('Images/StatusInvoicedActive.gif')"/>" alt="" /></td>	
		<td style="white-space:nowrap;">
			&nbsp;&nbsp;Invoice for this item has been sent
		</td>
	</tr>
	<tr>
		<td><img src="<ww:property value="registry.linkGenerator.forResource('Images/StatusInvoicedInactive.gif')"/>" alt="" /></td>	
        <td style="white-space:nowrap;">
			&nbsp;&nbsp;Invoice for this item has not been sent yet
		</td>
	</tr>
	<tr><td><img src="<ww:property value="registry.linkGenerator.forResource('Images/Transparent.gif')"/>" height="8" /></td></tr>
	<tr>
		<td><img src="<ww:property value="registry.linkGenerator.forResource('Images/StatusPaidActive.gif')"/>" alt="" /></td>	
        <td style="white-space:nowrap;">
			&nbsp;&nbsp;Item has been paid for
		</td>
	</tr>
	<tr>
		<td><img src="<ww:property value="registry.linkGenerator.forResource('Images/StatusPaidInactive.gif')"/>" alt="" /></td>	
        <td style="white-space:nowrap;">
			&nbsp;&nbsp;Item has not been paid for yet
		</td>
	</tr>
	<tr><td><img src="<ww:property value="registry.linkGenerator.forResource('Images/Transparent.gif')"/>" height="8" /></td></tr>
	<tr>
		<td><img src="<ww:property value="registry.linkGenerator.forResource('Images/StatusShippedActive.gif')"/>" alt="" /></td>	
        <td style="white-space:nowrap;">
			&nbsp;&nbsp;Item has been shipped
		</td>
	</tr>
	<tr>
		<td><img src="<ww:property value="registry.linkGenerator.forResource('Images/StatusShippedInactive.gif')"/>" alt="" /></td>	
        <td style="white-space:nowrap;">
			&nbsp;&nbsp;Item has not been shipped yet
		</td>
	</tr>
</table>
<ww:set name="End_backUrl" value="#BuyerCatchStatus_backUrl" />
<ww:include page="End.jsp" />
