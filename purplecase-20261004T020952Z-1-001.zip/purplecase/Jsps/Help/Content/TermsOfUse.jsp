<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="Begin_topic" value="'PriceDive Terms of Use'" />
<ww:include page="Begin.jsp" />
<ww:include page="/Jsps/Legal/TermsOfUseContent.jsp" />
<ww:include page="End.jsp" />