<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<tr>
    <td width="1" valign="top"><div class="FaqQuestionArrow"><img class="NoBorder" alt="" src="<ww:property value="registry.linkGenerator.forResource('Images/BulletArrow.gif')"/>" />&nbsp;</div></td>
    <td align="justify" valign="top">
        <ww:property value="#StrongPasswordEntry_content" />
    </td>
</tr>