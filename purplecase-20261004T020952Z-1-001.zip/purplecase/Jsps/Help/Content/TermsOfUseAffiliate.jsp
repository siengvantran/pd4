<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="Begin_topic" value="'PriceDive Affiliate Terms of Use'" />
<ww:include page="Begin.jsp" />
<ww:include page="/Jsps/Legal/TermsOfUseAffiliateContent.jsp" />
<ww:include page="End.jsp" />