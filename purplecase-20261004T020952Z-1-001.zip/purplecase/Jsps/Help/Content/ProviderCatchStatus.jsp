<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="Begin_topic" value="'Item Status'" />
<ww:include page="Begin.jsp" />
<table cellpadding="1" cellspacing="0">
	<tr>
		<td><img src="<ww:property value="registry.linkGenerator.forResource('Images/StatusReadyActive.gif')"/>" alt="" /></td>
		<td style="white-space:nowrap;">
			&nbsp;&nbsp;Order is confirmed
		</td>
	</tr>
	<tr>
		<td><img src="<ww:property value="registry.linkGenerator.forResource('Images/StatusReadyInactive.gif')"/>" alt="" /></td>
        <td style="white-space:nowrap;">
			&nbsp;&nbsp;Order is on hold
		</td>
	</tr>
	<tr><td><img src="<ww:property value="registry.linkGenerator.forResource('Images/Transparent.gif')"/>" height="8" /></td></tr>
	<tr>
		<td><img src="<ww:property value="registry.linkGenerator.forResource('Images/StatusShippedActive.gif')"/>" alt="" /></td>	
        <td style="white-space:nowrap;">
			&nbsp;&nbsp;Item has been shipped
		</td>
	</tr>
	<tr>
		<td><img src="<ww:property value="registry.linkGenerator.forResource('Images/StatusShippedInactive.gif')"/>" alt="" /></td>	
        <td style="white-space:nowrap;">
			&nbsp;&nbsp;Item has not been shipped yet
		</td>
	</tr>
</table>
<ww:set name="End_backUrl" value="#ProviderCatchStatus_backUrl" />
<ww:include page="End.jsp" />
