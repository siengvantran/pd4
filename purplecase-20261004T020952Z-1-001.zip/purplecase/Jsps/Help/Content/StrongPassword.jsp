<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="Begin_topic" value="'Tips for Building Strong Passwords'" />
<ww:include page="Begin.jsp" />
<b>Strong passwords:</b><br/><br/>
<table>
    <ww:set
        name="StrongPasswordEntry_content"
        value="'Have both upper and lower case letters.'" />
    <ww:include page="/Jsps/Help/Content/StrongPasswordEntry.jsp" />
    <ww:set
        name="StrongPasswordEntry_content"
        value="'Have digits and/or punctuation characters in addition to letters.'" />
    <ww:include page="/Jsps/Help/Content/StrongPasswordEntry.jsp" />
    <ww:set
        name="StrongPasswordEntry_content"
        value="'Are easy to remember, so they do not have to be written down.'" />
    <ww:include page="/Jsps/Help/Content/StrongPasswordEntry.jsp" />
    <ww:set
        name="StrongPasswordEntry_content"
        value="'Are as long as possible. The longer the password, the more difficult it is to guess.'" />
    <ww:include page="/Jsps/Help/Content/StrongPasswordEntry.jsp" />
    <ww:set
        name="StrongPasswordEntry_content"
        value="'Can be typed quickly, so someone else cannot look over your shoulder and learn it.'" />
    <ww:include page="/Jsps/Help/Content/StrongPasswordEntry.jsp" />
</table>
<br/>
<b>You might also try using phrases for strong passwords, for example:</b><br/><br/>
<table>
    <ww:set
        name="StrongPasswordEntry_content"
        value="'rsKf0myH - Raindrops keep falling on my head.'" />
    <ww:include page="/Jsps/Help/Content/StrongPasswordEntry.jsp" />
    <ww:set
        name="StrongPasswordEntry_content"
        value="'wru2rxy? - Who are you to ask why.'" />
    <ww:include page="/Jsps/Help/Content/StrongPasswordEntry.jsp" />
    <ww:set
        name="StrongPasswordEntry_content"
        value="'bWiIso3! - Beware the ides of March!'" />
    <ww:include page="/Jsps/Help/Content/StrongPasswordEntry.jsp" />
</table>
<br/>
<b>A strong password is not:</b><br/><br/>
<table>
    <ww:set
        name="StrongPasswordEntry_content"
        value="'Personal information such as a name, phone number, social security number, birth date or address.'" />
    <ww:include page="/Jsps/Help/Content/StrongPasswordEntry.jsp" />
    <ww:set
        name="StrongPasswordEntry_content"
        value="'Any word in the dictionary, or based closely on such a word (such as a word spelled backwards).'" />
    <ww:include page="/Jsps/Help/Content/StrongPasswordEntry.jsp" />
    <ww:set
        name="StrongPasswordEntry_content"
        value="'A word with letters simply replaced by digits. For example, bl0wf1sh is not a strong password.'" />
    <ww:include page="/Jsps/Help/Content/StrongPasswordEntry.jsp" />
    <ww:set
        name="StrongPasswordEntry_content"
        value="'Easy to spot while you&#39;re typing them in. Passwords like 12345, qwerty (i.e., all keys right next to each other), or nnnnnn should be avoided.'" />
    <ww:include page="/Jsps/Help/Content/StrongPasswordEntry.jsp" />
</table>
<ww:include page="End.jsp" />