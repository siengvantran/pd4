<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %><ww:if test="#Icon_textLink != null"><a
	href="#"
    id="Help<ww:property value="#Icon_topic" />"
    onclick="
		return helpPopup(
		'<ww:property value="registry.linkGenerator.getHelp(#Icon_topic)"/>',
		<ww:property value="#Icon_width" />,
		<ww:property value="#Icon_height" />,
		<ww:property value="#Icon_resize" />);"><ww:property value="#Icon_textLink" /></a></ww:if><ww:else><a
	href="#" 
    id="Help<ww:property value="#Icon_topic" />"
	onclick="
		return helpPopup(
		'<ww:property value="registry.linkGenerator.getHelp(#Icon_topic)"/>',
		<ww:property value="#Icon_width" />,
		<ww:property value="#Icon_height" />,
		<ww:property value="#Icon_resize" />);"><img class="NoBorder" src="<ww:property value="registry.linkGenerator.forResource('Images/Help.gif')"/>" alt="" /></a></ww:else>