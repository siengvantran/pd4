<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<tr>
    <td colspan="2">
        <div class="FaqSectionQuestionTitle"><ww:property value="#FaqSectionQuestionBegin_title" /></div>
    </td>
</tr>