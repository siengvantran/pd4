<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<table cellpadding="0" cellspacing="0">
    <tr>
        <td valign="bottom" class="PageTitle">
            <ww:if test="#ContactTitle_text != null">
                <ww:property value="#ContactTitle_text" />
            </ww:if>
            <ww:else>Contact</ww:else>
            <ww:property value="registry.htmlRenderer.renderAsText(registry.internationalizer.formatter.formatUsername(#ContactTitle_user.username))" />
        </td>
        <ww:if test="#ContactTitle_user.isSeller">
            <td class="PageTitle" style="padding-left:10px;">
                <ww:set name="SellerAvatar_size" value="'Small'" />
                <ww:set name="SellerAvatar_user" value="#ContactTitle_user" />
                <ww:set name="SellerAvatar_readOnly" value="true" />
                <ww:include page="/Jsps/Seller/Avatar.jsp" />
            </td>
        </ww:if>
    </tr>
</table>