<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="ContactCustomerService_backUrl" value="registry.linkGenerator.getContactCustomerService().setBackUrl(backUrl)" />
<ww:set name="PageBegin_description" value="'Contact Customer Service'" />
<ww:include page="/Jsps/Page/Begin.jsp" />
<ww:include page="/Jsps/Help/QuickLinks/Begin.jsp"/>
	<div class="PageTitle">Contact PriceDive Customer Service</div>
    <div class="PageTitleTagLine">A representative will reply to your message shortly to the email address listed in your <a id="TagLineMyAccount" href="<ww:property value="registry.linkGenerator.myAccount.setBackUrl(registry.linkGenerator.contactCustomerService.setBackUrl(backUrl))"/>" >account</a>.</div>
	<form name="validatedMessage" action="<ww:property value="registry.linkGenerator.processContactCustomerService" />" method="POST" onsubmit="disableForm(this)">
		<ww:set name="FormModuleHeader_title" value="'Enter Your Message'" />
		<ww:set name="FormModuleHeader_showRequiredFieldsNotice" value="true" />
		<ww:include page="/Jsps/Utils/FormModuleHeader.jsp" />
			<ww:component template="form-containerbegin.vm" />
				<ww:include page="/Jsps/Utils/BackUrlHiddenField.jsp" />
					<ww:component template="form-rowbegin.vm" />
						<ww:component template="form-cellbegin.vm" />
							<ww:textarea
                                required="true"
								labelposition="'top'" 
								cols="58"
								rows="10"
								label="@com.zeedive.validation.validated.ValidatedMessage@MESSAGE_LABEL" 
								name="'validatedMessage.message'"/>
						<ww:component template="form-cellend.vm" />
					<ww:component template="form-rowend.vm" />
			<ww:component template="form-containerend.vm" />
		<ww:include page="/Jsps/Utils/FormModuleFooter.jsp" />
		<ww:set name="FormSubmitFooter_submitButtonName" value="'Send Message'" />
        <ww:set name="FormSubmitFooter_noBottomPadding" value="true" />
        <ww:include page="/Jsps/Utils/FormSubmitFooter.jsp" />
	</form>
<ww:include page="/Jsps/Help/QuickLinks/End.jsp"/>
<p>&nbsp;</p>
<ww:set name="End_backUrl" value="#ContactCustomerService_backUrl" />
<ww:include page="/Jsps/Page/End.jsp" />
