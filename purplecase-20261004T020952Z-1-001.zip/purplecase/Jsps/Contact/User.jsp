<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="ContactUser_backUrl" value="registry.linkGenerator.getContactUser(user, listing).setBackUrl(backUrl)" />
<ww:set name="ContactUser_username" value="registry.htmlRenderer.renderAsText(registry.internationalizer.formatter.formatUsername(user.username))" />
<ww:set name="PageBegin_description" value="'Contact ' + #ContactUser_username" />
<ww:include page="/Jsps/Page/Begin.jsp" />
    <ww:set name="ContactTitle_user" value="user" />
    <ww:include page="/Jsps/Contact/Title.jsp" />
    <ww:if test="listing != null">
        <div class="DetailedListingInformationContainer">
            <ww:set name="DetailedListingInformation_listing" value="listing" />
            <ww:set name="DetailedListingInformation_showListingLinks" value="true" />
            <ww:set name="DetailedListingInformation_showCatchHistoryLink" value="false" />
            <ww:set name="DetailedListingInformation_showCatchButton" value="false" />
            <ww:include page="/Jsps/Listing/DetailedInformation.jsp" />
        </div>
    </ww:if>
	<form name="validatedMessage" action="<ww:property value="registry.linkGenerator.processContactUser" />" method="POST" onsubmit="disableForm(this)">
		<ww:set name="FormModuleHeader_title" value="'Enter Your Message'" />
		<ww:set name="FormModuleHeader_showRequiredFieldsNotice" value="true" />
		<ww:include page="/Jsps/Utils/FormModuleHeader.jsp" />
			<ww:component template="form-containerbegin.vm" />
				<ww:include page="/Jsps/Utils/BackUrlHiddenField.jsp" />
				<ww:hidden name="'userId'" value="user.userId" />
				<ww:hidden name="'listingId'" value="listing.listingId" />
					<ww:component template="form-rowbegin.vm" />
						<ww:component template="form-cellbegin.vm" />
							<ww:textarea 
								required="true" 
								labelposition="'top'" 
								cols="80"
								rows="10" 
								label="@com.zeedive.validation.validated.ValidatedMessage@MESSAGE_LABEL" 
								name="'validatedMessage.message'"/>
						<ww:component template="form-cellend.vm" />
					<ww:component template="form-rowend.vm" />
			<ww:component template="form-containerend.vm" />
		<ww:include page="/Jsps/Utils/FormModuleFooter.jsp" />
		<ww:set name="FormSubmitFooter_submitButtonName" value="'Send Message'" />
		<ww:include page="/Jsps/Utils/FormSubmitFooter.jsp" />
	</form>
<ww:set name="End_backUrl" value="#ContactUser_backUrl" />
<ww:include page="/Jsps/Page/End.jsp" />
