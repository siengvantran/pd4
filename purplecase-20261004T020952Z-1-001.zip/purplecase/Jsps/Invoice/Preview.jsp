<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<html>
<head> 
<ww:set name="Title_description" value="'invoice preview'" />
<ww:include page="/Jsps/Utils/Title.jsp" />
<link href="Css/Main.css" rel="stylesheet" type="text/css">
</head> 
<body class="mainfont"> 
<ww:include page="/Jsps/Utils/Header.jsp" />

<p>invoice preview</p>

<ww:set name="InvoiceReadOnly_invoice" value="model.invoice" />
<ww:include page="/Jsps/Invoice/Html/ReadOnly.jsp" />
	
<ww:form name="'validatedInvoice'" action="registry.linkGenerator.processInvoice" method="'POST'">
	<ww:iterator value="model.catches" status="iteratorStatus">
	<ww:set name="Invoice_listing" value="top.listing" />
		<ww:if test="validatedInvoice.validatedInvoiceCatches.idsForDomain.contains(top.catchId)" >
			<ww:hidden
				name="'validatedInvoice.validatedInvoiceCatches.ids'"
				value="top.catchId" />
		</ww:if>
	</ww:iterator>
	<ww:hidden name="'userId'" value="user.userId" />
	<ww:hidden name="'validatedInvoice.shippingInsuranceType'" />
	<ww:hidden name="'validatedInvoice.shippingInsurancePrice'" />
	<ww:hidden name="'validatedInvoice.salesTaxRegion'" />
	<ww:hidden name="'validatedInvoice.salesTaxRate'" />
	<ww:hidden name="'validatedInvoice.applySalesTaxToShipping'" value="validatedInvoice.applySalesTaxToShippingForDomain.booleanValue" />
    <!--BLK--><!--NR-->
    <ww:hidden name="'validatedInvoice.paymentInstructions'" />
    <ww:hidden name="'validatedInvoice.shippingInstructions'" />
    <!--BLK-->
	<ww:hidden name="'validatedInvoice.sellerCharges'" />
	<ww:set name="HiddenFieldsShippingOptions_validatedShippingOptions" value="validatedInvoice.validatedShippingOptions" />
	<ww:include page="/Jsps/CreateListing/HiddenFieldsShippingOptions.jsp" />
	<div style="display: none;"><input type="text" id="command" name="command" value="SEND" /></div>
	<a 
		href="#" 
		onclick="
			document.getElementById('command').value = 'EDIT';
			validatedInvoice.submit();
			return false;">
		Edit invoice
	</a>
	<ww:submit name="'doSubmit'" align="left" value="'Send Invoice'" />
</ww:form>

	
<ww:include page="/Jsps/Utils/Footer.jsp" />
<ww:include page="/Jsps/Utils/BodyEnd.jsp" /> 
</html>