<%@ taglib uri="webwork" prefix="ww" %><ww:set name="ItemList_showItemsTotal" value="false" /><ww:set name="ItemList_catches" value="#InvoiceReadOnly_invoice.catches" /><ww:set name="ItemList_itemsTotal" value="#InvoiceReadOnly_invoice.catchesTotal" /><ww:include page="/Jsps/Invoice/Text/ItemList.jsp" /><ww:if test="@com.zeedive.util.StringUtil@isEmpty(#InvoiceReadOnly_invoice.paymentInstructions) == false">

	
Note from the Seller:

<ww:property value="registry.internationalizer.formatter.formatPaymentInstructions(#InvoiceReadOnly_invoice.paymentInstructions)" /></ww:if>