<%@ taglib uri="webwork" prefix="ww" %>
Items:

<ww:iterator value="#ItemList_catches" status="iteratorStatus"><ww:property value="registry.internationalizer.formatter.formatListingTitle(top.listing.title)" /> - Quantity: <ww:property value="registry.internationalizer.formatter.formatCount(top.buyerCatch.quantityWon)" /> - Price: <ww:property value="registry.internationalizer.formatter.formatPrice(top.price)" />
</ww:iterator><ww:if test="#ItemList_showItemsTotal == true">
Item Total: <ww:property value="registry.internationalizer.formatter.formatPrice(#ItemList_itemsTotal)"/></ww:if>