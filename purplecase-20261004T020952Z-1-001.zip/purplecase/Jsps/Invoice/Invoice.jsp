<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<html>
<head> 
<ww:set name="Title_description" value="'invoice'" />
<ww:include page="/Jsps/Utils/Title.jsp" />
<link href="Css/Main.css" rel="stylesheet" type="text/css">
</head> 
<body class="mainfont"> 
<ww:include page="/Jsps/Utils/Header.jsp" />

<p>invoice</p>

<ww:property value="model.toUser.username"/><br>

<ww:set name="Invoice_shippingOptionType" value="model.fromUser.address.country.shippingOptionType" />
<ww:property value="#Invoice_shippingOptionType.displayName"/><br>

<ww:form name="'validatedInvoice'" action="registry.linkGenerator.processInvoice" method="'POST'">
<div style="display: none;"><input type="text" id="command" name="command" value="SEND" /></div>
<a 
	href="#" 
	onclick="
		document.getElementById('command').value = 'REFRESH';
		validatedInvoice.submit();
		return false;">
	Refresh Totals
</a>

<table border="1">
	<ww:iterator value="model.catches" status="iteratorStatus">
	<ww:set name="Invoice_listing" value="top.listing" />
		<tr>
			<ww:component template="form-cellbegin.vm" />
				<ww:checkbox
					name="'validatedInvoice.validatedInvoiceCatches.ids'"
					value="validatedInvoice.validatedInvoiceCatches.idsForDomain.contains(top.catchId)"
					fieldValue="top.catchId" />
			<ww:component template="form-cellend.vm" />
			<td>
				<ww:property value="registry.htmlRenderer.renderAsText(registry.internationalizer.formatter.formatListingTitle(#Invoice_listing.title))"/><br>
			</td>
			<td>
				<ww:property value="
					registry.internationalizer.formatter.formatPrice(
					top.price)"/>
			</td>
		</tr>
	</ww:iterator>
</table>
<p>
	Item Total: <ww:property value="
		registry.internationalizer.formatter.formatPrice(
		model.invoice.catchesTotal)"/><br>
	
	<table>
		<ww:iterator value="model.invoice.shippingOptions" status="iteratorStatus">
			<tr>
				<td>
					Total for shipping option: 
					<ww:property value="
						registry.internationalizer.formatter.formatPrice(model.invoice.computeTotalForShippingOption(top))"/>
				</td>
			</tr>
		</ww:iterator>
	</table>	
	
</p>
<p>
		<ww:hidden name="'userId'" value="user.userId"/>

		<ww:set name="ShippingOptions_formName" value="'validatedInvoice'" />
		<ww:set name="ShippingOptions_validatedShippingOptions" value="validatedInvoice.validatedShippingOptions" />
		<ww:set name="ShippingOptions_currentStepIndex" value="-1" />
		<ww:set name="ShippingOptions_shippingOptionType" value="#Invoice_shippingOptionType" />
		
		<ww:include page="/Jsps/CreateListing/ShippingOptions.jsp" />

		<ww:component template="form-rowbegin.vm" />
			<ww:component template="form-cellbegin.vm" />
				<ww:select 
					label="'Shipping Insurance'" 
					name="'validatedInvoice.shippingInsuranceType'"
					list="@com.zeedive.domain.objects.ShippingInsuranceType@values()" 
					listValue="displayName"
					size="1"/>
			<ww:component template="form-cellend.vm" />
			<ww:component template="form-cellbegin.vm" />
				<ww:textfield size="7" label="'Price'" name="'validatedInvoice.shippingInsurancePrice'" />
			<ww:component template="form-cellend.vm" />
		<ww:component template="form-rowend.vm" />
	
		<ww:component template="form-rowbegin.vm" />
			<ww:component template="form-cellbegin.vm" />
				<ww:select 
					label="'Region'" 
					name="'validatedInvoice.salesTaxRegion'"
					list="@com.zeedive.domain.objects.SalesTaxRegion@values()" 
					listValue="displayName" 
					size="1"/>
			<ww:component template="form-cellend.vm" />
			<ww:component template="form-cellbegin.vm" />
				<ww:textfield label="'Rate'" size="7" name="'validatedInvoice.salesTaxRate'" />
			<ww:component template="form-cellend.vm" />
		<ww:component template="form-rowend.vm" />
		<ww:component template="form-rowbegin.vm" />
			<ww:component template="form-cellbegin.vm" />
				<ww:checkbox
					name="'validatedInvoice.applySalesTaxToShipping'"
					fieldValue="'true'"/>
			<ww:component template="form-cellend.vm" />
		<ww:component template="form-rowend.vm" />

		<ww:component template="form-rowbegin.vm" />
			<ww:component template="form-cellbegin.vm" />
				<!--BLK--><!--NR--><ww:textarea cols="40" rows="5" labelposition="'top'" label="'Payment Instructions'" name="'validatedInvoice.paymentInstructions'" /><!--BLK-->
			<ww:component template="form-cellend.vm" />
		<ww:component template="form-rowend.vm" />
			
		<ww:component template="form-rowbegin.vm" />
			<ww:component template="form-cellbegin.vm" />
				<!--BLK--><!--NR--><ww:textarea cols="40" rows="5" labelposition="'top'" label="'Shipping Instructions'" name="'validatedInvoice.shippingInstructions'" value="'DO NOT USE'" /><!--BLK-->
			<ww:component template="form-cellend.vm" />
		<ww:component template="form-rowend.vm" />

		<ww:component template="form-rowbegin.vm" />
			<ww:component template="form-cellbegin.vm" />
				<ww:textfield label="'Seller Charges'" size="7" name="'validatedInvoice.sellerCharges'" />
			<ww:component template="form-cellend.vm" />
		<ww:component template="form-rowend.vm" />

		<p>
			<a 
				href="#" 
				onclick="
					document.getElementById('command').value = 'PREVIEW';
					validatedInvoice.submit();
					return false;">
				Preview invoice
			</a>
			<ww:submit name="'doSubmit'" align="left" value="'Send Invoice'" />
		</p>
	</ww:form>
</p>

	
<ww:include page="/Jsps/Utils/Footer.jsp" />
<ww:include page="/Jsps/Utils/BodyEnd.jsp" /> 
</html>