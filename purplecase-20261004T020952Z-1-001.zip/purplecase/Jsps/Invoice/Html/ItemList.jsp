<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:include page="/Jsps/Utils/FormModuleBareHeader.jsp" />
	<table width="100%" cellpadding="0" cellspacing="0">
		<tr>
			<td style="
        			border-left: 1px solid #CCCCCC; border-top: 1px solid #CCCCCC; border-bottom: 1px solid #CCCCCC;
        			font-size:12px; padding-left: 6px; padding-right: 6px; padding-top: 10px; padding-bottom: 10px;">&nbsp;</td>
			<td style="
                    border-top: 1px solid #CCCCCC; border-bottom: 1px solid #CCCCCC;
                    font-size:12px; padding-left: 6px; padding-right: 6px; padding-top: 10px; padding-bottom: 10px;">&nbsp;</td>
			<td style="
			        border-top: 1px solid #CCCCCC; border-bottom: 1px solid #CCCCCC; vertical-align: bottom;
	                padding-left: 6px; padding-right: 6px; padding-top: 10px; padding-bottom: 10px; text-align: center;
	                font-size:12px; white-space: nowrap; font-weight: bold;">Quantity</td>
			<td style="
                border-right: 1px solid #CCCCCC; border-top: 1px solid #CCCCCC; border-bottom: 1px solid #CCCCCC;
                vertical-align: bottom; padding-left: 6px; padding-right: 11px; padding-top: 10px; padding-bottom: 10px;
                font-size:12px; text-align:right; white-space: nowrap; font-weight: bold;">Price</td>
		</tr>
            <ww:iterator value="#ItemList_catches" status="iteratorStatus">
			<ww:set name="PaymentReadOnly_listRowStyle" value="#iteratorStatus.odd ? 'background-color: #FFF5EC;' : 'background-color: #FFFFFF;'" />
			<tr style="<ww:property value="#PaymentReadOnly_listRowStyle" />">
				<td width="1" style="padding-top: 10px; padding-bottom: 10px; padding-left: 6px; padding-right: 15px; background-color: #FFFFFF;">
					<ww:set name="Thumbnail_type" value="'Micro'" />
					<ww:set name="Thumbnail_listing" value="top.listing" />
					<ww:set name="Thumbnail_readOnly" value="true" />
					<ww:include page="/Jsps/Picture/Thumbnail.jsp" />
				</td>
				<td style="font-size:12px; padding: 6px; text-align: left;">
					<ww:property value="registry.htmlRenderer.renderAsText(registry.internationalizer.formatter.formatListingTitle(top.listing.title))" />
				</td>
				<td style="font-size:12px; padding: 6px; text-align: center; white-space: nowrap;">
					<ww:property value="registry.internationalizer.formatter.formatCount(top.buyerCatch.quantityWon)" />
				</td>
				<td style="font-size:12px; padding-left: 6px; padding-right: 11px; padding-top: 6px; padding-bottom: 6px; white-space: nowrap; text-align: right;">
					<ww:property value="registry.internationalizer.formatter.formatPrice(top.price)" />
				</td>
			</tr>
		</ww:iterator>
	</table>	
	<ww:include page="/Jsps/Utils/PageNavigationEmpty.jsp" />
	<ww:if test="#ItemList_showItemsTotal == true">
		<table width="100%" cellpadding="0" cellspacing="0">
			<tr>
				<td style="font-size: 14px; padding-right: 20px; padding-bottom: 20px; text-align: right;">
					Item Total:
				</td>
				<td style="text-align: right; font-size: 14px; padding-left: 6px; padding-right: 11px; padding-bottom: 20px; font-weight: bold;" width="1">
					<ww:property value="
						registry.internationalizer.formatter.formatPrice(
							#ItemList_itemsTotal)"/>
				</td>
			</tr>
		</table>
	</ww:if>
<ww:include page="/Jsps/Utils/FormModuleBareFooter.jsp" />