<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<div style="padding-left: 5px; padding-bottom: 30px;">
	<table cellpadding="0" cellspacing="0">
		<tr>
			<td style="font-size:12px; font-weight: bold;" valign="bottom">
				<ww:if test="#InvoiceHeader_to">
					Invoice to&nbsp;
					<ww:set name="InvoiceHeader_user" value="#InvoiceHeader_invoice.toUser" />
				</ww:if>
				<ww:if test="#InvoiceHeader_from">
					Payment information is available for items you purchased from&nbsp;
					<ww:set name="InvoiceHeader_user" value="#InvoiceHeader_invoice.fromUser" />
				</ww:if>
			</td>
            <td style="font-size:12px; font-weight: bold;" valign="bottom">
                <ww:property value="registry.htmlRenderer.renderAsText(registry.internationalizer.formatter.formatUsername(#InvoiceHeader_user.username))" />
			</td>
			<ww:if test="#InvoiceHeader_invoice.isPaid == false">
                <td style="font-size:12px;" valign="bottom">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</td>
				<td valign="bottom"><div style="font-size:12px;"><a style="text-decoration: underline; color: #0033CC; font-size:12px;" id="EmailInvoicePay" href="<ww:property value="registry.linkGenerator.getPayment(#InvoiceHeader_invoice)" />">Pay now</a>.</div></td>
			</ww:if>
		</tr>
	</table>
</div>
