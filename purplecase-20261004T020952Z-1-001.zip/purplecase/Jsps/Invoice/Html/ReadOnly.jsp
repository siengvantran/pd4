<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="ItemList_showItemsTotal" value="false" />
<ww:set name="ItemList_catches" value="#InvoiceReadOnly_invoice.catches" />
<ww:set name="ItemList_itemsTotal" value="#InvoiceReadOnly_invoice.catchesTotal" />
<ww:include page="/Jsps/Invoice/Html/ItemList.jsp" />
<ww:if test="@com.zeedive.util.StringUtil@isEmpty(#InvoiceReadOnly_invoice.paymentInstructions) == false">
	<ww:set name="ModuleHeader_title" value="'Note from the Seller'" />
	<ww:include page="/Jsps/Utils/ModuleHeader.jsp" />
		<div class="PaymentInstructions">
			<ww:property value="
				registry.htmlRenderer.renderAsText(registry.internationalizer.formatter.formatPaymentInstructions(
					#InvoiceReadOnly_invoice.paymentInstructions))" />
		</div>
	<ww:include page="/Jsps/Utils/ModuleFooter.jsp" />
</ww:if>
