<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>

<ww:set name="NO_DISCOUNT" value="@com.zeedive.actions.ConfirmOfferAction@NO_DISCOUNT"/>
<ww:set name="purchasePrice" value="registry.internationalizer.formatter.formatOfferPrice(purchasePrice)" />
<ww:set name="noneDiscount" value="registry.internationalizer.formatter.formatOfferPrice(#NO_DISCOUNT)" />
<ww:set name="noneDiscountedPrice" value="registry.internationalizer.formatter.formatOfferPrice(discountedPrice(#NO_DISCOUNT))" />
<ww:set name="noneFinalPrice" value="registry.internationalizer.formatter.formatOfferPrice(finalPrice(#NO_DISCOUNT))" />

<ww:set name="CREDIT_EXPERT_DISCOUNT" value="@com.zeedive.actions.ConfirmOfferAction@CREDIT_EXPERT_DISCOUNT"/>
<ww:set name="creditExpertDiscount" value="registry.internationalizer.formatter.formatOfferPrice(#CREDIT_EXPERT_DISCOUNT)" />
<ww:set name="creditExpertDiscountedPrice" value="registry.internationalizer.formatter.formatOfferPrice(discountedPrice(#CREDIT_EXPERT_DISCOUNT))" />
<ww:set name="creditExpertFinalPrice" value="registry.internationalizer.formatter.formatOfferPrice(finalPrice(#CREDIT_EXPERT_DISCOUNT))" />

<ww:set name="GALA_BINGO_DISCOUNT" value="@com.zeedive.actions.ConfirmOfferAction@GALA_BINGO_DISCOUNT"/>
<ww:set name="galaBingoDiscount" value="registry.internationalizer.formatter.formatOfferPrice(#GALA_BINGO_DISCOUNT)" />
<ww:set name="galaBingoDiscountedPrice" value="registry.internationalizer.formatter.formatOfferPrice(discountedPrice(#GALA_BINGO_DISCOUNT))" />
<ww:set name="galaBingoFinalPrice" value="registry.internationalizer.formatter.formatOfferPrice(finalPrice(#GALA_BINGO_DISCOUNT))" />

<ww:set name="LOVE_FILM_DISCOUNT" value="@com.zeedive.actions.ConfirmOfferAction@LOVE_FILM_DISCOUNT"/>
<ww:set name="loveFilmDiscount" value="registry.internationalizer.formatter.formatOfferPrice(#LOVE_FILM_DISCOUNT)" />
<ww:set name="loveFilmDiscountedPrice" value="registry.internationalizer.formatter.formatOfferPrice(discountedPrice(#LOVE_FILM_DISCOUNT))" />
<ww:set name="loveFilmFinalPrice" value="registry.internationalizer.formatter.formatOfferPrice(finalPrice(#LOVE_FILM_DISCOUNT))" />

<ww:set name="ESURE_DISCOUNT" value="@com.zeedive.actions.ConfirmOfferAction@ESURE_DISCOUNT"/>
<ww:set name="esureDiscount" value="registry.internationalizer.formatter.formatOfferPrice(#ESURE_DISCOUNT)" />
<ww:set name="esureDiscountedPrice" value="registry.internationalizer.formatter.formatOfferPrice(discountedPrice(#ESURE_DISCOUNT))" />
<ww:set name="esureFinalPrice" value="registry.internationalizer.formatter.formatOfferPrice(finalPrice(#ESURE_DISCOUNT))" />

<ww:set name="postage" value="registry.internationalizer.formatter.formatOfferPrice(listing.maxPostage)" />

<input type="hidden" id="noneFinalPrice" value="<ww:property value="#noneFinalPrice"/>" />
<input type="hidden" id="ceFinalPrice" value="<ww:property value="#creditExpertFinalPrice"/>" />
<input type="hidden" id="ceBlurb" value="Claim your free credit report and 30-day free trial" />
<input type="hidden" id="gbFinalPrice" value="<ww:property value="#galaBingoFinalPrice"/>" />
<input type="hidden" id="gbBlurb" value="Join Gala today and get £10 free play" />
<input type="hidden" id="lfFinalPrice" value="<ww:property value="#loveFilmFinalPrice"/>" />
<input type="hidden" id="lfBlurb" value="Claim 2 FREE rentals when you join LoveFilm" />
<input type="hidden" id="eFinalPrice" value="<ww:property value="#esureFinalPrice"/>" />
<input type="hidden" id="eBlurb" value="Claim your new customer online discount from esure today" />

<table cellpadding="0" cellspacing="0">
    <tr>
        <td>
            <table cellpadding="0" cellspacing="0">
                <tr>
                    <td width="150px">Sponsor</td>
                    <td width="120px">Price</td>
                    <td width="120px">Discount</td>
                    <td width="120px">Effective Price</td>
                    <td width="80px">Select</td>

                </tr>
                <tr id="e" style="background-color: white;">
                    <!-- Esure -->
                    <td>
                        <script type="text/javascript">
                        var uri = 'http://impgb.tradedoubler.com/imp?type(img)g(11644011)a(1508349)epi(<ww:property value="authenticationInfo.user.username"/>)epi(<ww:property value="listing.listingId"/>)' + new String (Math.random()).substring (2, 11);
                        document.write('<a href="http://clkuk.tradedoubler.com/click?p=4846&a=1508349&g=11644011&epi=<ww:property value="authenticationInfo.user.username"/>&epi=<ww:property value="listing.listingId"/>" target="_BLANK"><img src="'+uri+'" border=0></a>');
                        </script>
                    </td>
                    <td id="ePrice" class="SponsorCell"><ww:property value="#purchasePrice" /></td>
                    <td id="eDiscount" class="SponsorCell"><ww:property value="#esureDiscount" /></td>
                    <td id="eEffective" class="SponsorCell"><ww:property value="#esureDiscountedPrice" /></td>
                    <td><input type="radio" id="eRadio" name="sponsorRadio" value="esure" onclick="Offer_background('e');"><br></td>
                </tr>
                <tr id="gb" style="background-color: white;">
                    <!-- Gala Bingo -->
                    <td>
                        <script type="text/javascript">
                        var uri = 'http://impgb.tradedoubler.com/imp?type(img)g(17193194)a(1508349)epi(<ww:property value="authenticationInfo.user.username"/>)epi(<ww:property value="listing.listingId"/>)' + new String (Math.random()).substring (2, 11);
                        document.write('<a href="http://clkuk.tradedoubler.com/click?p=44561&a=1508349&g=17193194&epi=<ww:property value="authenticationInfo.user.username"/>&epi=<ww:property value="listing.listingId"/>" target="_BLANK"><img src="'+uri+'" border=0></a>');
                        </script>
                    </td>
                    <td id="gbPrice" class="SponsorCell"><ww:property value="#purchasePrice" /></td>
                    <td id="gbDiscount" class="SponsorCell"><ww:property value="#galaBingoDiscount" /></td>
                    <td id="gbEffective" class="SponsorCell"><ww:property value="#galaBingoDiscountedPrice" /></td>
                    <td><input type="radio" id="gbRadio" name="sponsorRadio" value="galaBingo" onclick="Offer_background('gb');"><br></td>
                </tr>
                <tr id="lf" style="background-color: white;">
                    <!-- Love Film -->
                    <td>
                        <script type="text/javascript">
                        var uri = 'http://impgb.tradedoubler.com/imp?type(img)g(11617614)a(1508349)epi(<ww:property value="authenticationInfo.user.username"/>)epi(<ww:property value="listing.listingId"/>)' + new String (Math.random()).substring (2, 11);
                        document.write('<a href="http://clkuk.tradedoubler.com/click?p=3412&a=1508349&g=11617614&epi=<ww:property value="authenticationInfo.user.username"/>&epi=<ww:property value="listing.listingId"/>" target="_BLANK"><img src="'+uri+'" border=0></a>');
                        </script>
                    </td>
                    <td id="lfPrice" class="SponsorCell"><ww:property value="#purchasePrice" /></td>
                    <td id="lfDiscount" class="SponsorCell"><ww:property value="#loveFilmDiscount" /></td>
                    <td id="lfEffective" class="SponsorCell"><ww:property value="#loveFilmDiscountedPrice" /></td>
                    <td><input type="radio" id="lfRadio" name="sponsorRadio" value="loveFilm" onclick="Offer_background('lf');"><br></td>
                </tr>
                <tr id="ce" style="background-color: white;">
                    <!-- Credit Expert -->
                    <td>
                        <script type="text/javascript">
                        var uri = 'http://impgb.tradedoubler.com/imp?type(img)g(16137314)a(1508349)epi(<ww:property value="authenticationInfo.user.username"/>)epi(<ww:property value="listing.listingId"/>)' + new String (Math.random()).substring (2, 11);
                        document.write('<a href="http://clkuk.tradedoubler.com/click?p=32000&a=1508349&g=16137314&epi=<ww:property value="authenticationInfo.user.username"/>&epi=<ww:property value="listing.listingId"/>" target="_BLANK"><img src="'+uri+'" border=0></a>');
                        </script>
                    </td>
                    <td id="cePrice" class="SponsorCell"><ww:property value="#purchasePrice" /></td>
                    <td id="ceDiscount" class="SponsorCell"><ww:property value="#creditExpertDiscount" /></td>
                    <td id="ceEffective" class="SponsorCell"><ww:property value="#creditExpertDiscountedPrice" /></td>
                    <td><input type="radio" id="ceRadio" name="sponsorRadio" value="creditExpert" onclick="Offer_background('ce');"><br></td>
                </tr>

                <tr id="none" style="background-color: rgb(170, 221, 238); height:60px">
                    <td class="SponsorCell">None</td>
                    <td id="nonePrice" class="SponsorCell"><ww:property value="#purchasePrice" /></td>
                    <td id="noneDiscount" class="SponsorCell">None</td>
                    <td id="noneEffective" class="SponsorCell"><ww:property value="#purchasePrice" /></td>
                    <td><input type="radio" id="noneRadio" name="sponsorRadio" value="none" checked="selected" onclick="Offer_background('none');" on><br></td>
                </tr>
            </table>
        </td>
        <td style="vertical-align:top;">
            <table style="border-width:20px; border-spacing:5px; border-style:solid; border-color:rgb(170, 221, 238); border-collapse:separate;">
                <tr style="height:49px">
                    <td width="100px">Price</td>
                    <td width="80px" id="summaryPrice" class="SponsorSummaryCell"><ww:property value="#purchasePrice" /></td>
                </tr>
                <tr style="height:49px">
                    <td>Discount</td>
                    <td id="summaryDiscount" class="SponsorSummaryCell">None</td>
                </tr>
                <tr style="height:49px">
                    <td>Effective Price</td>
                    <td id="summaryEffective" class="SponsorSummaryCell"><ww:property value="#purchasePrice" /></td>
                </tr>
                <tr style="height:49px">
                    <td>Postage</td>
                    <td class="SponsorSummaryCell"><ww:property value="#postage" /></td>
                </tr>
                <tr style="height:48px">
                    <td>Final Effective Price (with Postage)</td>
                    <td id="summaryFinal" class="SponsorSummaryCell"><ww:property value="#noneFinalPrice" /></td>
                </tr>
            </table>
        </td>
        <td style="vertical-align:top;">
            <table style="border-width:20px; border-spacing:5px; border-style:solid; border-color:rgb(170, 221, 238); border-collapse:separate;">
                <tr style="height:264px">
                    <td id="summaryNotes" style="vertical-align:top; visibility:hidden" width="200px">
                        To qualify for the sponsor's discount,
                        <br><br>a) <span id="summaryBlurb"></span>
                        <br><br>b) Pay for the product: <i><ww:property value="#purchasePrice" /> + <ww:property value="#postage" /> = <ww:property value="#noneFinalPrice"/></i>
                        <br><br>c) Claim your rebate of <b><i><span id="summaryRebate"></span></i></b> by sending us the sponsor's email on team@pricedive.com
                        <br><br>d) Any remaining credit will be applied to your account accordingly.
                    </td>
                </tr>
            </table>
        </td>
    </tr>

</table>





