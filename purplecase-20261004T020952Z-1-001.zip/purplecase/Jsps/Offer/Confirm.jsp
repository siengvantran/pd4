<%@ taglib uri="webwork" prefix="ww" %><%@ page contentType="text/html; charset=UTF-8" %>
<ww:set name="PageBegin_description" value="'Confirm Offer'" />
<ww:set name="DiveInformation_backUrl" value="registry.linkGenerator.getView(listing).setBackUrl(backUrl)" />
<ww:include page="/Jsps/Page/Begin.jsp" />
    <div class="PageTitle">Confirm Your Offer Information</div>

    <div class="DetailedListingInformationContainer">
        <ww:set name="DetailedListingInformation_listing" value="listing" />
        <ww:set name="DetailedListingInformation_showListingLinks" value="true" />
        <ww:set name="DetailedListingInformation_showCatchHistoryLink" value="false" />
        <ww:set name="DetailedListingInformation_showCatchButton" value="false" />
        <ww:include page="/Jsps/Listing/DetailedInformation.jsp" />
    </div>

    <ww:form name="ConfirmOffer" method="post" action="registry.linkGenerator.getConfirmOffer().setBackUrl(#DiveInformation_backUrl)">

        <ww:hidden name="'listingId'" value="listing.listingId" />

        <ww:set name="FormModuleHeader_title" value="'Offer Information'" />
        <ww:set name="FormModuleHeader_showRequiredFieldsNotice" value="false" />
        <ww:include page="/Jsps/Utils/FormModuleHeader.jsp" />
            <ww:component template="form-containerbegin.vm" />
                <ww:component template="form-rowbegin.vm" />
                    <ww:component template="form-cellbegin.vm" />
                        <ww:textfield size="5" labelposition="'left'" label="'Offer Price: £'" name="'validatedOffer.offerPrice'" />
                    <ww:component template="form-cellend.vm" />
                <ww:component template="form-rowend.vm" />
            <ww:component template="form-containerend.vm" />

        <ww:include page="/Jsps/Utils/FormModuleFooter.jsp" />
        <br />
        <ww:set name="FormSubmitFooterBinding_submitButtonName" value="'Submit Your Offer'" />
        <ww:set name="FormSubmitFooterBinding_helpText" value="'By clicking \"Submit Your Offer\", you agree to purchase the selected item if your offer is successful.'" />
        <ww:include page="/Jsps/Utils/FormSubmitFooterBinding.jsp" />

        <ww:include page="/Jsps/Utils/FormModuleBareHeader.jsp" />

    </ww:form>

<ww:include page="/Jsps/Page/End.jsp" />
