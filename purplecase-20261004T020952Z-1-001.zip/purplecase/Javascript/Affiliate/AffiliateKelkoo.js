////////////////////////////
/////ini les variables//////
////////////////////////////
var aff_num;
var key;
var kpowered;
var kcatid;
var klogic;
var kkpartnerid;
var kad_w;
var kad_h;
var kad_font;
var kad_font_size;
var kad_img_border_color;
var kad_table_border_color;
var kad_table_background_color;
var kad_price_color;
var kad_titre;
var kad_prix;
var kurl;
var kxsl;
var kcatid;
var kcomid;
var klogic;
var kkpartner;
///// FIN ini les variables//////
///// Declare URL ////////
kurl='http://export.kelkoo.co.uk/ctl/exportSearch?partner=kelkoo';
if (key!=undefined){
	key=escape(key);
	kurl+="&siteSearchQuery="+key;}
if (aff_num!=undefined){kurl+="&aff_num="+aff_num}
if (kad_w!=undefined){kurl+="&kad_w="+kad_w}
if (kad_h!=undefined){kurl+="&kad_h="+kad_h}
if (kpowered!=undefined){kurl+="&kpowered="+kpowered}
if (kcatid!=undefined){kurl+="&catId="+kcatid}
if (klogic!=undefined){kurl+="&logicalType=AND"}
kurl+="&partnerId=8901411";
//if (kkpartnerid!=undefined){kurl+="&partnerId="+kkpartnerid}
if (kad_font!=undefined){kurl+="&kad_font="+kad_font}else{kurl+="&kad_font=arial"}
if (kad_font_size!=undefined){kurl+="&kad_font_size="+kad_font_size}else{kurl+="&kad_font_size=11"}
if (kad_img_border_color!=undefined){kurl+="&kad_img_border_color="+kad_img_border_color}else{kurl+="&kad_img_border_color="+kad_img_border_color}
if (kad_table_border_color!=undefined){kurl+="&kad_table_border_color="+kad_table_border_color}else{}
if (kad_table_background_color!=undefined){kurl+="&kad_table_background_color="+kad_table_background_color}else{}
if (kad_price_color!=undefined){kurl+="&kad_price_color="+kad_price_color}else{}
if (kad_titre!=undefined){kurl+="&kad_titre="+kad_titre}else{}
if (kad_prix!=undefined){kurl+="&kad_prix="+kad_prix}else{}
if (kxsl!=undefined){kurl+="&xsl="+kxsl+".xsl"}
//  DELETE   document.write(kurl);
// border iframe
if (kad_table_border_color!=undefined){
	iframestyle="style=\"border:1px solid #"+kad_table_border_color+"\"";
	}else{iframestyle="";}
document.write("<ifr"+"ame src=\""+kurl+"\" name=\"kad\" id=\"kad\" frameborder=\"0\" scrolling=\"no\" marginwidth=\"0\" marginheight=\"0\""
+" width=\""+kad_w+"\" height=\""+kad_h+"\" "+iframestyle+" ></iframe>");
//powered by
if (kpowered!=undefined){
    powimg="<img src=\"http://export.kelkoo.co.uk/images/uk/affiliates/xsl/powered.gif\" width=\"120\" height=\"18\" border=\"0\" />";
    powtxt="Powered by Kelkoo";
	if(kpowered=='image'){
		kpoweredby=powimg;
	}else if(kpowered=='text') {
		kpoweredby=powtxt;
	}else{kpoweredby=powtxt;}
	document.write("<div align='right' style=\"width:"+kad_w+"px; font-size:"+kad_font_size+"px; font-family:Arial\"><a href='http://tracker.tradedoubler.com/click?p=3431&amp;a="+aff_num+"&amp;g=1023129&amp;url=http://www.kelkoo.co.uk' target='_blank'>"+kpoweredby+"</a></div>");
	}
// impressions TD
var uri = 'http://impgb.tradedoubler.com/imp/img/1023129/'+aff_num+'?' + new String (Math.random()).substring (2, 11);
document.write('<a href="http://trac'+'ker.tradedoubler.com/click?p=3431&amp;a='+aff_num+'&amp;g=1023129" target="_blank"><img src="'+uri+'" width="1" height="1" border="0"></a>');
//initalise les variables//
aff_num= undefined;
key= undefined;
kpowered= undefined;
kcatid= undefined;
kcomid= undefined;
klogic= undefined;
kkpartnerid= undefined;
kad_w= undefined;
kad_h= undefined;
kad_font= undefined;
kad_font_size= undefined;
kad_img_border_color= undefined;
kad_table_border_color= undefined;
kad_table_background_color= undefined;
kad_price_color= undefined;
kad_titre= undefined;
kad_prix= undefined;
kad_cat= undefined;
kurl= undefined;
kxsl= undefined;
kcatid= undefined;
kcomid= undefined;
klogic= undefined;
kkpartner= undefined;
