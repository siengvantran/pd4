function affiliateTaxInfoNotifiedByIRSCheck() {
    var elm = $("AffiliateTaxInfoNotifiedByIRSCheckbox");
    if (elm.checked) {
        $("AffiliateBackupWithholdingAgreement").style.textDecoration = "line-through";
    } else {
        $("AffiliateBackupWithholdingAgreement").style.textDecoration = "none";
    }
}