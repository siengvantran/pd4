AffiliateFrameCreator = Class.create();
AffiliateFrameCreator.prototype = {
    initialize: function (domain, width, height, numListings, style) {
        this.width = width+2;
        this.height = height+2;
        this.numListings = numListings;
        this.domain = domain;
        this.style = style;
    },

    create: function () {

        var frameSource = this.domain+"AffiliateContent.zd";
        frameSource += "?fetchNewListing="+this.numListings;
        frameSource += "&affiliateFrameId="+_affiliate_id;
        frameSource += "&affiliateStyle="+this.style;

        var elementText = "<iframe ";
        elementText += "width = \""+this.width+"\" ";
        elementText += "scrolling = no ";
        elementText += "marginwidth = 0px ";
        elementText += "marginheight = 0px ";
        elementText += "frameborder = 0 ";
        elementText += "height = \""+this.height+"\" ";
        elementText += "src = \""+frameSource+"\" ";
        elementText += "></iframe>";
        
        document.write(elementText);
    }
};