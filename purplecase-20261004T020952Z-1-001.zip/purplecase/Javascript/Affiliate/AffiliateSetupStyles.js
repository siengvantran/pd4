function affiliateSetupStyle(value, affiliateId, baseUrl) {
    var elm = $('AffiliateSetupTextArea');
    var text =
    "<script type=\"text/javascript\" >\n"+
        "var _affiliate_id = "+affiliateId+";\n"+
    "</script>\n"+
    "<script language=\"javascript\"\n"+
        "src=\""+baseUrl+"AffiliateFrame.zd?affiliateStyle="+value+"\">\n"+
    "</script>";
    elm.value = text;
}
