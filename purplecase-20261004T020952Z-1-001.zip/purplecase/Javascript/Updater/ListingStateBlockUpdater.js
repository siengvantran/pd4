
ListingStateBlockUpdater = Class.create();
ListingStateBlockUpdater.prototype = {

    initialize: function(registry, listingTransferObject, blockDisplay) {
        this.listingTransferObject = listingTransferObject;
        this.blockDisplay = blockDisplay;
        this.stateCalculator = new ListingStateCalculator(listingTransferObject);
        this.needsRefreshListingEnd = true;
        this.needsRefreshListingBegin = true;
        this.registry = registry;
        this.beginningState = this.stateCalculator.stateAtDate(this.registry.getDiveTime().getTime());
        this.blockDisplay.display(this.beginningState);
    },

    update: function() {
        var state = this.stateCalculator.stateAtDate(this.registry.getDiveTime().getTime());
        if (state != this.beginningState){
            if (listingEnded(state) && this.needsRefreshListingEnd) {
                this.needsRefreshListingEnd = false;
                this.blockDisplay.display(state);
            }

            if (state == LISTING_STATE_ACTIVE && this.needsRefreshListingBegin) {
                this.needsRefreshListingBegin = false;
                this.blockDisplay.display(state);
            }
        }
    }
};