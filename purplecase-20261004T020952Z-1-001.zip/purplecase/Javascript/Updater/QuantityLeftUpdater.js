function QuantityLeftUpdater(registry, listingTransferObject, quantityLeftDisplay) {
	this.listingTransferObject = listingTransferObject;
	this.quantityLeftDisplay = quantityLeftDisplay;
    this.listingStateCalculator = new ListingStateCalculator(listingTransferObject);
    this.registry = registry;
}

QuantityLeftUpdater.prototype.update = function() {
	this.quantityLeftDisplay.setQuantityLeft(
            this.listingTransferObject.formattedQuantityLeft,
            this.listingStateCalculator.stateAtDate(this.registry.getDiveTime().getTime()));
}