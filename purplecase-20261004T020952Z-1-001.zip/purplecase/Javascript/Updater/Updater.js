Updater = Class.create();
Updater.prototype = {
    initialize: function(system) {
        this.updateables = new Array();
        this.system = system;
    },

    addUpdateable: function(updateable) {
        var count = this.updateables.length;
        this.updateables[count] = updateable;
    },

    startUpdateables: function() {
        this.periodicUpdate();
    },

    updateUpdateables: function() {
        for (var i = 0; i < this.updateables.length; i++) {
            this.updateables[i].update();
        }
    },

    periodicUpdate: function() {
        this.updateUpdateables();
        this.system.setTimeout(this.periodicUpdate.bind(this), 1000);
    }
};