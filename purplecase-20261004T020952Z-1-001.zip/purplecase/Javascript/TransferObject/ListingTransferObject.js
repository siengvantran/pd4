ListingTransferObject = Class.create();

ListingTransferObject.QUANTITY_LEFT_VALID_FLAG = 0x1;
ListingTransferObject.TITLE_VALID_FLAG = 0x2;
ListingTransferObject.IMAGE_LEFT_VALID_FLAG = 0x4;

ListingTransferObject.prototype = {
    initialize: function (listingId,
						startDate,
						absoluteEndDate,
						effectiveEndDate,
                        absoluteMaxPrice,
                        absoluteMinPrice,
                        effectiveMaxPrice,
                        effectiveMinPrice,
                        soldWhenEnds,
                        formattedEndTime,
                        catchCount,
                        isMultiQuantity,
                        formattedCatchCount,
                        formattedQuantityLeft,
                        formattedPublishTime,
                        formattedMaxPrice,
                        formattedWatchCount,
                        topCatchPrice,
                        formattedTopCatchUserName,
                        topCatchIsFromLoggedInUser,
                        minValidCatchPrice,
                        proposedCatchPrice,
                        formattedTitle,
                        imageId,
                        listingRefiller) {
      this.listingId = listingId;
      this.startDate = new Date(startDate);
      this.absoluteEndDate = new Date(absoluteEndDate);
      this.effectiveEndDate = new Date(effectiveEndDate);
      this.absoluteMaxPrice = absoluteMaxPrice;
      this.absoluteMinPrice = absoluteMinPrice;
      this.effectiveMaxPrice = effectiveMaxPrice;
      this.effectiveMinPrice = effectiveMinPrice;
      this.soldWhenEnds = soldWhenEnds;
      this.formattedEndTime = formattedEndTime;
      this.catchCount = catchCount;
      this.isMultiQuantity = isMultiQuantity;
      this.formattedCatchCount = formattedCatchCount;
      this.formattedQuantityLeft = formattedQuantityLeft;
      this.formattedPublishTime = formattedPublishTime;
      this.formattedMaxPrice = formattedMaxPrice;
      this.formattedWatchCount = formattedWatchCount;
      this.topCatchPrice = topCatchPrice;
      this.formattedTopCatchUserName = formattedTopCatchUserName;
      this.topCatchIsFromLoggedInUser = topCatchIsFromLoggedInUser;
      this.minValidCatchPrice = minValidCatchPrice;
      this.proposedCatchPrice = proposedCatchPrice;
      this.formattedTitle = formattedTitle;
      this.imageId = imageId;

      this.listingRefiller = listingRefiller;
      }
};