ErrorTransferObject = Class.create();
ErrorTransferObject.prototype = {
    initialize: function(message) {
        this.message = message;
    }
};
