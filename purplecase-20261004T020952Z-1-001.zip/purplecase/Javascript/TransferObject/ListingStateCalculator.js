function ListingStateCalculator(listingTransferObject) {
  this.listingTransferObject = listingTransferObject;
}

ListingStateCalculator.prototype.getEndPrice = function(index) {
    var endingPrice;
    if (this.listingTransferObject.catchCount == 0) {
        endingPrice = this.listingTransferObject.absoluteMinPrice;
    } else {
        endingPrice = this.listingTransferObject.effectiveMinPrice;
    }
    return endingPrice;
}

ListingStateCalculator.prototype.getStartPrice = function(index) {
	return this.listingTransferObject.effectiveMaxPrice;
}

ListingStateCalculator.prototype.priceAtDate = function(aDate) {
    var fraction = this.effectiveFractionOfDiveAtDate(aDate);
    var value = this.convertDiveFractionToPrice(fraction, this.listingTransferObject.effectiveMaxPrice, this.listingTransferObject.effectiveMinPrice);
    return value;
}

ListingStateCalculator.prototype.absolutePriceAtDate = function(aDate) {
    var fraction = this.absoluteFractionOfDiveAtDate(aDate);
    var value = this.convertDiveFractionToPrice(fraction, this.listingTransferObject.absoluteMaxPrice, this.listingTransferObject.absoluteMinPrice);
    return value;
}

ListingStateCalculator.prototype.convertDiveFractionToPrice = function(fraction, maxPrice, minPrice) {
    fraction = clampNormalized(fraction);
    var delta = fraction * (maxPrice - minPrice);
    return maxPrice-delta;
}

ListingStateCalculator.prototype.timeBeforePublish = function(aDate) {
	return (this.listingTransferObject.startDate.getTime() - aDate.getTime());
}

ListingStateCalculator.prototype.timeLeftAtDate = function(aDate) {

	var timeLeftBeforePublish = this.timeBeforePublish(aDate);
	if (timeLeftBeforePublish > 0) {
		return timeLeftBeforePublish;
	}
	else {
        var timeLeft = this.listingTransferObject.effectiveEndDate.getTime() - aDate.getTime();
        return (timeLeft < 0) ? 0 : timeLeft;
	}
}

ListingStateCalculator.prototype.stateAtDate = function(aDate) {

  var fraction = this.effectiveFractionOfDiveAtDate(aDate);
  if (fraction < 0) {
	return LISTING_STATE_NOT_PUBLISHED;
  }
  else {
	  if (fraction < 1) {
	  	return LISTING_STATE_ACTIVE;
	  }
	  else {
	  	if (this.listingTransferObject.soldWhenEnds) {
	 		return LISTING_STATE_INACTIVE_SOLD;
	  	}
	  	else {
	 		return LISTING_STATE_INACTIVE_NOT_SOLD;
		}
	  }
  }
}

ListingStateCalculator.prototype.fractionOfDiveAtDate = function(aDate, endDate) {
  var millis = aDate.getTime() - this.listingTransferObject.startDate.getTime();
  var totalMillis = endDate.getTime() - this.listingTransferObject.startDate.getTime();
  var fraction = millis/totalMillis;
  if (fraction>1)
    fraction = 1;
  return fraction;
}

ListingStateCalculator.prototype.effectiveFractionOfDiveAtDate = function(aDate) {
  var val = this.fractionOfDiveAtDate(aDate, this.listingTransferObject.effectiveEndDate);
  return val;
}

ListingStateCalculator.prototype.absoluteFractionOfDiveAtDate = function(aDate) {
  var val = this.fractionOfDiveAtDate(aDate, this.listingTransferObject.absoluteEndDate);
  return val;
}