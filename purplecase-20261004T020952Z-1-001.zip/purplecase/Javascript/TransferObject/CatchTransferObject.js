CatchTransferObject = Class.create();
CatchTransferObject.prototype = {
    initialize: function(listingId,
                         catchId,
                         executionDate,
                         price,
                         catchState,
                         formattedExecutionTime,
                         formattedCount,
                         formattedQuantityWon,
                         formattedQuantityLeft,
                         hasPartialCatch,
                         formattedUserName) {
        this.listingId = listingId;
        this.catchId = catchId;
        this.executionDate = new Date(executionDate);
        this.price = price;
        this.catchState = catchState;
        this.formattedExecutionTime = formattedExecutionTime;
        this.formattedCount = formattedCount;
        this.formattedQuantityWon = formattedQuantityWon;
        this.formattedQuantityLeft = formattedQuantityLeft;
        this.hasPartialCatch = hasPartialCatch;
        this.formattedUserName = formattedUserName;
    },

    copy: function(otherCatch) {
        this.listingId = otherCatch.listingId;
        this.catchId = otherCatch.catchId;
        this.executionDate = new Date(otherCatch.executionDate.getTime());
        this.price = otherCatch.price;
        this.catchState = otherCatch.catchState;
        this.formattedExecutionTime = otherCatch.formattedExecutionTime;
        this.formattedCount = otherCatch.formattedCount;
        this.formattedQuantityWon = otherCatch.formattedQuantityWon;
        this.formattedQuantityLeft = otherCatch.formattedQuantityLeft;
        this.hasPartialCatch = otherCatch.hasPartialCatch;
        this.formattedUserName = otherCatch.formattedUserName;
    }
};
