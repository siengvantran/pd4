CatchList = Class.create();
CatchList.prototype = {
    initialize: function(listingId) {
        this.listingId = listingId;
        this.catches = new Map();
        this.addedCatches = new Map();
    },

    addCatch: function(catchObject) {
        var existing = this.catches.get(catchObject.catchId);
        if (!existing){
            this.catches.put(catchObject.catchId, catchObject);
            this.addedCatches.put(catchObject.catchId, catchObject);
        } else {
            existing.copy(catchObject);
        }
    },

    getAndProcessAddedCatches: function() {
        var processedCatches = this.addedCatches.values();
        this.addedCatches.clear();
        return processedCatches;
    },

    getAndProcessRemovedCatches: function(){

    },

    getAllCatches: function(){
        var allCatches = this.catches.values();
        return allCatches;
    }
};
