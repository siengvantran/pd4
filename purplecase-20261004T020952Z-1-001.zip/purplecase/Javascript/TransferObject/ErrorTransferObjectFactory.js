ErrorTransferObjectFactory = Class.create();
ErrorTransferObjectFactory.prototype = {
    initialize: function() {
    },

    create: function(xmlElement) {
        var result = new ErrorTransferObject(
                xmlElement.childElements[0].text
                );
        return result;
    }
};
