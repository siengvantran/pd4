var LISTING_STATE_ACTIVE = 0;
var LISTING_STATE_INACTIVE_SOLD = 1;
var LISTING_STATE_INACTIVE_NOT_SOLD = 2;
var LISTING_STATE_NOT_PUBLISHED = 3;

function listingEnded(listingState) {
    return (listingState == LISTING_STATE_INACTIVE_SOLD ||
            listingState == LISTING_STATE_INACTIVE_NOT_SOLD);
}

function listingBecomesActive(oldState, newState) {
    return (oldState == LISTING_STATE_NOT_PUBLISHED &&
            newState == LISTING_STATE_ACTIVE);
}




