function setWatchOperation(operation) {
	var formElement = document.getElementById('Watch_operation');
	formElement.value = operation;
}

function setWatch(watchId, operation) {
	var formElement = document.getElementById('Watch_watchId');
	formElement.name = 'Watch_watchId';
	formElement.value = watchId;
	setWatchOperation(operation);
}

function setListingOperation(operation) {
	var formElement = document.getElementById('Listing_operation');
	formElement.value = operation;
}

function setListing(listingId, operation) {
	var formElement = document.getElementById('Listing_listingId');
	formElement.name = 'Listing_listingId';
	formElement.value = listingId;
	setListingOperation(operation);
}

function setCatchOperation(operation) {
	var formElement = document.getElementById('Catch_operation');
	formElement.value = operation;
}

function setCatch(catchId, operation) {
	var formElement = document.getElementById('Catch_catchId');
	formElement.name = 'Catch_catchId';
	formElement.value = catchId;
	setCatchOperation(operation);
}
