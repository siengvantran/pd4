function Offer_revealSponsors() {

    var sponsorPanel = document.getElementById("sponsor_panel");
    sponsorPanel.style.visibility = "visible";
    sponsorPanel.style.height = "320px";

}

function Offer_background(rowId) {

    // A new sponsor row has been selected, but we don't know what
    // the old row was, so we make them all white
    document.getElementById("none").style.backgroundColor = "white";
    document.getElementById("ce").style.backgroundColor = "white";
    document.getElementById("gb").style.backgroundColor = "white";
    document.getElementById("lf").style.backgroundColor = "white";
    document.getElementById("e").style.backgroundColor = "white";
    
    // Now make the selected row blue
    var pdBlue = "rgb(170, 221, 238)";
    document.getElementById(rowId).style.backgroundColor = pdBlue;

    // If the first row is selected, then hide the notes.
    // Otherwise show them and change the figures.
    var notes = document.getElementById("summaryNotes");
    if (rowId == "none") {
        notes.style.visibility = "hidden"
        Offer_resetToSummary();
    } else {
        notes.style.visibility = "visible"
        Offer_copyToSummary(rowId);
    }

}

function Offer_copyToSummary(rowId) {

    var summaryBlurb = document.getElementById("summaryBlurb");
    var summaryDiscount = document.getElementById("summaryDiscount");
    var summaryEffective = document.getElementById("summaryEffective");
    var summaryFinal = document.getElementById("summaryFinal");
    var summaryRebate = document.getElementById("summaryRebate");

    summaryBlurb.innerHTML = document.getElementById(rowId + "Blurb").value;
    summaryDiscount.innerHTML = document.getElementById(rowId + "Discount").innerHTML;
    summaryRebate.innerHTML = summaryDiscount.innerHTML;
    summaryEffective.innerHTML = document.getElementById(rowId + "Effective").innerHTML;
    summaryFinal.innerHTML = document.getElementById(rowId + "FinalPrice").value;
}

function Offer_resetToSummary() {

    var summaryDiscount = document.getElementById("summaryDiscount");
    var summaryEffective = document.getElementById("summaryEffective");
    var summaryFinal = document.getElementById("summaryFinal");
    var summaryRebate = document.getElementById("summaryRebate");

    summaryDiscount.innerHTML = "None";
    summaryRebate.innerHTML = "None";
    summaryEffective.innerHTML = document.getElementById("noneEffective").innerHTML;
    summaryFinal.innerHTML = document.getElementById("noneFinalPrice").value;

}

/*

<td id="nonePrice" class="SponsorCell"><ww:property value="#purchasePrice" /></td>
<td id="noneDiscount" class="SponsorCell">None</td>
<td id="noneEffective" class="SponsorCell"><ww:property value="#purchasePrice" /></td>*/
