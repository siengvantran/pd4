if (typeof addthis_widget15 == "undefined") {
    var addthis_widget15 = 'addthis';
    var at15O = 'http://s7.addthis.com/';
    var at15o = 'http://s7.addthis.com/services/';
    var at15Y = 'http://s7.addthis.com/select/';
    var at15y = new Array();
    at15y['ask'] = ['Ask','ask.png'];
    at15y['delicious'] = ['Del.icio.us','delicious.png'];
    at15y['digg'] = ['Digg','digg.png'];
    at15y['email'] = ['Email','email.png'];
    at15y['favorites'] = ['Favorites','favorites.png'];
    at15y['facebook'] = ['Facebook','facebook.gif'];
    at15y['fark'] = ['Fark','fark.png'];
    at15y['furl'] = ['Furl','furl.gif'];
    at15y['google'] = ['Google','goog.png'];
    at15y['live'] = ['Live','live.gif'];
    at15y['myspace'] = ['MySpace','myspace.png'];
    at15y['myweb'] = ['Yahoo MyWeb','yahoo-myweb.png'];
    at15y['newsvine'] = ['Newsvine','newsvine.png'];
    at15y['reddit'] = ['Reddit','reddit.gif'];
    at15y['sk*rt'] = ['Sk*rt','skrt.gif'];
    at15y['slashdot'] = ['Slashdot','slashdot.png'];
    at15y['stumbleupon'] = ['StumbleUpon','su.png'];
    at15y['stylehive'] = ['Stylehive','stylehive.gif'];
    at15y['tailrank'] = ['Tailrank','tailrank2.png'];
    at15y['technorati'] = ['Technorati','technorati.png'];
    at15y['thisnext'] = ['ThisNext','thisnext.gif'];
    at15y['twitter'] = ['Twitter','twitter.gif'];
    at15y['ballhype'] = ['BallHype','ballhype.png'];
    at15y['more'] = ['More ...','more.gif'];
    function at15I(at15i) {
        return document.getElementById(at15i);
    }
    function addthis_clearclosewin15() {
        if (typeof at15A != "undefined")clearTimeout(at15A);
    }
    function addthis_open(at15a, at15E, at15e, at15U) {
        addthis_clearclosewin15();
        addthis_url = at15e;
        addthis_title = at15U;
        if (addthis_url == '' || addthis_url == '[URL]')addthis_url = location.href;
        if (addthis_title == '' || addthis_title == '[TITLE]')addthis_title = document.title;
        var at15u = 020;
        var at15Z = at15a.getElementsByTagName('img');
        if (at15Z && at15Z[0]) {
            at15a = at15Z[0];
            at15u = 0;
        }
        atshow(at15E);
        var at15z = at15X(at15a);
        var at15x = at15z[0] + addthis_offset_left;
        var at15W = at15z[1] + at15u + 1 + addthis_offset_top;
        var at15w = at15V();
        var at15v = at15T();
        var at15t = at15I('addthis_dropdown15');
        at15t.style.display = 'block';
        if (at15x - at15v[0] + at15t.clientWidth + 024 > at15w[0])at15x = at15x - at15t.clientWidth;
        if (at15W - at15v[1] + at15t.clientHeight + at15a.clientHeight + 024 > at15w[1])at15W = at15W - at15t.clientHeight - 024;
        at15t.style.left = at15x + 'px';
        at15t.style.top = (at15W + at15a.clientHeight) + 'px';
        if (addthis_hide_embed) {
            var at15S = at15x + at15t.clientWidth;
            var at15s = at15W + at15t.clientHeight;
            var at15R = document.getElementsByTagName('embed');
            var at15r = 0,at15Q = 0,at15q = 0;
            for (at15P = 0; at15P < at15R.length; at15P++) {
                at15r = at15X(at15R[at15P]);
                at15Q = at15r[0];
                at15q = at15r[1];
                if (at15x < at15Q + at15R[at15P].clientWidth && at15W < at15q + at15R[at15P].clientHeight) {
                    if (at15S > at15Q && at15s > at15q) {
                        if (at15R[at15P].style.visibility != 'hidden') {
                            at15R[at15P].at15p = true;
                            at15R[at15P].style.visibility = 'hidden';
                        }
                    }
                }
            }
        }
        at15N();
        return false;
    }
    function at15N() {
        if (at15n)return;
        var at15M = addthis_options.replace(/\s/g, '');
        var at15m = at15M.split(',');
        for (var at15P = 0; at15P < at15m.length; at15P++) {
            var at15L = at15m[at15P];
            if (at15L in at15y) {
                var at15l = at15I('addthis_' + at15L + '15');
                if (at15l)at15l.src = at15o + at15y[at15L][1];
            }
        }
        at15n = true;
    }
    function addthis_close() {
        at15A = setTimeout("addthis_closewin15()", 0764);
    }
    function addthis_closewin15() {
        var at15t = at15I('addthis_dropdown15');
        at15t.style.display = 'none';
        var at15R = document.getElementsByTagName('embed');
        if (addthis_hide_embed) {
            for (at15P = 0; at15P < at15R.length; at15P++) {
                if (at15R[at15P].at15p)at15R[at15P].style.visibility = 'visible';
            }
        }
        return false;
    }
    function addthis_sendto(at15K) {
        if (at15K == 'email') {
            atshow(at15K);
            return false;
        }
        addthis_closewin15();
        if (at15K == 'favorites') {
            if (document.all)window.external.AddFavorite(addthis_url, addthis_title); else window.sidebar.addPanel(addthis_title, addthis_url, '');
            return false;
        }
        if (at15K == 'stumbleupon')at15K = 'su';
        if (at15K == 'sk*rt')at15K = 'skrt';
        window.open(at15k(at15K), 'addthis', 'scrollbars=yes,menubar=no,width=620,height=500,resizable=yes,toolbar=no,location=no,status=no');
        return false;
    }
    function at15k(at15K) {
        var at15J = encodeURIComponent(addthis_url);
        var at15j = encodeURIComponent(addthis_title);
        var at15H = encodeURIComponent(addthis_logo);
        return 'http://www.addthis.com/bookmark.php?v=15&winname=addthis&pub=' + addthis_pub + '&s=' + at15K + '&url=' + at15J + '&title=' + at15j + '&logo=' + at15H + '&logobg=' + addthis_logo_background + '&logocolor=' + addthis_logo_color;
    }
    function at15X(at15h) {
        var at15G = 0,at15g = 0;
        do {
            at15G += at15h.offsetTop || 0;
            at15g += at15h.offsetLeft || 0;
            at15h = at15h.offsetParent;
        } while (at15h);
        return [at15g,at15G];
    }
    function at15V() {
        var at15F = 0;
        var at15f = 0;
        if (typeof(window.innerWidth) == 'number') {
            at15F = window.innerWidth;
            at15f = window.innerHeight;
        } else if (document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)) {
            at15F = document.documentElement.clientWidth;
            at15f = document.documentElement.clientHeight;
        } else if (document.body && (document.body.clientWidth || document.body.clientHeight)) {
            at15F = document.body.clientWidth;
            at15f = document.body.clientHeight;
        }
        return [at15F,at15f];
    }
    function at15T() {
        var at15D = 0;
        var at15d = 0;
        if (typeof(window.pageYOffset) == 'number') {
            at15d = window.pageYOffset;
            at15D = window.pageXOffset;
        } else if (document.body && (document.body.scrollLeft || document.body.scrollTop)) {
            at15d = document.body.scrollTop;
            at15D = document.body.scrollLeft;
        } else if (document.documentElement && (document.documentElement.scrollLeft || document.documentElement.scrollTop)) {
            at15d = document.documentElement.scrollTop;
            at15D = document.documentElement.scrollLeft;
        }
        return [at15D,at15d];
    }
    function at15C() {
        var at15c = document.createElement('link');
        at15c.rel = 'stylesheet';
        at15c.type = 'text/css';
        at15c.href = addthis_css;
        at15c.media = 'all';
        document.lastChild.firstChild.appendChild(at15c);
    }
    function at15B() {
        at15b();
        at15C();
        var at15o0 = '<div id="addthis_dropdown15" onmouseover="addthis_clearclosewin15()" onmouseout="addthis_close()" style="z-index: 1000000; position: absolute; display: none">';
        at15o0 += '<table width="100%" cellpadding="2" cellspacing="0" style="background-color: #EEEEEE; height: 18px">';
        at15o0 += '<tr><td style="font-size: 12px; color: #666666; padding-left:3px"><span id="at_caption">Bookmark&nbsp;&amp;&nbsp;Share</span></td><td align="right" style="font-size: 9px; color: #666666; padding-right: 3px">' + addthis_brand + '</td></tr>';
        at15o0 += '</table>';
        var at15O0 = false;
        at15o0 += '<div id="at_share">';
        at15o0 += '<table id="addthis_services" width="100%" cellpadding="0" style="font-family: Verdana, Arial; font-size: 11px">';
        at15o0 += '<tr><td colspan="2" style="height: 0px"></td></tr>';
        var at15m = addthis_options.split(',');
        for (var at15P = 0; at15P < at15m.length; at15P++) {
            var at15L = at15m[at15P];
            if (at15L in at15y) {
                if (!at15O0)at15o0 += '<tr>';
                at15o0 += '\x3ctd width=\"50%\" style=\"height: 19px\">\x3ca href=\"/\" onclick=\"return addthis_sendto(\'' + at15L + '\');\">\x3cimg id=\"addthis_' + at15L + '15" alt="" width="16" height="16" />&nbsp; ' + at15y[at15L][0] + '</a></td>';
                if (at15O0)at15o0 += '</tr>';
                at15O0 = !at15O0;
            }
        }
        if (at15O0)at15o0 += '<td></td></tr>';
        at15o0 += '<tr><td colspan="2" style="height: 2px"></td></tr>';
        at15o0 += '</table>';
        at15o0 += '\x3c/div>\n';
        at15o0 += '<div id="at_email" style="display: none; font-size: 11px; padding-left: 20px; padding-top: 6px">';
        at15o0 += '<table border="0">';
        at15o0 += '<tr><td style="font-size: 12px">To:</td><td><input id="at_to" type="text" style="width: 130px; height: 18px; font-size: 11px; font-family: Arial; color: #999999" value=" email address" onfocus="checkto(this)" /></td</tr>';
        at15o0 += '<tr><td style="font-size: 12px">From:</td><td><input id="at_from" type="text" style="width: 130px; height: 18px; font-size: 11px; font-family: Arial; color: #999999" value=" email address" onfocus="checkto(this)"/></td</tr>';
        at15o0 += '<tr><td style="font-size: 12px" valign="top">Note:</td><td><textarea id="at_msg" style="width: 130px; height: 36px; font-size: 11px; font-family: Arial;"/></textarea></td</tr>';
        at15o0 += '<tr><td colspan="2" align="right"><span id="at_success" style="font-size: 10px; color: #777777;"></span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<input type="button" value="Send" onclick="return addthis_send()" style="font-size: 9px"/></td</tr>';
        at15o0 += '</table>';
        at15o0 += '\x3c/div>\n';
        at15o0 += '<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background-color: #EEEEEE">';
        at15o0 += '<tr><td colspan="2" align="right" style="padding: 0px; padding-right: 10px; height: 11px"><img id="at_img" src="' + at15Y + 'select_load.png" style="width: 1px; height: 1px" /><a href="http://www.addthis.com" target="_blank" style="height: 6px; padding: 0px"><img src="' + at15o + 'addthis-mini.gif" border="0" style="padding: 0px; width: 50px; height: 9px" alt="" /></a></td></tr>';
        at15o0 += '\x3c/table>\n';
        at15o0 += '\x3c/div>\n';
        at15l0 = document.createElement('div');
        at15l0.innerHTML = at15o0;
        document.body.insertBefore(at15l0, document.body.firstChild);
        at15l0.style.zIndex = 03641100;
    }
    function at15b() {
        at15n = false;
        if (typeof addthis_pub == 'undefined')addthis_pub = '';
        if (typeof at15i0 == 'undefined')at15i0 = 'Bookmark &amp Share';
        if (typeof addthis_brand == 'undefined')addthis_brand = '';
        if (typeof addthis_logo == 'undefined')addthis_logo = '';
        if (typeof addthis_logo_background == 'undefined')addthis_logo_background = '';
        if (typeof addthis_logo_color == 'undefined')addthis_logo_color = '';
        if (typeof addthis_options == 'undefined')addthis_options = 'favorites, digg, delicious, google, myspace, facebook, reddit, newsvine, live, more';
        if (typeof addthis_offset_top != 'number')addthis_offset_top = 0;
        if (typeof addthis_offset_left != 'number')addthis_offset_left = 0;
        if (typeof addthis_caption_share == 'undefined')addthis_caption_share = 'Bookmark &amp; Share';
        if (typeof addthis_caption_email == 'undefined')addthis_caption_email = 'Email a Friend';
        if (typeof addthis_css == 'undefined')addthis_css = at15O + 'css/152/addthis_widget.css';
        if (typeof addthis_hide_embed == 'undefined')addthis_hide_embed = true;
        addthis_options = addthis_options.replace(/\s/g, '');
    }
    function atshow(at15I0) {
        var at15o1 = at15I('at_share');
        var at15O1 = at15I('at_email');
        var at15l1 = at15I('at_caption');
        var at15i1 = at15I('at_success');
        at15o1.style.display = 'none';
        at15O1.style.display = 'none';
        at15i1.innerHTML = '';
        if (at15I0 == 'share' || at15I0 == '') {
            at15o1.style.display = 'block';
            at15l1.innerHTML = addthis_caption_share;
        } else {
            at15O1.style.display = 'block';
            at15l1.innerHTML = addthis_caption_email;
        }
    }
    function addthis_send() {
        var at15I1 = at15I('at_from');
        var at15o2 = at15I('at_to');
        var at15O2 = at15I('at_img');
        var at15i1 = at15I('at_success');
        var at15l2 = at15I('at_msg');
        if (at15I1.value.indexOf('@') < 0 || at15o2.value.indexOf('@') < 0 || at15I1.value.indexOf('.') < 0 || at15o2.value.indexOf('.') < 0) {
            alert('Please enter a valid email address!');
            return;
        }
        at15i2 = Math.random();
        at15I2 = 'http://www.addthis.com/tellfriend.php?pub=' + encodeURIComponent(addthis_pub) + '&url=' + encodeURIComponent(addthis_url) + '&fromname=aaa&fromemail=' + encodeURIComponent(at15I1.value) + '&tofriend=' + encodeURIComponent(at15o2.value) + '&note=' + encodeURIComponent(at15l2.value) + '&r=' + at15i2;
        at15O2.src = at15I2;
        at15i1.innerHTML = 'Message Sent!';
        at15A = setTimeout("addthis_closewin15()", 02260);
        return false;
    }
    function checkto(at15o3) {
        at15o3.style.color = '#000000';
        if (at15o3.value == ' email address')at15o3.value = '';
    }
    at15B();
}
