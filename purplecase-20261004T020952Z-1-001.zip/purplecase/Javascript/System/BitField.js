BitField = Class.create();

BitField.prototype = {

    initialize: function() {
        this.value = 0;
        this.clearAll();
    },

    setAll: function() {
        this.value = 0xFFFFFFFF;
    },

    clearAll: function() {
        this.value = 0;
    },

    setFlag: function(flag) {
        this.value |= flag;
    },

    clearFlag: function(flag) {
        this.value &= ~flag;
    },

    isFlagSet: function(flag) {
        if (this.value & flag) {
            return true;
        }
        return false;
    },

    getValue: function() {
        return this.value;
    }
 };
