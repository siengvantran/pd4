Session = Class.create();
Session.prototype = {

    SESSION_DURATION: 14400000,

    initialize: function(registry) {
        this.registry = registry;
    },

    start: function() {
        this.registry.getSystem().setTimeout(this.callback.bind(this), this.SESSION_DURATION);
    },

    callback: function() {
        var url = this.registry.getLinkUrlGenerator().getErrorPage("EXPIRED");
        this.registry.getPageNavigator().goToPage(url);
    }

 };
