EventGroup = Class.create();
EventGroup.prototype = {
    initialize: function(eventHandler) {
        this.eventHandler = eventHandler;
        this.events = new Array();
        this.enabled = true;
    },

    addEvent: function(element, eventStr, func) {
        var count = this.events.length;
        this.events[count] = {
                element: element,
                eventName: eventStr,
                callback: func
            };
        this.eventHandler.addEvent(element, eventStr, func);
    },

    enableEvents: function(enable) {
        if (enable != this.enabled) {
            for (var i=0; i<this.events.length; i++){
                if (enable) {
                    this.eventHandler.addEvent(
                            this.events[i].element,
                            this.events[i].eventName,
                            this.events[i].callback);
                } else {
                    this.eventHandler.removeEvent(
                            this.events[i].element,
                            this.events[i].eventName,
                            this.events[i].callback);
                }
            }

            this.enabled = enable;
        }
    }
};
