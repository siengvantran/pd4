LinkUrlGenerator = Class.create();
LinkUrlGenerator.prototype = {

    initialize: function(encodedBackUrl) {
        this.encodedBackUrl = encodedBackUrl;
    },

    getErrorPage: function(message) {
      return "Error.zd?errorMessageString=" + message;
    },

    getViewPage: function(listingId) {
      return "View.zd?listingId=" + listingId;
    },

    getAffiliateViewPage: function(affiliateId, listingId) {
      return "NoOp.zd?affiliateId="+affiliateId+
             "&affiliateUrl="+
             "View.zd%3FlistingId=" + listingId + "%26showHowItWorks=true"
    },

    getImageUrl: function(imageId) {
      return "PictureStream.zd?pictureDataId="+imageId;
    },

    getProcessCatchPage: function() {
      return "ProcessCatch.zd";
    },

    appendBackUrl: function(url) {
        var generatedUrl = url;
        if (this.encodedBackUrl != null) {
            generatedUrl += "&encodedBackUrl="+this.encodedBackUrl;
        }
        return generatedUrl;
    },

    appendCatchPrice: function(url, catchPrice) {
        var generatedUrl = url+"&validatedCatch.price="+catchPrice;
        return generatedUrl;
    }
};