DiveTime = Class.create();
DiveTime.prototype = {
    initialize: function(refServerTime) {
        this.setTime(refServerTime);
    },

    getTime: function() {
        var nowOnClient = new Date();
        nowOnClient.setTime(nowOnClient.getTime() + this.serverClientDeltaMillis);
        return nowOnClient;
    },

    setTime: function(refServerTime) {
        var refClientTime = new Date();

        this.serverClientDeltaMillis =
            refServerTime - refClientTime.getTime();
    }
 };

