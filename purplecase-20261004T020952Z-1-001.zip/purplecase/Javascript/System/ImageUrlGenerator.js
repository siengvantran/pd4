function ImageUrlGenerator(urlPrefix) {
    this.urlPrefix = urlPrefix;
}

ImageUrlGenerator.prototype.generateUrl = function(imageName) {
    var url;
    if (IE){
        url = this.urlPrefix+"/"+imageName;
    } else {
        url = "url("+this.urlPrefix+"/"+imageName+")";
    }
    return url;
}