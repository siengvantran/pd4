ElementIdGenerator = Class.create();
ElementIdGenerator.prototype = {
    initialize: function() {
        this.elementId = 0;
    },

    generateId: function() {
        var id = "id_"+this.elementId;
        this.elementId++;
        return id; 
    }
};