AjaxRequester = Class.create();
AjaxRequester.prototype = {
    initialize: function() {
    },

    makeRequest: function(url, options) {
        var request = new Ajax.Request(url,options);
        return request;
    }
}