function OnLoad(pageRefresher) {
    this.pageRefresher = pageRefresher;
}

OnLoad.prototype.onloadCallback = function() {
   var defaultValue ="1";
   var isBackButtonPageLoad = (defaultValue != document.browserState.buttonState.value);
   document.browserState.buttonState.value=2;
   document.browserState.buttonState.defaultValue=2;

   if (isBackButtonPageLoad) {
      this.pageRefresher.refreshPage();
   }
}