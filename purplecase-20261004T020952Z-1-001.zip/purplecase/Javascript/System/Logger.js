function logDebugOutput(id, message) {
    var element = document.getElementById("logDebugOutputDiv"+id);
    if (!element){
        element = document.createElement("div");
        element.id = "logDebugOutputDiv"+id;
        var mybody = document.getElementById("logDebugOutputDiv");
        mybody.appendChild(element);
    }

    element.innerHTML = message;
}