function checkAll(field) {
	for (i = 0; i < field.length; i++) {
		if (!field[i].disabled) {
			field[i].checked = true ;
		}
	}
}

function uncheckAll(field) {
	for (i = 0; i < field.length; i++) {
		if (!field[i].disabled) {
			field[i].checked = false ;
		}
	}
}

function anyElementsSelected(field) {
	for (i = 0; i < field.length; i++) {
		if (field[i].checked) {
			return true;
		}
	}
    
    return false;
}
