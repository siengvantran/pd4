var IE=0;
if(document.all) {
 IE=1
}
 