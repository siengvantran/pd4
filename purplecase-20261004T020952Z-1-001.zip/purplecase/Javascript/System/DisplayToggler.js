function hide(divId) {

	var div = document.getElementById(divId);
	div.style.display = "none";
}
function show(divId) {

	var div = document.getElementById(divId);
	div.style.display = "block";
}