//System
function System() {
}

System.prototype.setTimeout = function(expression, duration) {
	setTimeout(expression, duration);
}

System.prototype.getCurrentTime = function() {
	return new Date();
}