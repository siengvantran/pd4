UrlParams = Class.create();
UrlParams.prototype = {

    initialize: function() {
        this.params = new Array();
    },

    addParameter: function(key, value) {
        var count = this.params.length;
        this.params[count] = {theKey:key,
                                   theValue:value};
        return this;
    },

    merge: function(other) {
        for (var i= 0; i < other.params.length; i++) {
            this.addParameter(other.params[i].theKey,other.params[i].theValue);
        }
    },

    toQueryString: function() {
        var queryString = "";
        for (var i= 0; i < this.params.length; i++) {
            queryString += this.params[i].theKey+"="+this.params[i].theValue;

            if (i != this.params.length-1) {
                queryString+="&";
            }
        }
        return queryString;
    }
};