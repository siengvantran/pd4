function cancelEvent() {
	if( IE &&window.event) { 
		window.event.cancelBubble=true;
		window.event.returnValue=false;
	}
	return false;
}