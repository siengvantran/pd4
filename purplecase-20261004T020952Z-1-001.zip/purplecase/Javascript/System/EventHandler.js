EventHandler = Class.create();
EventHandler.prototype = {
    initialize: function() {

    },

    addEvent: function(element, eventStr, func) {
        Event.observe(element, eventStr, func, false);
    },

    removeEvent: function(element, eventStr, func) {
        Event.stopObserving(element, eventStr, func, false);
    },

    element: function(event) {
        return Event.element(event);
    }
};
