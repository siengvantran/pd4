UrlFactory = Class.create();
UrlFactory.prototype = {

    initialize: function() {
    },

    create: function(urlString) {
        var index = urlString.indexOf("?");
        if (index == -1) {
            return new Url(urlString);
        }
        var url = new Url(urlString.substring(0,index));
        this.addParams(url, urlString.substring(index+1, urlString.length));
        return url;
    },

    addParams: function(url, urlString) {
        var currentIndex = 0;

        while (currentIndex < urlString.length) {
            var equalsIndex = urlString.indexOf("=", currentIndex);
            if (equalsIndex == -1) {
                break;
            }

            var key = urlString.substring(currentIndex,equalsIndex);
            currentIndex = equalsIndex+1;

            var paramSeparatorIndex = urlString.indexOf("&",currentIndex);
            var value;
            if (paramSeparatorIndex == -1) {
                value = urlString.substring(currentIndex,urlString.length);
                currentIndex = urlString.length;
            } else {
                value = urlString.substring(currentIndex,paramSeparatorIndex);
                currentIndex = paramSeparatorIndex+1;
            }

            url.addParameter(key,value);
        }

        return url;




    }



};