function PageRefresher() {
}

PageRefresher.prototype.refreshPage = function() {
    window.location.replace(window.document.location.toString());
}
