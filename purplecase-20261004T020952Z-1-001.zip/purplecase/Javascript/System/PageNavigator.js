PageNavigator = Class.create();
PageNavigator.prototype = {
    initialize: function() {
    },

    goToPage: function(url) {
        window.top.location = url;
    }
};
