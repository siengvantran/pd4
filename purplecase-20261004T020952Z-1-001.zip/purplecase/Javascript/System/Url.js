Url = Class.create();
Url.prototype = {

    initialize: function(target) {
        this.target = target;
        this.params = new Array();
    },

    addParameter: function(key, value) {
        var count = this.params.length;
        this.params[count] = {theKey:key,
                                   theValue:value};
        return this;
    },

    getTarget: function() {
        return this.target;
    },

    paramsToQueryString: function() {
        var queryString = "";
        queryString = this.buildParamsAsQueryString(queryString, false);
        return queryString;
    },

    buildParamsAsQueryString: function(queryString, includeStartingMark) {
        for (var i= 0; i < this.params.length; i++) {
            if (i == 0 && includeStartingMark) {
                queryString += "?";
            }

            queryString += this.params[i].theKey+"="+this.params[i].theValue;

            if (i != this.params.length-1) {
                queryString+="&";
            }
        }

        return queryString;
    },

    toQueryString: function() {
        var queryString = this.getTarget();
        queryString = this.buildParamsAsQueryString(queryString, true);
        return queryString;
    }
};