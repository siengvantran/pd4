function disableForm(theForm) {
	if (document.all || document.getElementById) {
		for (i = 0; i < theForm.length; i++) {
			var tempObj = theForm.elements[i];
			if (tempObj.type.toLowerCase() == "submit" || tempObj.type.toLowerCase() == "reset") {
				tempObj.disabled = true;
			}
		}
	}	
}