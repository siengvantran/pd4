CookiesEnabledVerifier = Class.create();
CookiesEnabledVerifier.prototype = {
    initialize: function(registry) {
        this.registry = registry;
    },

    verify: function() {
        if (document.cookie.length == 0) {
            var url = this.registry.getLinkUrlGenerator().getErrorPage("NO_COOKIES");
            this.registry.getPageNavigator().goToPage(url);
        }
    }
 };