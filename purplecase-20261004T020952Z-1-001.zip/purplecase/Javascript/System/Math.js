function clampNormalized(value) {
	if (value < 0) {
		value = 0;
	}
	if (value > 1) {
		value = 1;
	}
	return value;
}