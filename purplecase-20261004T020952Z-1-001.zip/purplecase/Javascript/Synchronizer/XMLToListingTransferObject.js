XMLToListingTransferObject = Class.create();
XMLToListingTransferObject.prototype = {
    initialize: function() {

    },

    convert: function(element, transferObject) {
        var index = 0;
        
        transferObject.listingId = stringToNumber(element.childElements[index++].text);
        transferObject.startDate = new Date(stringToNumber(element.childElements[index++].text));
        transferObject.absoluteEndDate = new Date(stringToNumber(element.childElements[index++].text));
        transferObject.effectiveEndDate = new Date(stringToNumber(element.childElements[index++].text));
        transferObject.absoluteMaxPrice = stringToNumber(element.childElements[index++].text);
        transferObject.absoluteMinPrice = stringToNumber(element.childElements[index++].text);
        transferObject.effectiveMaxPrice = stringToNumber(element.childElements[index++].text);
        transferObject.effectiveMinPrice = stringToNumber(element.childElements[index++].text);
        transferObject.soldWhenEnds = stringToBoolean(element.childElements[index++].text);
        transferObject.formattedEndTime = element.childElements[index++].text;
        transferObject.catchCount = stringToNumber(element.childElements[index++].text);
        transferObject.isMultiQuantity = stringToBoolean(element.childElements[index++].text);
        transferObject.formattedCatchCount = element.childElements[index++].text;
        transferObject.formattedQuantityLeft = element.childElements[index++].text;
        transferObject.formattedPublishTime = element.childElements[index++].text;
        transferObject.formattedMaxPrice = element.childElements[index++].text;
        transferObject.formattedWatchCount = element.childElements[index++].text;
        transferObject.topCatchPrice = stringToNumber(element.childElements[index++].text);
        transferObject.formattedTopCatchUserName = element.childElements[index++].text;
        transferObject.topCatchIsFromLoggedInUser = stringToBoolean(element.childElements[index++].text);
        transferObject.minValidCatchPrice = stringToNumber(element.childElements[index++].text);
        transferObject.proposedCatchPrice = stringToNumber(element.childElements[index++].text);
        transferObject.formattedTitle = element.childElements[index++].text;
        transferObject.imageId = stringToNumber(element.childElements[index++].text);
    }
};
