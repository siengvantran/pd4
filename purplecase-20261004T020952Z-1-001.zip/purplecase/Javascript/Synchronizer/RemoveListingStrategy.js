RemoveListingStrategy = Class.create();
RemoveListingStrategy.prototype = {
    initialize: function() {
    },

    locateListingForKey: function(key, transferObjects) {
        return transferObjects.get(key);
    },

    handleEndedListing: function(key, transferObjects) {
        transferObjects.remove(key);
    },

    generateUrlParams: function(transferObjects) {
        var urlParams = new UrlParams();
        var transferObjectValues = transferObjects.values();
        for (var index = 0; index < transferObjectValues.length; index++) {
            urlParams.addParameter("listingIds",transferObjectValues[index].listingId);
        }

        return urlParams;
    }
};
