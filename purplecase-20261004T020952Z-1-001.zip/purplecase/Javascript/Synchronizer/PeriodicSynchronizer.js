PeriodicSynchronizer = Class.create();
PeriodicSynchronizer.prototype = {
    initialize: function(registry) {
        this.system = registry.getSystem();
        this.ajaxRequester = registry.getAjaxRequester();
        this.synchronizables = new Map();
    },

    start: function() {
        this.synchronize();
    },

    registerSynchronizable: function(synchronizable) {
        this.synchronizables.put(synchronizable.getXMLTagName(), synchronizable);
    },

    callback: function(request, responseHeader) {
        var xmlDoc = new REXMLLite(request.responseText);

        for (var i = 0; i < xmlDoc.rootElement.childElements.length; i++) {
            var synchronizable = this.synchronizables.get(xmlDoc.rootElement.childElements[i].name);
            if (synchronizable) {
                synchronizable.synchronizeState(xmlDoc.rootElement.childElements[i]);
            }
        }
    },

    assembleUrlParamsForSynchronizableValues: function(params) {
        var synchronizableValues = this.synchronizables.values();
        for (var index = 0; index < synchronizableValues.length; index++) {
            params.merge(synchronizableValues[index].getUrlParams());
        }
    },

    assembleUrlParams: function() {
        var params = new UrlParams();
        this.assembleUrlParamsForSynchronizableValues(params);
        return params.toQueryString();
    },

    synchronizeNeeded: function() {
        var synchronizableValues = this.synchronizables.values();
        for (var index = 0; index < synchronizableValues.length; index++) {
            if (!synchronizableValues[index].synchronizeNeeded()) {
                return false;
            }
        }
        return true;
    },

    synchronize: function() {
        var urlParam = this.assembleUrlParams();
        if (this.synchronizeNeeded()) {
        var request = this.ajaxRequester.makeRequest("SynchronizeStateAjax.zd",
            {parameters: urlParam, onSuccess: this.callback.bind(this)});
        }

        setTimeout(this.synchronize.bind(this), 5000);
    }
};