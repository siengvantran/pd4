CatchSynchronizer = Class.create();
CatchSynchronizer.prototype = {
    initialize: function() {
    },

    setCatchList: function(catchList) {
        this.catchList = catchList;
    },

    getXMLTagName: function() {
        return "catches";
    },

    getUrlParams: function() {
        var params = new UrlParams();
        params.addParameter("listingId",this.catchList.listingId);
        return params;
    },

    synchronizeState: function(xmlElement) {
        for (var i = 0; i < xmlElement.childElements.length; i++) {
            var index = 0;
            var element = xmlElement.childElements[i];
            var catchObject = new CatchTransferObject(
                stringToNumber(element.childElements[index++].text),
                stringToNumber(element.childElements[index++].text),
                stringToNumber(element.childElements[index++].text),
                stringToNumber(element.childElements[index++].text),
                stringToNumber(element.childElements[index++].text),
                element.childElements[index++].text,
                element.childElements[index++].text,
                element.childElements[index++].text,
                element.childElements[index++].text,
                stringToBoolean(element.childElements[index++].text),
                element.childElements[index++].text);
            this.catchList.addCatch(catchObject);
        }
    },

    synchronizeNeeded: function() {
        return true;
    }
};
