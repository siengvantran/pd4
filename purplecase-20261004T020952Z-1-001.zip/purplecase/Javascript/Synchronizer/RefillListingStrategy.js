RefillListingStrategy = Class.create();
RefillListingStrategy.prototype = {
    initialize: function(registry, userId) {
        this.registry = registry;
        this.userId = userId;
    },

    locateListingForKey: function(key, transferObjects) {
        var element = transferObjects.get(key);
        if (element != null) {
            if (!element.listingRefiller.isLocked()) {
                element.listingRefiller.renewExpirationAndRelock();
            }
            return element;
        }

        var transferObjectValues = transferObjects.values();
        for (var index = 0; index < transferObjectValues.length; index++) {
            transferObject = transferObjectValues[index];
            if (transferObject.listingRefiller.canRefillListing(transferObject)) {
               transferObject.listingRefiller.renewExpirationAndRelock();

               transferObjects.remove(""+transferObject.listingId);
               transferObjects.put(key, transferObject);
               return transferObject;
            }
        }

        return null;
    },

    handleEndedListing: function(key, transferObjects) {
    },

    generateUrlParams: function(transferObjects) {
        var urlParams = new UrlParams();
        var transferObjectValues = transferObjects.values();
        var endedCount = 0;
        for (var index = 0; index < transferObjectValues.length; index++) {
            var transferObject = transferObjectValues[index];
            calculator = new ListingStateCalculator(transferObject);
            if (transferObject.listingRefiller.canRefillListing(transferObject)) {
                endedCount++;
            } else {
                urlParams.addParameter("listingIds",transferObject.listingId);
            }
        }

        if (endedCount > 0) {
            urlParams.addParameter("fetchNewListing",""+endedCount);
            urlParams.addParameter("affiliateFrameId",this.userId);
        }

        return urlParams;
    }
};
