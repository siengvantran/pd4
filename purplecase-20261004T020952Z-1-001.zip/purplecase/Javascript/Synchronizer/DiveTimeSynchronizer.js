DiveTimeSynchronizer = Class.create();
DiveTimeSynchronizer.prototype = {
    initialize: function(registry) {
        this.registry = registry;
    },

    getUrlParams: function() {
        return new UrlParams();
    },

    synchronizeState: function(xmlElement) {
        this.registry.getDiveTime().setTime(stringToNumber(xmlElement.text));
    },

    synchronizeNeeded: function() {
        return true;
    },

    getXMLTagName: function() {
        return "divetime";
    }
}


