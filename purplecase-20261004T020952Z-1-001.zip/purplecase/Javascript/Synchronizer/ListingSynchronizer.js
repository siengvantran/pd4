ListingSynchronizer = Class.create();
ListingSynchronizer.prototype = {
    initialize: function(registry, listingDataFlagsValue, endingListingStrategy) {
        this.registry = registry;
        this.transferObjects = new Map();
        this.listingDataFlagsValue = listingDataFlagsValue;
        this.endingListingStrategy = endingListingStrategy;
    },

    addListingTransferObject: function(transferObject) {
        this.transferObjects.put("" + transferObject.listingId, transferObject);
    },

    getListingTransferObjectForId: function(listingId) {
        return (this.transferObjects.get("" + listingId));
    },

    listingTransferObjectForIdExists: function(listingId) {
        return (this.getListingTransferObjectForId(listingId) != null);
    },

    getXMLTagName: function() {    
        return "listing";
    },

    getUrlParams: function() {
        var urlParams = this.endingListingStrategy.generateUrlParams(this.transferObjects);

        urlParams.addParameter("listingDataFlags", this.listingDataFlagsValue);

        return urlParams;
    },

    handleListingElement: function(element) {
        var key = "" + stringToNumber(element.childElements[0].text);
        var transferObject = this.endingListingStrategy.locateListingForKey(key, this.transferObjects);
        var index = 0;

        var converter = new XMLToListingTransferObject();
        converter.convert(element, transferObject);

        this.removeListingElementIfEnded(transferObject);
    },

    removeListingElementIfEnded: function(transferObject) {
        if (transferObject.effectiveEndDate.getTime() < this.registry.getDiveTime().getTime().getTime()) {
            this.endingListingStrategy.handleEndedListing("" + transferObject.listingId, this.transferObjects);
        }
    },

    synchronizeState: function(xmlElement) {
        this.handleListingElement(xmlElement);
    },

    synchronizeNeeded: function() {
        return (!this.transferObjects.isEmpty());
    }
};
