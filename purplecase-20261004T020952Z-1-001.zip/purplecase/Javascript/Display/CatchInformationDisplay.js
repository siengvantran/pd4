function CatchInformationDisplay(catchTimeElementName, priceElementName, quantityElementName, catchState, formattedExecutionTime,
                                 formattedPrice, formattedCount, formattedQuantityWon, formattedQuantityLeft, partialCatch) {
    this.catchState = catchState;
    this.formattedExecutionTime = formattedExecutionTime;
    this.formattedPrice = formattedPrice;
    this.formattedCount = formattedCount;
    this.formattedQuantityWon = formattedQuantityWon;
    this.formattedQuantityLeft = formattedQuantityLeft;
    this.partialCatch = partialCatch;
    this.catchTimeElement = document.getElementById(catchTimeElementName);
    this.priceElement = document.getElementById(priceElementName);
    this.quantityElement = document.getElementById(quantityElementName);
}

CatchInformationDisplay.prototype.setCatchInformation = function(catchTimeLeft) {

    if (catchTimeLeft.getTime() < 0 &&
        this.catchState == CATCH_STATE_ACTIVE){
        this.catchState = CATCH_STATE_EXECUTED;
    }

    this.generateCatchTimeHTML(catchTimeLeft);
    this.generatePriceHTML();
    this.generateCountHTML();
}

CatchInformationDisplay.prototype.generateCatchTimeHTML = function(catchTimeLeft) {
    var innerHTML = "";

    innerHTML += this.beginSpan(CATCH_STATE_CSS_CLASS[this.catchState]);
    if (this.catchState == CATCH_STATE_INACTIVE) {
        innerHTML += "Inactive<br>Not a winning catch";
    } else if (this.catchState == CATCH_STATE_ACTIVE) {
     /*   innerHTML += "Will catch in<br>" + formatTimeRaw(catchTimeLeft);*/  innerHTML += "<br>";
    } else if (this.catchState == CATCH_STATE_EXECUTED) {
        innerHTML += "Executed<br>" + this.formattedExecutionTime;
    }
    innerHTML += this.endSpan();
    this.catchTimeElement.innerHTML = innerHTML;
}

CatchInformationDisplay.prototype.generatePriceHTML = function() {
    var innerHTML = "";
    innerHTML += this.beginSpan(CATCH_STATE_CSS_CLASS[this.catchState]);
    innerHTML += this.formattedPrice;
    innerHTML += this.endSpan();
    this.priceElement.innerHTML = innerHTML;
}

CatchInformationDisplay.prototype.generateCountHTML = function() {
    var innerHTML = "";
    innerHTML += this.beginSpan(CATCH_STATE_CSS_CLASS[this.catchState]);
    innerHTML += this.formattedCount;
    if (this.catchState != CATCH_STATE_INACTIVE) {
        if (this.partialCatch) {
            innerHTML += this.beginDiv("CatchHistoryCatchInfo");
            if (this.catchState == CATCH_STATE_ACTIVE) {
                innerHTML += "You'll catch: ";
            } else {
                innerHTML += "Caught: ";
            }
            innerHTML += this.formattedQuantityWon;
            innerHTML += this.endDiv();
        }

        if (this.catchState == CATCH_STATE_ACTIVE) {
            innerHTML += this.beginDiv("CatchHistoryCatchInfo");
            innerHTML += "Remaining: " + this.formattedQuantityLeft;
            innerHTML += this.endDiv();
        }
    }
    innerHTML += this.endSpan();
    this.quantityElement.innerHTML = innerHTML;
}

CatchInformationDisplay.prototype.beginSpan = function(cssClass) {
    return "<span class=\"" + cssClass + "\">";
}

CatchInformationDisplay.prototype.endSpan = function() {
    return  "</span>";
}

CatchInformationDisplay.prototype.beginDiv = function(cssClass) {
    return "<div class=\"" + cssClass + "\">";
}

CatchInformationDisplay.prototype.endDiv = function() {
    return  "</div>";
}