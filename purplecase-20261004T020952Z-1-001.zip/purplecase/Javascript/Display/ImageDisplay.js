ImageDisplay = Class.create();
ImageDisplay.prototype = {

    initialize: function(registry,
                        transferObject,
                        elementName) {

        this.registry = registry;
        this.transferObject = transferObject;
        this.element = $(elementName);
        this.currentImageId = -1;
    },

    update: function() {
        if (this.currentImageId != this.transferObject.imageId) {
            var imageUrl = this.registry.getLinkUrlGenerator().getImageUrl(this.transferObject.imageId);
            this.element.innerHTML = "<image border=\"0\" src=\""+imageUrl+"\"></img>";
            this.currentImageId = this.transferObject.imageId;
        }
    }
};

