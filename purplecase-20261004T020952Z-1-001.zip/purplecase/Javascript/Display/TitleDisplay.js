TitleDisplay = Class.create();
TitleDisplay.prototype = {

    initialize: function(registry,
                        transferObject,
                        elementName) {

        this.registry = registry;
        this.transferObject = transferObject;
        this.element = $(elementName);
    },

    update: function() {
        this.element.innerHTML = this.transferObject.formattedTitle;
    }
};
