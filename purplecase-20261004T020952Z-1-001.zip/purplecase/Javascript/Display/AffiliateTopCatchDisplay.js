AffiliateTopCatchDisplay = Class.create();
AffiliateTopCatchDisplay.prototype = {

    UNSET_VALUE:-1,

    initialize: function(registry, transferObject, elementName) {
        this.element = $(elementName);
        this.transferObject = transferObject;
        this.registry = registry;
        this.catchCount = this.UNSET_VALUE;
        this.listingId = this.transferObject.listingId;
        this.hudElementSequencerPulse = registry.getHudElementSequencerPulse();
    },

    update: function() {
        var html = "";

        if (this.transferObject.catchCount > 0  && this.transferObject.isMultiQuantity == false) {
            this.element.innerHTML = this.generateUsername();
        } else {
            this.element.innerHTML = "catch it now!";
        }

        if (this.needToPulse()) {
            this.hudElementSequencerPulse.startNewHudElement(this.element,
                    HUD_ELEMENT_SEQUENCE_PULSE_TYPE_POSITIVE);
        }

        this.catchCount = this.transferObject.catchCount;
        this.listingId = this.transferObject.listingId;
    },

    generateUsername: function() {

        var value;
        if (this.transferObject.topCatchIsFromLoggedInUser) {
            value = "Me!";
        }
        else {
            value = this.transferObject.formattedTopCatchUserName;
        }
        return value;

    },

    needToPulse: function() {
        return (this.catchCount != this.UNSET_VALUE &&
                this.catchCount != this.transferObject.catchCount &&
                this.listingId == this.transferObject.listingId);
    }

};
