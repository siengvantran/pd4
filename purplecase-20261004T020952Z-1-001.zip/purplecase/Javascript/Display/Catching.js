//Catching
function handlePartialCatch(divId, quantityFieldId) {
	if (document.getElementById(quantityFieldId).value > 1) {
		show(divId);
	}
	else {
		hide(divId);
	}
}

function handleEmptyPrice(catchAtCurrentPriceFieldId, priceFieldId) {

	if (document.getElementById(priceFieldId).value=="") {
		document.getElementById(catchAtCurrentPriceFieldId).value="true";
	}
}
