TopCatchDisplay = Class.create();
TopCatchDisplay.prototype = {

    UNSET_VALUE:-1,

    initialize: function(registry, transferObject, elementName, addBreakLine, showPriceAtDiveEnd) {
        this.addBreakLine = addBreakLine;
        this.showPriceAtDiveEnd = showPriceAtDiveEnd;
        this.element = $(elementName);
        this.transferObject = transferObject;
        this.registry = registry;
        this.catchCount = this.UNSET_VALUE;
        this.hudElementSequencerPulse = registry.getHudElementSequencerPulse();
        this.listingStateCalculator = new ListingStateCalculator(transferObject);

        if (this.addBreakLine) {
            this.lineBreakContent = "<br/>";
        } else {
            this.lineBreakContent = "&nbsp;-&nbsp;";
        }
    },

    update: function() {
        var html = "";

        var state = this.listingStateCalculator.stateAtDate(this.registry.getDiveTime().getTime());

        if (listingEnded(state) && !this.showPriceAtDiveEnd) {

            if (state == LISTING_STATE_INACTIVE_NOT_SOLD) {
                html +="<span class=\"TopCatchNotCaught\">[Not caught]</span>";
            } else {
                if (this.transferObject.isMultiQuantity) {
                    html +="<span class=\"TopCatchNotCaught\">[Multiple]</span>";
                }
                else {
                    html += this.generateUsername("TopCatchUsernameBig", "TopCatchUsernameBigMe");
                }
            }
        }
        else {

            html += this.generatePriceContent();

            if (this.transferObject.catchCount > 0  && this.transferObject.isMultiQuantity == false) {
                html += this.lineBreakContent+this.generateUsername("TopCatchUsernameSmall", "TopCatchUsernameSmallMe");
            }
        }

        this.element.innerHTML = html;

        if (this.catchCount != this.UNSET_VALUE &&
                    this.catchCount != this.transferObject.catchCount) {
            this.hudElementSequencerPulse.startNewHudElement(this.element,
                    HUD_ELEMENT_SEQUENCE_PULSE_TYPE_POSITIVE);
        }

        this.catchCount = this.transferObject.catchCount;
    },

    generatePriceContent: function() {
        var priceContent;
        if (this.transferObject.catchCount == 0 || this.transferObject.isMultiQuantity) {
            if (this.transferObject.absoluteMinPrice > 0) {
                priceContent = "<span class=\"TopCatchPriceNoCatch\">"+formatPriceNoSubcent(this.transferObject.absoluteMinPrice)+"</span>";
            } else {
                priceContent = "<span class=\"TopCatchNoMinimum\">[No minimum]</span>";
            }
        } else {
            priceContent = "<span class=\"TopCatchPriceCatchExists\">"+formatPriceNoSubcent(this.transferObject.topCatchPrice)+"</span>";
        }

        return priceContent;
    },

    generateUsername: function(cssClass, cssClassMe) {

        if (this.transferObject.topCatchIsFromLoggedInUser) {
            value="<span class=\""+cssClassMe+"\">Me!</span>";
        }
        else {


            var value = "<span class=\""+cssClass+"\">"+
                    this.transferObject.formattedTopCatchUserName+"</span>";
        }
        return value;

    }

};
