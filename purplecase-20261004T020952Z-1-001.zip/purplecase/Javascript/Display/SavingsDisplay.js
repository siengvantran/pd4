SavingsDisplay = Class.create();
SavingsDisplay.prototype = {

    initialize: function(registry, transferObject, retailElementName, retailPrice, savingsElementName) {
        this.registry = registry;
        this.stateCalculator = new ListingStateCalculator(transferObject);
        this.transferObject = transferObject;
        this.retailElement = $(retailElementName);
        this.retailPrice = retailPrice;
        this.savingsElement = $(savingsElementName);
    },

    update: function() {
        var state = this.stateCalculator.stateAtDate(this.registry.getDiveTime().getTime());

        if (state == LISTING_STATE_NOT_PUBLISHED) {
            this.retailElement.innerHTML = "<span class=\"ListingSaving\">???</span>";
            this.savingsElement.innerHTML = "<span class=\"ListingSaving\">???</span>";
        } else {
            var percent =
                    100.0 - (this.stateCalculator.priceAtDate(this.registry.getDiveTime().getTime()) /
                    this.retailPrice * 100.0);

            var style;
            if (state == LISTING_STATE_ACTIVE) {
                style = "ListingSavingImportant";
            } else {
                style = "ListingSaving";
            }

            this.retailElement.innerHTML = "<span class=\"" + style + "\">" +
                                           formatPriceNoSubcent(this.retailPrice) + "</span>";
            this.savingsElement.innerHTML = "<span class=\"" + style + "\">" +
                                            formatRawPrice(percent, 2) + "%</span>";
        }
    }
};
