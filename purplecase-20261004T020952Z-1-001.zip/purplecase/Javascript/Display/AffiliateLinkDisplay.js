AffiliateLinkDisplay = Class.create();
AffiliateLinkDisplay.prototype = {

    FADE_STATE_INITIAL_FADE_IN: 0,
    FADE_STATE_NO_FADE: 1,
    FADE_STATE_WAITING_TO_FADE_OUT: 2,
    FADE_STATE_FADING_OUT: 3,
    FADE_STATE_WAITING_FOR_NEW_LISTING: 4,
    FADE_STATE_DELAY_BEFORE_FADE_IN: 5,
    FADE_STATE_FADING_IN: 6,

    initialize: function(registry,
                        transferObject,
                        elementName,
                        parentElementName,
                        backgroundElementName,
                        affiliateId,
                        width,
                        height) {

        this.registry = registry;
        this.transferObject = transferObject;
        this.element = $(elementName);
        this.backgroundElement = $(backgroundElementName);
        this.parentElement = $(parentElementName);
        this.parentElement.style.position = "relative";

        this.initContentElement();
        this.initBackgroundElement();

        this.affiliateId = affiliateId;
        this.width = width;
        this.height = height;
        this.registry.getEventHandler().addEvent(this.element, 'mouseup', this.onMouseUp.bindAsEventListener(this));
        this.stateCalculator = new ListingStateCalculator(this.transferObject);
        this.state = this.FADE_STATE_NO_FADE;
        this.renderScheduleId = this.registry.getRenderScheduler().registerRenderable(this, "affiliate");
        this.registry.getRenderScheduler().requestRender(this.renderScheduleId);
        this.fader = new ElementFader(this.registry.getSystem(), this.element, 0.0, 1.0, 2000);
        this.fader.start();
        this.fader.update();
        this.state = this.FADE_STATE_INITIAL_FADE_IN;
        this.transferObject.locked = true;
        this.renderObjectFactory = new RenderObjectFactory(registry);
    },

    onMouseUp: function() {
        this.registry.getPageNavigator().goToPage(
                this.registry.getLinkUrlGenerator().getAffiliateViewPage(this.affiliateId, this.transferObject.listingId));
    },

    update: function() {

    },

    render: function() {
        if (this.state == this.FADE_STATE_INITIAL_FADE_IN) {
            this.initialFadeIn();
        }
        else if (this.transferObject.listingRefiller.needToRefillListing(this.transferObject) &&
            this.state == this.FADE_STATE_NO_FADE) {
            this.initWaitToFadeOut();
        } else if (this.state == this.FADE_STATE_WAITING_TO_FADE_OUT) {
            this.waitToFadeOut();
        } else if (this.state == this.FADE_STATE_FADING_OUT) {
            this.fadingOut();
        } else if (this.state == this.FADE_STATE_WAITING_FOR_NEW_LISTING) {
            this.waitForNewListing();
        } else if (this.state == this.FADE_STATE_DELAY_BEFORE_FADE_IN) {
            this.delayBeforeFadeIn();
        } else if (this.state == this.FADE_STATE_FADING_IN) {
            this.fadingIn();
        }

        this.registry.getRenderScheduler().requestRender(this.renderScheduleId);
    },

    initialFadeIn: function() {
        this.fader.update();
        if (this.fader.isComplete()) {
            this.state = this.FADE_STATE_NO_FADE;
            this.transferObject.locked = false;
            Element.show(this.backgroundElement);
        }
    },

    initWaitToFadeOut: function() {
        this.startDelayTime = this.registry.getSystem().getCurrentTime();
        this.state = this.FADE_STATE_WAITING_TO_FADE_OUT;
    },

    waitToFadeOut: function() {
        if (this.registry.getSystem().getCurrentTime().getTime() -
            this.startDelayTime.getTime() > 3000) {
            this.fader = new ElementFader(this.registry.getSystem(), this.element, 1.0, 0.0, 1000);
            this.fader.start();
            this.state = this.FADE_STATE_FADING_OUT;
        }
    },

    fadingOut: function() {
        this.fader.update();
        if (this.fader.isComplete()) {
            this.transferObject.listingRefiller.unlockListing();
            this.state = this.FADE_STATE_WAITING_FOR_NEW_LISTING;
        }
    },

    waitForNewListing: function() {
        if (!this.transferObject.listingRefiller.needToRefillListing(this.transferObject)) {
            this.state = this.FADE_STATE_DELAY_BEFORE_FADE_IN;
            this.startDelayTime = this.registry.getSystem().getCurrentTime();
        }
    },

    delayBeforeFadeIn: function() {
        if (this.registry.getSystem().getCurrentTime().getTime() -
            this.startDelayTime.getTime() > 1000) {
            this.fader = new ElementFader(this.registry.getSystem(), this.element, 0.0, 1.0, 1000);
            this.fader.start();
            this.state = this.FADE_STATE_FADING_IN;
        }
    },

    fadingIn: function() {
        this.fader.update();
        if (this.fader.isComplete()) {
            this.state = this.FADE_STATE_NO_FADE;
        }
    },

    initContentElement: function() {
        this.element.style.zIndex = '2';
        this.element.style.cursor = "pointer";
        this.element.style.position = "absolute";
        this.element.style.left = 0;
        this.element.style.top = 0;
    },

    initBackgroundElement: function() {
        this.backgroundElement.style.position = "absolute";
        this.backgroundElement.style.left = 0;
        this.backgroundElement.style.top = 0;
        this.backgroundElement.style.zIndex = '1';
        var opacityValue = 1.0;
        this.backgroundElement.style.filter = "alpha(opacity=" + Math.round(opacityValue * 100.0) + ")";
        this.backgroundElement.style.opacity = opacityValue + '';
        Element.hide(this.backgroundElement);
    }
};

