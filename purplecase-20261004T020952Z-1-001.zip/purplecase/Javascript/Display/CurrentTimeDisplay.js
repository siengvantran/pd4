CurrentTimeDisplay = Class.create();
CurrentTimeDisplay.prototype = {

    initialize: function(registry, elementId) {
        this.registry = registry;
        this.element = $(elementId);
    },

    update: function() {
        this.element.innerHTML = this.registry.getDiveTime().getTime().toLocaleString();
    }
};
