InstantCatchDisplay = Class.create();
InstantCatchDisplay.prototype = {

    initialize: function(registry,
                        periodicSynchronizer,
                        transferObject,
                        elementName,
                        elementNameNA,
                        showNA,
                        isSignedIn,
                        confirmCatch,
                        quantity,
                        priceInputName,
                        catchItNowButtonName,
                        setYourPriceButtonName,
                        catchItNowBlockName,
                        setYourPriceBlockName,
                        listingDataFlagsValue) {

        this.registry = registry;
        registry.getCatchNotifier().registerObserver(this);
        this.periodicSynchronizer = periodicSynchronizer;
        this.isSignedIn = isSignedIn;
        this.confirmCatch = confirmCatch;
        this.ajaxRequester = registry.getAjaxRequester();
        this.element = $(elementName);
        this.elementNA = $(elementNameNA);
        this.showNA = $(showNA);
        this.catchItNowButtonInput = $(catchItNowButtonName);
        this.setYourPriceButtonInput = $(setYourPriceButtonName);
        this.quantity = quantity;
        this.priceInput = $(priceInputName);
        this.catchItNowBlock = $(catchItNowBlockName);
        this.setYourPriceBlock = $(setYourPriceBlockName);
        this.listingDataFlagsValue = listingDataFlagsValue;

        this.transferObject = transferObject;
        this.stateCalculator = new ListingStateCalculator(this.transferObject);

        if (this.hasSetYourPriceBlock()) {
            this.submitButtonOriginalValue = this.setYourPriceButtonInput.value;
            this.registry.getEventHandler().addEvent(this.priceInput, 'focus', this.onPriceInputFocus.bindAsEventListener(this));
            this.registry.getEventHandler().addEvent(this.priceInput, 'blur', this.onPriceInputLeave.bindAsEventListener(this));
            this.priceInputFocus = false;
            this.setPriceValueToProposedCatchPrice();
            this.initializeClickEventsForSetYourPrice();
        }

        if (this.hasCatchItNowBlock()) {
            this.initializeClickEventsForCatchItNow();
        }
    },

    hasSetYourPriceBlock: function() {
        return this.setYourPriceBlock != null;
    },

    hasCatchItNowBlock: function() {
        return this.catchItNowBlock != null;
    },

    generateUrlParams: function(url, catchItNow) {
        url.addParameter("listingId",
                this.transferObject.listingId);

        url.addParameter("listingDataFlags", this.listingDataFlagsValue);
        if (!catchItNow && !this.confirmCatch) {
            url.addParameter("listingIds",
                    this.transferObject.listingId);
        }
        url.addParameter("validatedCatch.catchAtCurrentPrice",
                catchItNow);
        url.addParameter("validatedCatch.quantity",
                this.quantity);
        url.addParameter("validatedCatch.confirmCatch",
                this.confirmCatch);

        if (!catchItNow) {
            url.addParameter(this.priceInput.name,
                this.priceInput.value);
        }
    },

    gotoSetYourPriceProcessCatchPage: function() {
        this.gotoProcessCatchPage(false);
        return cancelEvent();
    },

    gotoCatchItNowProcessCatchPage: function() {
        this.gotoProcessCatchPage(true);
        return cancelEvent();
    },

    gotoProcessCatchPage: function(catchItNow) {

        if (this.isSignedIn) {
            var url = new Url("ProcessCatch.zd");
            this.generateUrlParams(url, catchItNow);
            url.addParameter("encodedBackUrl",this.registry.getLinkUrlGenerator().encodedBackUrl);
            this.registry.getPageNavigator().goToPage(url.toQueryString());
        }
        else {
            var url = new Url("SignIn.zd");
            url.addParameter("encodedBackUrl",this.registry.getLinkUrlGenerator().encodedBackUrl);
            url.addParameter("encodedReturnUrl",this.registry.getLinkUrlGenerator().encodedBackUrl);
            this.registry.getPageNavigator().goToPage(url.toQueryString());
        }
    },

    dynamicSetYourPrice: function() {
        var url = new Url("ConfirmCatchAjax.zd");
        this.generateUrlParams(url, false);

        this.disableInputs();

        var request = this.ajaxRequester.makeRequest(url.getTarget(),
            {parameters: url.paramsToQueryString(), onSuccess: this.callback.bind(this)});

        return cancelEvent();
    },

    callback: function(request, responseHeader) {
        var xmlDoc = new REXMLLite(request.responseText);

        this.enableInputs();

        if (xmlDoc.rootElement.childElements.length > 0) {
            if (xmlDoc.rootElement.childElements[0].name == "error") {
                this.registry.hudElementSequencerPulse.startNewHudElement(this.priceInput,
                        HUD_ELEMENT_SEQUENCE_PULSE_TYPE_NEGATIVE);
                this.setPriceValueToProposedCatchPrice();

            } else {
                this.periodicSynchronizer.callback(request,responseHeader);
                this.registry.getUpdater().updateUpdateables();
            }
        }
    },

    update: function() {

        var state = this.stateCalculator.stateAtDate(this.registry.getDiveTime().getTime());

        if (state == LISTING_STATE_ACTIVE) {
            this.updateInputCatchPrice();
            Element.show(this.element);
            Element.hide(this.elementNA);
        } else {
            Element.hide(this.element);
            if (this.showNA) {
                Element.show(this.elementNA);
            }
        }
    },

    disableInputs: function(){
        this.setYourPriceButtonInput.value = "...";
        this.setYourPriceButtonInput.disabled = true;
        this.priceInput.disabled = true;
    },

    enableInputs: function(){
        this.setYourPriceButtonInput.value = this.submitButtonOriginalValue;
        this.setYourPriceButtonInput.disabled = false;
        this.priceInput.disabled = false;
        this.setYourPriceButtonInput.focus();
    },

    onPriceInputFocus: function(){
        this.priceInputFocus = true;
    },

    onPriceInputLeave: function(){
        this.priceInputFocus = false;
        this.updateInputCatchPriceValueIfNecessary();
    },

    updateInputCatchPriceValueIfNecessary: function() {
        var value = stringToNumber(this.priceInput.value);
        if (value < this.transferObject.minValidCatchPrice ||
            value > this.stateCalculator.absolutePriceAtDate(this.registry.getDiveTime().getTime())) {
            this.setPriceValueToProposedCatchPrice();
        }
    },

    updateInputCatchPrice: function() {
        if (this.priceInputFocus == false) {
            this.updateInputCatchPriceValueIfNecessary();
        }
    },

    setPriceValueToProposedCatchPrice: function(){
        this.priceInput.value = formatRawPriceNoSubcent(this.transferObject.proposedCatchPrice);
    },

    setCatch: function(price) {
        if (this.hasSetYourPriceBlock()) {
            this.priceInput.value = price;
            Element.show(this.setYourPriceBlock);

            if (this.hasCatchItNowBlock()) {
                Element.hide(this.catchItNowBlock);
            }
        }
    },

    initializeClickEventsForCatchItNow: function() {
        this.catchItNowButtonInput.onclick = this.gotoCatchItNowProcessCatchPage.bind(this);
    },

    initializeClickEventsForSetYourPrice: function() {
        if (this.confirmCatch) {
            this.setYourPriceButtonInput.onclick = this.gotoSetYourPriceProcessCatchPage.bind(this);
        } else {
            this.setYourPriceButtonInput.onclick = this.dynamicSetYourPrice.bind(this);
        }
    }
};
