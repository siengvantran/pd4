function DivePriceDisplay(elementName) {
	this.element = $(elementName);
}

DivePriceDisplay.prototype.setPrice = function(price, listingState) {
	this.price = price;
	this.generateHTML(listingState);
}

DivePriceDisplay.prototype.generateHTML = function(listingState) {

    var innerHTML;

    if (listingState == LISTING_STATE_NOT_PUBLISHED) {
        innerHTML =
            "<span class=\"" + DIVE_PRICE_CSS_CLASS[LISTING_STATE_NOT_PUBLISHED] + "\">" +
            "???" +
            "</span>";

	}
	else {
        innerHTML = formatPriceWithType(this.price, listingState);
	}

    this.element.innerHTML = innerHTML;
}