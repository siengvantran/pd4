QuantityLeftDisplay = Class.create();
QuantityLeftDisplay.prototype = {

    UNSET_VALUE: -1,

    initialize: function(registry, elementName) {
        this.element = $(elementName);
        this.quantityLeft = this.UNSET_VALUE;
        this.hudElementSequencerPulse = registry.getHudElementSequencerPulse();
        this.listingState = this.UNSET_VALUE;
    },

    setQuantityLeft: function(quantityLeft, listingState) {
        this.element.innerHTML = quantityLeft;

        if (this.quantityChanged(quantityLeft) &&
            !listingBecomesActive(this.listingState, listingState)) {
            this.hudElementSequencerPulse.startNewHudElement(this.element,
                    HUD_ELEMENT_SEQUENCE_PULSE_TYPE_POSITIVE);
        }
        this.quantityLeft = quantityLeft;
        this.listingState = listingState;

    },

    quantityChanged: function(quantityLeft){
        var changed = this.quantityLeft != this.UNSET_VALUE && quantityLeft != this.quantityLeft;
        return changed;
    }
};