var CATCH_STATE_CSS_CLASS = new Array(
    "CatchHistoryDataCaught",
    "CatchHistoryDataDeprecated",
    "CatchHistoryData");
