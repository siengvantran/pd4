WatchCountDisplay = Class.create();
WatchCountDisplay.prototype = {

    UNSET_VALUE: "invalidContent",

    initialize: function(registry, transferObject, elementId) {
        this.registry = registry;
        this.transferObject = transferObject;
        this.element = $(elementId);
        this.stateCalculator = new ListingStateCalculator(transferObject);
        this.hudElementSequencerPulse = registry.getHudElementSequencerPulse();
        this.content = this.UNSET_VALUE;
        this.listingState = this.UNSET_VALUE;
    },

    update: function() {
        var innerHtml = this.transferObject.formattedWatchCount;
        this.element.innerHTML = innerHtml;
        var listingState = this.stateCalculator.stateAtDate(this.registry.getDiveTime().getTime());

        if (this.contentChanged(innerHtml) &&
            !listingBecomesActive(this.listingState, listingState)) {
            this.hudElementSequencerPulse.startNewHudElement(this.element,
                    HUD_ELEMENT_SEQUENCE_PULSE_TYPE_POSITIVE);
        }

        this.content = innerHtml;
        this.listingState = listingState;
    },

    contentChanged: function(content){
        var changed = this.content != this.UNSET_VALUE &&
                    content != this.content;
        return changed;
    }
};
