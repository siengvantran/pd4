ListingStateBlockDisplay = Class.create();
ListingStateBlockDisplay.prototype = {

    initialize: function(transferObject, elementId) {
        this.transferObject = transferObject;
        this.element = $(elementId);
    },

    display: function(state) {
        if (state == LISTING_STATE_ACTIVE) {
            this.element.innerHTML = "";
        } else if (state == LISTING_STATE_INACTIVE_NOT_SOLD){
            this.element.innerHTML = this.createTableBlockHTML("ViewEndedBlockNotSold",
                    "This Dive Ended " + this.transferObject.formattedEndTime);
        } else if (state == LISTING_STATE_INACTIVE_SOLD){
            this.element.innerHTML = this.createTableBlockHTML("ViewEndedBlockSold",
                    "This Dive Ended " + this.transferObject.formattedEndTime);
        } else if (state == LISTING_STATE_NOT_PUBLISHED) {
            this.element.innerHTML = this.createTableBlockHTML("ViewNotYetActiveBlock",
                    "This Dive Will Start " + this.transferObject.formattedPublishTime);
        }
    },

    createTableBlockHTML: function(cssClass, message) {
        var html = "<table class=\"ModuleContainer\" cellpadding=\"0\" cellspacing=\"0\">" +
                        "<tr>" +
                            "<td width=\"100%\">" +
                                "<div class=\""+cssClass+"\">" +
                                    message +
                                "</div>"+
                            "</td>" +
                        "</tr>" +
                    "</table>";
        return html;
    }
};
