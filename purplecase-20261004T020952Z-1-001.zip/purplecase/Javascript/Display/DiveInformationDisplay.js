DiveInformationDisplay = Class.create();
DiveInformationDisplay.prototype = {

    initialize: function(registry, transferObject) {
        this.registry = registry;
        this.stateCalculator = new ListingStateCalculator(transferObject);
        this.transferObject = transferObject;
    },

    update: function() {
        var state = this.stateCalculator.stateAtDate(this.registry.getDiveTime().getTime());

        if (state == LISTING_STATE_NOT_PUBLISHED) {
            $("dynDiveInfo_QuantityLeftLabel").innerHTML = "Quantity Available:";
            $("dynDiveInfo_DiveEndsValue").innerHTML = "???";
        } else {
            $("dynDiveInfo_QuantityLeftLabel").innerHTML = "Quantity Left:";
            $("dynDiveInfo_DiveEndsValue").innerHTML = this.transferObject.formattedEndTime;
        }

        if (listingEnded(state)) {
            $("dynDiveInfo_DiveEndsLabel").innerHTML = "Dive Ended:";
            Element.hide($("dynDiveInfo_WatchThisListing"));
        } else {
            $("dynDiveInfo_DiveEndsLabel").innerHTML = "Dive Ends:";
        }

        $("dynDiveInfo_MaxPostageLabel").innerHTML = "Standard P&P:";

    }
};
