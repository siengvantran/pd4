NonInstantCatchDisplay = Class.create();
NonInstantCatchDisplay.prototype = {

    initialize: function(registry, transferObject, elementName) {
        this.registry = registry;
        this.element = $(elementName);
        this.transferObject = transferObject;
        this.stateCalculator = new ListingStateCalculator(this.transferObject);
    },

    update: function() {
        var state = this.stateCalculator.stateAtDate(this.registry.getDiveTime().getTime());

        if (state == LISTING_STATE_ACTIVE) {
            Element.show(this.element);
        } else {
            Element.hide(this.element);
        }
    }
};
