var DIVE_TIME_LEFT_CSS_CLASS = new Array(
        "DiveTimeLeftActive",
        "DiveTimeLeftInactiveSold",
        "DiveTimeLeftInactiveNotSold",
        "DiveTimeLeftNotPublished");

DiveTimeDisplay = Class.create();
DiveTimeDisplay.prototype = {

    UNSET_VALUE: -1,

    initialize: function(registry, listingTransferObject, elementName, longDesc, showEndTime) {
        this.element = $(elementName);
        this.listingTransferObject = listingTransferObject;
        this.longDesc = longDesc;
        this.showEndTime = showEndTime;
        this.timeLeft = this.UNSET_VALUE;
        this.catchCount = this.UNSET_VALUE;
        this.listingState = this.UNSET_VALUE;
        this.currentListingId = this.listingTransferObject.listingId;
        this.hudElementSequencerPulse = registry.getHudElementSequencerPulse();
    },

    setTimeLeft: function(timeLeft, listingState) {

        if (this.timeChanged(timeLeft) &&
            this.catchCountChanged() &&
            !listingBecomesActive(this.listingState, listingState) &&
            this.currentListingId == this.listingTransferObject.listingId) {
            this.hudElementSequencerPulse.startNewHudElement(this.element,
                    HUD_ELEMENT_SEQUENCE_PULSE_TYPE_POSITIVE);
        }

        this.timeLeft = timeLeft;
        this.catchCount = this.listingTransferObject.catchCount;
        this.listingState = listingState;
        this.currentListingId = this.listingTransferObject.listingId;
        this.generateHTML(listingState);
    },

    generateHTML: function(listingState) {

        var innerHTML = "<span class=\"" + DIVE_TIME_LEFT_CSS_CLASS[listingState] + "\">";

        if (listingState == LISTING_STATE_NOT_PUBLISHED) {
            if (this.longDesc) {
                innerHTML += "Starts In ";
                innerHTML += "<b>" + formatTimeLeft(this.timeLeft) + "</b>";
            }
            else {
                innerHTML += "Not Started";
                innerHTML +=
                "<br>" +
                "<span class=\"DiveTimeLeftNotPublishedSmallText\">" +
                formatTimeLeft(this.timeLeft)+
                "</span>";
            }
        }
        else {
            if (listingState == LISTING_STATE_ACTIVE) {
                if (this.longDesc) {
                    innerHTML +=
                    "Ends In ";
                }
                innerHTML += "<b>" + formatTimeLeft(this.timeLeft) + "</b>";
            }
            else {

                if (this.longDesc) {
                    innerHTML += "Ended";
                    if (this.showEndTime) {
                        innerHTML +=
                        " <span class=\"DiveTimeLeftEndTime\">" +
                        this.listingTransferObject.formattedEndTime +
                        "</span>";
                    }
                }
                else {
                    innerHTML += "Ended";
                    if (this.showEndTime) {
                        innerHTML +=
                        "<br>" +
                        "<span class=\"DiveTimeLeftEndTime\">" +
                        this.listingTransferObject.formattedEndTime +
                        "</span>";
                    }
                }
            }
        }

        innerHTML += "</span>";
        this.element.innerHTML = innerHTML;
    },

    timeChanged: function(timeLeft) {
        var changed =
                this.timeLeft != this.UNSET_VALUE &&
                Math.abs(timeLeft - this.timeLeft) > 10000;
        return changed;
    },

    catchCountChanged: function() {
        var changed = this.catchCount != this.UNSET_VALUE &&
            this.catchCount != this.listingTransferObject.catchCount;
        return changed;
    }
};
