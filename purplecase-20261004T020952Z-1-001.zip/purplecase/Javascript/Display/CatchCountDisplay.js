CatchCountDisplay = Class.create();
CatchCountDisplay.prototype = {

    INVALID_STATE: -1,

    initialize: function(registry, elementName, showTextFormat, linkUrl) {
        this.element = $(elementName);
        this.linkUrl = linkUrl;
        this.showTextFormat = showTextFormat;
        this.catchCount = this.INVALID_STATE;
        this.listingState = this.INVALID_STATE;
        this.hudElementSequencerPulse = registry.getHudElementSequencerPulse();
    },

    setCatchCount: function(catchCount, formattedValue, listingState) {

        if (catchCount == 0) {
            if (this.showTextFormat) {
                this.element.innerHTML =
                "<span class=\"CatchHistoryNoCatch\">" +
                               "[" + formattedValue + "]</span>";
            }
            else {
                this.element.innerHTML = catchCount;
            }
        } else {
            var textToDisplay = this.showTextFormat ? formattedValue : catchCount;

            if (this.linkUrl != "") {
                this.element.innerHTML =
                "<a href=\"" + this.linkUrl + "\">" + textToDisplay + "</a>";
            } else {
                this.element.innerHTML = textToDisplay;
            }
        }

        if (this.catchCountChanged(catchCount) &&
            !listingBecomesActive(this.listingState, listingState)) {
            this.hudElementSequencerPulse.startNewHudElement(this.element,
                    HUD_ELEMENT_SEQUENCE_PULSE_TYPE_POSITIVE);
        }
        this.catchCount = catchCount;
        this.listingState = listingState;
    },

    catchCountChanged: function(count) {
        var countChanged = (this.catchCount != this.INVALID_STATE &&
            count != this.catchCount);
        return countChanged;
    }
};