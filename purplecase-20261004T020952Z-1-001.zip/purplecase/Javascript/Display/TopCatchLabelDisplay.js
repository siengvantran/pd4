TopCatchLabelDisplay = Class.create();
TopCatchLabelDisplay.prototype = {

    initialize: function(registry, transferObject, elementName) {
        this.element = $(elementName);
        this.transferObject = transferObject;
        this.registry = registry;
        this.listingStateCalculator = new ListingStateCalculator(this.transferObject);
    },

    update: function() {
        if (listingEnded(this.listingStateCalculator.stateAtDate(this.registry.getDiveTime().getTime()))) {
            this.element.innerHTML = "Caught by: ";
        } else {
            if (this.transferObject.catchCount == 0 || this.transferObject.isMultiQuantity) {
                this.element.innerHTML = "As low as: ";
            } else {
                this.element.innerHTML = "Top Bid: ";
            }
        }
    }
};
