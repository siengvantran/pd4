//User Notification
function UserNotification(system, elementId, timeLeft) {
	this.system = system;
	this.elementId = elementId;
	this.timeLeft = timeLeft;
}

UserNotification.prototype.start = function() {
	if (this.timeLeft > 0) {
		show(this.elementId);
		this.system.setTimeout(this.stop.bind(this), this.timeLeft);
	}
}

UserNotification.prototype.stop = function() {
	hide(this.elementId);
}