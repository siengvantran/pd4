//Listing Pictures

function setMainPicture(pictureIndex) {

	document.getElementById('Main').src = 
		document.getElementById('Image_'+pictureIndex).src;

	document.getElementById('PictureNumber').innerHTML = currentPicture;
}

function setNextPicture() {
	currentPicture = currentPicture + 1;
	if (currentPicture > numberOfPictures) {
		currentPicture = 1;
	}
	setMainPicture(currentPicture);
	return cancelEvent();
}

function setPreviousPicture() {
	currentPicture = currentPicture - 1;
	if (currentPicture < 1) {
		currentPicture = numberOfPictures;
	}
	setMainPicture(currentPicture);
	return cancelEvent();
}

function setFirstPicture() {
	currentPicture = currentPicture = 1;
	setMainPicture(currentPicture);
	return cancelEvent();
}

function setLastPicture() {
	currentPicture = currentPicture = numberOfPictures;
	setMainPicture(currentPicture);
	return cancelEvent();
}
