function prefillCustomFields() {

    var customFieldPrefills = document.getElementsByName("validatedListing.customFieldPrefill");// HTMLCollection
    var customNameFields    = document.getElementsByName("validatedListing.customName");        // HTMLCollection

    for (var x = 0; x < customFieldPrefills.length; x++) {
        var nameField = customNameFields[x];                                            // HTMLInputElement
        var prefillField = customFieldPrefills[x];                                      // HTMLInputElement
        nameField.value = prefillField.value;
    }

}

function clearCustomFields() {

    var customNameFields  = document.getElementsByName("validatedListing.customName");  // HTMLCollection
    var customValueFields = document.getElementsByName("validatedListing.customValue"); // HTMLCollection

    for (var x = 0; x < customNameFields.length; x++) {
        var nameField = customNameFields[x];                                            // HTMLInputElement
        nameField.value = "";
        var valueField = customValueFields[x];                                          // HTMLInputElement
        valueField.value = "";
    }

}

