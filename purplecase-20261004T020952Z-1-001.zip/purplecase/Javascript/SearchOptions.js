//Search Options
function searchOptionsUsernameCheck(element) {
	if (!element.checked) {
		document.getElementById('SearchOptionsUsername').value = '';
	}
}

function searchOptionsKeywordsCheck(element) {
	if (!element.checked) {
		document.getElementById('SearchOptionsKeywords').value = '';
	}
}

function searchOptionsUsername(element) {
	if (trim(element.value) != "") {
		document.getElementById('SearchOptionsUsernameCheck').checked = true;
	}
	else {
		document.getElementById('SearchOptionsUsernameCheck').checked = false;
	}
}

function searchOptionsKeywords(element) {
	if (trim(element.value) != "") {
		document.getElementById('SearchOptionsKeywordsCheck').checked = true;
	}
	else {
		document.getElementById('SearchOptionsKeywordsCheck').checked = false;
	}
}

function clearSearchOptions() {
    document.getElementById('SearchOptionsProviderUserCheckHidden').value = false;
	document.getElementById('SearchOptionsKeywordsCheck').checked = false;
	document.getElementById('SearchOptionsUsernameCheck').checked = false;
	document.getElementById('model.state.validatedSearch.diveRestrictionPosition0').checked = true;
	document.getElementById('SearchOptionsUsername').value = '';
	document.getElementById('SearchOptionsKeywords').value = '';
}