function NotifyRequest_preSubmit() {

    // Some stuff we need to do to the page before the form is submitted

    // Firstly, copy the value from the user's price to the hidden field so it gets posted to the action
    var instantCatchCounter = document.getElementById("instantCatchCounter").value;
    var priceSource = document.getElementById("dynInstantCatch_price_" + instantCatchCounter);
    var priceDest = document.getElementsByName("validatedNotifyRequest.price");
    priceDest[0].value = priceSource.value;

}