//Utility
var helpPopupWindow=0;
function helpPopup(name, width, height, resize) {
	var resizeText = 'no';
	if (resize==true) {
		var resizeText = 'yes';
	}

	if(helpPopupWindow) {
    	if(!helpPopupWindow.closed) helpPopupWindow.close();
	}
	helpPopupWindow = open(name, 'name', 'toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=' + resizeText + ',resizable=' + resizeText + ',copyhistory=yes,width='+width+',height='+height+'');
	helpPopupWindow.focus();
	return cancelEvent();
}